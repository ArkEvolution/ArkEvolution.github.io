# Changelog
## [v1.0.0] 2025.08
- 基于[@ohos/axios]()原库2.2.7-rc.3版本进行适配
