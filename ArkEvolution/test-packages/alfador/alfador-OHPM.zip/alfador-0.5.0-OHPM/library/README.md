# alfador
基于 alfador 原库 v0.5.0 版本进行适配的0.0.2版本 ArkTS 3D 数学库。

## 安装 (Install)
```sh
ohpm install alfador
```

## 版本说明 (Version Note)
本库已升级适配至 alfador v0.5.0。
**注意**：为了符合 ArkTS 的严格类型系统，部分 API 方法名进行了调整（不再支持多态参数，而是拆分为具体后缀的方法），例如：
- `mult` -> `multScalar` (标量乘法)
- `mult` -> `multVec3` / `multMat33` (向量/矩阵乘法)
- `add` -> `addMat33`
- `Transform` 属性改为直接访问 public 成员 (如 `transform.up`) 而非 getter 方法。

# alfador.js (Original)

[![npm version](https://badge.fury.io/js/alfador.svg)](http://badge.fury.io/js/alfador) [![Bower version](https://badge.fury.io/bo/alfador.svg)](http://badge.fury.io/bo/alfador) [![Build Status](https://travis-ci.org/kbirk/alfador.svg?branch=master)](https://travis-ci.org/kbirk/alfador) [![Coverage Status](https://coveralls.io/repos/kbirk/alfador/badge.svg)](https://coveralls.io/r/kbirk/alfador) [![Dependency Status](https://david-dm.org/kbirk/alfador.svg)](https://david-dm.org/kbirk/alfador)

A fast 3D math library for JavaScript

### Installation

Requires [bower](http://bower.io/) or [node](http://nodejs.org/).

```bash
bower install alfador
```
or
```bash
npm install alfador
```