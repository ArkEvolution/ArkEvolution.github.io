# Changelog

## [v0.0.2] - 2025-10
### Added
- 基于 alfador v0.5.0 进行升级适配的0.0.2。
- **Triangle**: 新增 `area()`, `isInside()`, `intersect()`, `closestPoint()` 方法。
- **Vec2/Vec3**: 新增 `unsignedAngleRadians()` 和 `unsignedAngleDegrees()` 方法。
- **Core**: 新增 `Epsilon.ets` 用于浮点数比较常量。

### Changed
- **Breaking Change**: 遵循 ArkTS 强类型规范，拆分多态方法：
    - `mult` 拆分为 `multScalar`, `multVec3`, `multVec4`, `multMat33`, `multMat44`, `multQuat`。
    - `div` 拆分为 `divScalar`。
    - `add` 拆分为 `addMat33`, `addMat44` 等。
    - `sub` 拆分为 `subMat33`, `subMat44` 等。
- **Breaking Change**: `Transform` 类移除了 `up()`, `forward()`, `left()`, `scale()` 等 getter/setter 方法，改为直接访问 public 属性。新增 `rotateUpTo()`, `rotateForwardTo()` 等链式方法用于设置方向。
- **Refactor**: 优化了 `Mat33`, `Mat44` 的 `rotationFromTo` 算法。
- **Refactor**: `Vec` 类的 `length()` 方法增加了 EPSILON 容差处理。

### Fixed
- 修复了 `exports` 中 `Vec4` 导出错误的问题。

## [v1.0.0] - 2025.08
- 基于[alfador-0.0.1]()原库0.4.7版本进行适配