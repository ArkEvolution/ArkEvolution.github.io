import { describe, it, expect } from "@normalized:N&&&@ohos/hypium/index&1.0.21";
import Vec2 from "@normalized:N&&&alfador/src/main/ets/src/Vec2&0.4.7";
import Vec3 from "@normalized:N&&&alfador/src/main/ets/src/Vec3&0.4.7";
import Vec4 from "@normalized:N&&&alfador/src/main/ets/src/Vec4&0.4.7";
import Mat33 from "@normalized:N&&&alfador/src/main/ets/src/Mat33&0.4.7";
import Mat44 from "@normalized:N&&&alfador/src/main/ets/src/Mat44&0.4.7";
import Quaternion from "@normalized:N&&&alfador/src/main/ets/src/Quaternion&0.4.7";
import Triangle from "@normalized:N&&&alfador/src/main/ets/src/Triangle&0.4.7";
import Transform from "@normalized:N&&&alfador/src/main/ets/src/Transform&0.4.7";
export default function MathTest() {
    describe('MathUtilsTest', () => {
        // 1. 测试 Vec2 的加法运算
        it('Vec2_Add_Success', 0, () => {
            let v1: Vec2 = new Vec2(10, 20);
            let v2: Vec2 = new Vec2(5, 5);
            let result: Vec2 = v1.add(v2);
            expect(result.x).assertEqual(15);
            expect(result.y).assertEqual(25);
        });
        // 2. 测试 Vec3 的点积 (Dot Product)
        it('Vec3_Dot_Success', 0, () => {
            let v1: Vec3 = new Vec3(1, 0, 0);
            let v2: Vec3 = new Vec3(0, 1, 0);
            let resultZero: number = v1.dot(v2);
            expect(resultZero).assertEqual(0);
            let v3: Vec3 = new Vec3(2, 2, 2);
            let resultVal: number = v1.dot(v3);
            expect(resultVal).assertEqual(2);
        });
        // 3. 测试 Vec3 的叉积 (Cross Product)
        it('Vec3_Cross_Success', 0, () => {
            let v1: Vec3 = new Vec3(1, 0, 0);
            let v2: Vec3 = new Vec3(0, 1, 0);
            let result: Vec3 = v1.cross(v2);
            expect(result.x).assertEqual(0);
            expect(result.y).assertEqual(0);
            expect(result.z).assertEqual(1);
        });
        // 4. 测试 Vec4 的归一化 (Normalize)
        it('Vec4_Normalize_Success', 0, () => {
            let v: Vec4 = new Vec4(0, 10, 0, 0);
            let normalized: Vec4 = v.normalize();
            expect(normalized.x).assertEqual(0);
            expect(normalized.y).assertEqual(1);
            expect(normalized.z).assertEqual(0);
            expect(normalized.w).assertEqual(0);
            // v0.5.0 中 length() 返回 number | Vec4，无参调用返回 number
            expect(normalized.length() as number).assertEqual(1);
        });
        // 5. 测试 Mat33 的转置 (Transpose)
        it('Mat33_Transpose_Success', 0, () => {
            let mat: Mat33 = new Mat33([
                1, 2, 3,
                4, 5, 6,
                7, 8, 9
            ]);
            let trans: Mat33 = mat.transpose();
            expect(trans.data[0]).assertEqual(1);
            expect(trans.data[1]).assertEqual(4);
            expect(trans.data[2]).assertEqual(7);
            expect(trans.data[3]).assertEqual(2);
        });
        // 6. 测试 Mat44 的矩阵乘法
        it('Mat44_Mult_Identity_Success', 0, () => {
            let mat: Mat44 = new Mat44([
                1, 2, 3, 4,
                5, 6, 7, 8,
                9, 10, 11, 12,
                13, 14, 15, 16
            ]);
            let identity: Mat44 = Mat44.identity();
            // Fix for v0.5.0: 使用 multMat44 替代 mult
            let result: Mat44 = mat.multMat44(identity);
            for (let i = 0; i < 16; i++) {
                expect(result.data[i]).assertEqual(mat.data[i]);
            }
        });
        // 7. 测试 Mat44 的平移矩阵构建
        it('Mat44_Translation_Construction', 0, () => {
            let transVec: Vec3 = new Vec3(10, 20, 30);
            let mat: Mat44 = Mat44.translation(transVec);
            expect(mat.data[12]).assertEqual(10);
            expect(mat.data[13]).assertEqual(20);
            expect(mat.data[14]).assertEqual(30);
            expect(mat.data[15]).assertEqual(1);
        });
        // 8. 测试 Quaternion (四元数) 旋转向量
        it('Quaternion_Rotate_Vector', 0, () => {
            // v0.5.0 支持 rotationDegrees (v0.6.0 移除)
            let q: Quaternion = Quaternion.rotationDegrees(90, new Vec3(0, 1, 0));
            let v: Vec3 = new Vec3(1, 0, 0);
            let result: Vec3 = q.rotate(v);
            expect(Math.abs(result.x) < 0.0001).assertTrue();
            expect(Math.abs(result.y) < 0.0001).assertTrue();
            expect(Math.abs(result.z - (-1)) < 0.0001).assertTrue();
        });
        // 9. 测试 Triangle 的法线计算
        it('Triangle_Normal_Success', 0, () => {
            let t: Triangle = new Triangle(new Vec3(0, 0, 0), new Vec3(1, 0, 0), new Vec3(0, 1, 0));
            let normal: Vec3 = t.normal();
            expect(normal.x).assertEqual(0);
            expect(normal.y).assertEqual(0);
            expect(normal.z).assertEqual(1);
        });
        // 10. 测试 Transform 类的默认值与矩阵生成
        it('Transform_Defaults_And_Matrix', 0, () => {
            let t: Transform = Transform.identity();
            // Fix for v0.5.0: Transform 属性改为 public 访问，不再是 getter 方法
            let origin: Vec3 = t.origin;
            expect(origin.x).assertEqual(0);
            expect(origin.y).assertEqual(0);
            expect(origin.z).assertEqual(0);
            // Fix for v0.5.0: 直接赋值
            t.origin = new Vec3(5, 5, 5);
            let mat: Mat44 = t.matrix();
            expect(mat.data[12]).assertEqual(5);
            expect(mat.data[13]).assertEqual(5);
            expect(mat.data[14]).assertEqual(5);
        });
    });
}
