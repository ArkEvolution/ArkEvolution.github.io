import { EPSILON } from "@normalized:N&&&alfador/src/main/ets/src/Epsilon&0.4.7";
class Vec2 {
    x: number;
    y: number;
    constructor(x?: number | Vec2 | number[], y?: number) {
        if (x instanceof Vec2) {
            this.x = x.x;
            this.y = x.y;
        }
        else if (x instanceof Array) {
            this.x = x[0];
            this.y = x[1];
        }
        else if (typeof x === 'number') {
            this.x = x;
            this.y = y || 0.0;
        }
        else {
            this.x = 0.0;
            this.y = 0.0;
        }
    }
    negate(): Vec2 {
        return new Vec2(-this.x, -this.y);
    }
    add(that: Vec2 | number[]): Vec2 {
        if (that instanceof Array) {
            return new Vec2(this.x + that[0], this.y + that[1]);
        }
        return new Vec2(this.x + that.x, this.y + that.y);
    }
    sub(that: Vec2 | number[]): Vec2 {
        if (that instanceof Array) {
            return new Vec2(this.x - that[0], this.y - that[1]);
        }
        return new Vec2(this.x - that.x, this.y - that.y);
    }
    multScalar(that: number): Vec2 {
        return new Vec2(this.x * that, this.y * that);
    }
    divScalar(that: number): Vec2 {
        return new Vec2(this.x / that, this.y / that);
    }
    dot(that: Vec2 | number[]): number {
        if (that instanceof Array) {
            return (this.x * that[0]) + (this.y * that[1]);
        }
        return (this.x * that.x) + (this.y * that.y);
    }
    cross(that: Vec2 | number[]): number {
        if (that instanceof Array) {
            return (this.x * that[1]) - (this.y * that[0]);
        }
        return (this.x * that.y) - (this.y * that.x);
    }
    length(length?: number): number | Vec2 {
        if (length === undefined) {
            let len = this.dot(this);
            if (Math.abs(len - 1.0) < EPSILON) {
                return len;
            }
            else {
                return Math.sqrt(len);
            }
        }
        return this.normalize().multScalar(length);
    }
    lengthSquared(): number {
        return this.dot(this);
    }
    equals(that: Vec2 | number[], epsilon?: number): boolean {
        let x: number;
        let y: number;
        if (that instanceof Array) {
            x = that[0];
            y = that[1];
        }
        else {
            x = that.x;
            y = that.y;
        }
        epsilon = epsilon === undefined ? 0 : epsilon;
        return (this.x === x || Math.abs(this.x - x) <= epsilon) &&
            (this.y === y || Math.abs(this.y - y) <= epsilon);
    }
    normalize(): Vec2 {
        const mag = this.length() as number;
        if (mag !== 0) {
            return new Vec2(this.x / mag, this.y / mag);
        }
        return new Vec2();
    }
    unsignedAngleRadians(that: Vec2 | number[]): number {
        let x: number;
        let y: number;
        if (that instanceof Array) {
            x = that[0];
            y = that[1];
        }
        else {
            x = that.x;
            y = that.y;
        }
        let angle = Math.atan2(y, x) - Math.atan2(this.y, this.x);
        if (angle < 0) {
            angle += 2 * Math.PI;
        }
        return angle;
    }
    unsignedAngleDegrees(that: Vec2 | number[]): number {
        return this.unsignedAngleRadians(that) * (180 / Math.PI);
    }
    toString(): string {
        return this.x + ", " + this.y;
    }
    toArray(): number[] {
        return [this.x, this.y];
    }
    static random(): Vec2 {
        return new Vec2(Math.random(), Math.random()).normalize();
    }
}
export default Vec2;
