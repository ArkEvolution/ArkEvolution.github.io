import Vec3 from "@normalized:N&&&alfador/src/main/ets/src/Vec3&0.4.7";
import Mat33 from "@normalized:N&&&alfador/src/main/ets/src/Mat33&0.4.7";
class Quaternion {
    w: number;
    x: number;
    y: number;
    z: number;
    constructor(w?: number | Quaternion | number[], x?: number, y?: number, z?: number) {
        if (w instanceof Quaternion) {
            this.w = w.w;
            this.x = w.x;
            this.y = w.y;
            this.z = w.z;
        }
        else if (w instanceof Array) {
            this.w = w[0];
            this.x = w[1];
            this.y = w[2];
            this.z = w[3];
        }
        else if (typeof w === 'number') {
            this.w = w;
            this.x = x || 0.0;
            this.y = y || 0.0;
            this.z = z || 0.0;
        }
        else {
            this.w = 1.0;
            this.x = 0.0;
            this.y = 0.0;
            this.z = 0.0;
        }
    }
    negate(): Quaternion {
        return new Quaternion(-this.w, -this.x, -this.y, -this.z);
    }
    multQuat(that: Quaternion | number[]): Quaternion {
        const q = (that instanceof Array) ? new Quaternion(that) : that;
        const w = (q.w * this.w) - (q.x * this.x) - (q.y * this.y) - (q.z * this.z);
        const x = this.y * q.z - this.z * q.y + this.w * q.x + this.x * q.w;
        const y = this.z * q.x - this.x * q.z + this.w * q.y + this.y * q.w;
        const z = this.x * q.y - this.y * q.x + this.w * q.z + this.z * q.w;
        return new Quaternion(w, x, y, z);
    }
    rotate(that: Vec3 | number[]): Vec3 {
        const v = (that instanceof Array) ? new Vec3(that) : that;
        const vq = new Quaternion(0, v.x, v.y, v.z);
        const r = this.multQuat(vq).multQuat(this.inverse());
        return new Vec3(r.x, r.y, r.z);
    }
    matrix(): Mat33 {
        const xx = this.x * this.x;
        const yy = this.y * this.y;
        const zz = this.z * this.z;
        const xy = this.x * this.y;
        const xz = this.x * this.z;
        const xw = this.x * this.w;
        const yz = this.y * this.z;
        const yw = this.y * this.w;
        const zw = this.z * this.w;
        return new Mat33([
            1 - 2 * yy - 2 * zz, 2 * xy + 2 * zw, 2 * xz - 2 * yw,
            2 * xy - 2 * zw, 1 - 2 * xx - 2 * zz, 2 * yz + 2 * xw,
            2 * xz + 2 * yw, 2 * yz - 2 * xw, 1 - 2 * xx - 2 * yy
        ]);
    }
    equals(that: Quaternion | number[], epsilon?: number): boolean {
        let w: number;
        let x: number;
        let y: number;
        let z: number;
        if (that instanceof Array) {
            w = that[0];
            x = that[1];
            y = that[2];
            z = that[3];
        }
        else {
            w = that.w;
            x = that.x;
            y = that.y;
            z = that.z;
        }
        epsilon = epsilon === undefined ? 0 : epsilon;
        return (this.w === w || Math.abs(this.w - w) <= epsilon) &&
            (this.x === x || Math.abs(this.x - x) <= epsilon) &&
            (this.y === y || Math.abs(this.y - y) <= epsilon) &&
            (this.z === z || Math.abs(this.z - z) <= epsilon);
    }
    normalize(): Quaternion {
        const mag = Math.sqrt(this.x * this.x +
            this.y * this.y +
            this.z * this.z +
            this.w * this.w);
        if (mag !== 0) {
            return new Quaternion(this.w / mag, this.x / mag, this.y / mag, this.z / mag);
        }
        return new Quaternion();
    }
    conjugate(): Quaternion {
        return new Quaternion(this.w, -this.x, -this.y, -this.z);
    }
    inverse(): Quaternion {
        return this.conjugate();
    }
    toString(): string {
        return this.x + ', ' + this.y + ', ' + this.z + ', ' + this.w;
    }
    toArray(): number[] {
        return [this.w, this.x, this.y, this.z];
    }
    static identity(): Quaternion {
        return new Quaternion(1, 0, 0, 0);
    }
    static rotationDegrees(angle: number, axis: Vec3 | number[]): Quaternion {
        return Quaternion.rotationRadians(angle * (Math.PI / 180), axis);
    }
    static rotationRadians(angle: number, axis: Vec3 | number[]): Quaternion {
        const axisVec = (axis instanceof Array) ? new Vec3(axis) : axis;
        const normAxis = axisVec.normalize();
        // set quaternion for the equivolent rotation
        const modAngle = (angle > 0) ? angle % (2 * Math.PI) : angle % (-2 * Math.PI);
        const sina = Math.sin(modAngle / 2);
        const cosa = Math.cos(modAngle / 2);
        return new Quaternion(cosa, normAxis.x * sina, normAxis.y * sina, normAxis.z * sina).normalize();
    }
    static slerp(fromRot: Quaternion | number[], toRot: Quaternion | number[], t: number): Quaternion {
        let f = (fromRot instanceof Array) ? new Quaternion(fromRot) : fromRot;
        const to = (toRot instanceof Array) ? new Quaternion(toRot) : toRot;
        // calculate angle between
        let cosHalfTheta = (f.w * to.w) + (f.x * to.x) + (f.y * to.y) + (f.z * to.z);
        // cosHalfTheta must be positive to return the shortest angle
        if (cosHalfTheta < 0) {
            f = f.negate();
            cosHalfTheta = -cosHalfTheta;
        }
        const halfTheta = Math.acos(cosHalfTheta);
        const sinHalfTheta = Math.sqrt(1 - cosHalfTheta * cosHalfTheta);
        const scaleFrom = Math.sin((1.0 - t) * halfTheta) / sinHalfTheta;
        const scaleTo = Math.sin(t * halfTheta) / sinHalfTheta;
        return new Quaternion(f.w * scaleFrom + to.w * scaleTo, f.x * scaleFrom + to.x * scaleTo, f.y * scaleFrom + to.y * scaleTo, f.z * scaleFrom + to.z * scaleTo);
    }
    static random(): Quaternion {
        const axis = Vec3.random().normalize();
        const angle = Math.random();
        return Quaternion.rotationRadians(angle, axis);
    }
}
export default Quaternion;
