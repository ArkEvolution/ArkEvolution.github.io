import Vec3 from "@normalized:N&&&alfador/src/main/ets/src/Vec3&0.4.7";
import Vec4 from "@normalized:N&&&alfador/src/main/ets/src/Vec4&0.4.7";
import Mat33 from "@normalized:N&&&alfador/src/main/ets/src/Mat33&0.4.7";
import Mat44 from "@normalized:N&&&alfador/src/main/ets/src/Mat44&0.4.7";
export interface TransformParams {
    up?: Vec3;
    forward?: Vec3;
    left?: Vec3;
    origin?: Vec3;
    scale?: Vec3 | number;
}
class Transform {
    up: Vec3;
    forward: Vec3;
    left: Vec3;
    origin: Vec3;
    scale: Vec3;
    constructor(that?: Transform | Mat33 | Mat44 | TransformParams) {
        // Default initialization
        this.up = new Vec3(0, 1, 0);
        this.forward = new Vec3(0, 0, 1);
        this.left = new Vec3(1, 0, 0);
        this.origin = new Vec3(0, 0, 0);
        this.scale = new Vec3(1, 1, 1);
        if (that) {
            if (that instanceof Transform) {
                this.up = new Vec3(that.up);
                this.forward = new Vec3(that.forward);
                this.left = new Vec3(that.left);
                this.origin = new Vec3(that.origin);
                this.scale = new Vec3(that.scale);
            }
            else if (that instanceof Mat33 || that instanceof Mat44) {
                const decomposed = that.decompose();
                this.up = decomposed["up"];
                this.forward = decomposed["forward"];
                this.left = decomposed["left"];
                this.scale = decomposed["scale"];
                if (that instanceof Mat44) {
                    this.origin = decomposed["origin"];
                }
            }
            else {
                // TransformParams
                // Fix: Using 'as' keyword for explicit casting to interface
                const obj = that as TransformParams;
                if (obj.up)
                    this.up = new Vec3(obj.up).normalize();
                if (obj.forward)
                    this.forward = new Vec3(obj.forward).normalize();
                if (obj.left)
                    this.left = new Vec3(obj.left).normalize();
                else
                    this.left = this.up.cross(this.forward).normalize();
                if (obj.origin)
                    this.origin = new Vec3(obj.origin);
                if (obj.scale !== undefined) {
                    if (typeof obj.scale === 'number') {
                        this.scale = new Vec3(obj.scale, obj.scale, obj.scale);
                    }
                    else {
                        this.scale = new Vec3(obj.scale);
                    }
                }
            }
        }
    }
    rotateForwardTo(forward: Vec3 | number[]): Transform {
        const fwd = (forward instanceof Array) ? new Vec3(forward).normalize() : forward.normalize();
        const rot = Mat33.rotationFromTo(this.forward, fwd);
        this.forward = fwd;
        this.up = rot.multVec3(this.up).normalize();
        this.left = rot.multVec3(this.left).normalize();
        return this;
    }
    rotateUpTo(up: Vec3 | number[]): Transform {
        const u = (up instanceof Array) ? new Vec3(up).normalize() : up.normalize();
        const rot = Mat33.rotationFromTo(this.up, u);
        this.forward = rot.multVec3(this.forward).normalize();
        this.up = u;
        this.left = rot.multVec3(this.left).normalize();
        return this;
    }
    rotateLeftTo(left: Vec3 | number[]): Transform {
        const l = (left instanceof Array) ? new Vec3(left).normalize() : left.normalize();
        const rot = Mat33.rotationFromTo(this.left, l);
        this.forward = rot.multVec3(this.forward).normalize();
        this.up = rot.multVec3(this.up).normalize();
        this.left = l;
        return this;
    }
    scaleMatrix(): Mat44 {
        return Mat44.scale(this.scale);
    }
    rotationMatrix(): Mat44 {
        return new Mat44([
            this.left.x, this.left.y, this.left.z, 0,
            this.up.x, this.up.y, this.up.z, 0,
            this.forward.x, this.forward.y, this.forward.z, 0,
            0, 0, 0, 1
        ]);
    }
    translationMatrix(): Mat44 {
        return Mat44.translation(this.origin);
    }
    matrix(): Mat44 {
        // T * R * S
        return this.translationMatrix()
            .multMat44(this.rotationMatrix())
            .multMat44(this.scaleMatrix());
    }
    inverseScaleMatrix(): Mat44 {
        return Mat44.scale(new Vec3(1 / this.scale.x, 1 / this.scale.y, 1 / this.scale.z));
    }
    inverseRotationMatrix(): Mat44 {
        return new Mat44([
            this.left.x, this.up.x, this.forward.x, 0,
            this.left.y, this.up.y, this.forward.y, 0,
            this.left.z, this.up.z, this.forward.z, 0,
            0, 0, 0, 1
        ]);
    }
    inverseTranslationMatrix(): Mat44 {
        return Mat44.translation(this.origin.negate());
    }
    inverseMatrix(): Mat44 {
        // S^-1 * R^-1 * T^-1
        return this.inverseScaleMatrix()
            .multMat44(this.inverseRotationMatrix())
            .multMat44(this.inverseTranslationMatrix());
    }
    viewMatrix(): Mat44 {
        const nOrigin = this.origin.negate();
        const right = this.left.negate();
        const backward = this.forward.negate();
        return new Mat44([
            right.x, this.up.x, backward.x, 0,
            right.y, this.up.y, backward.y, 0,
            right.z, this.up.z, backward.z, 0,
            nOrigin.dot(right), nOrigin.dot(this.up), nOrigin.dot(backward), 1
        ]);
    }
    translateWorld(translation: Vec3): Transform {
        this.origin = this.origin.add(translation);
        return this;
    }
    translateLocal(translation: Vec3 | number[]): Transform {
        const t = (translation instanceof Array) ? new Vec3(translation) : translation;
        this.origin = this.origin.add(this.left.multScalar(t.x))
            .add(this.up.multScalar(t.y))
            .add(this.forward.multScalar(t.z));
        return this;
    }
    rotateWorldDegrees(angle: number, axis: Vec3): Transform {
        return this.rotateWorldRadians(angle * Math.PI / 180, axis);
    }
    rotateWorldRadians(angle: number, axis: Vec3): Transform {
        const rot = Mat33.rotationRadians(angle, axis);
        this.up = rot.multVec3(this.up);
        this.forward = rot.multVec3(this.forward);
        this.left = rot.multVec3(this.left);
        return this;
    }
    rotateLocalDegrees(angle: number, axis: Vec3): Transform {
        return this.rotateWorldDegrees(angle, this.rotationMatrix().multVec3(axis));
    }
    rotateLocalRadians(angle: number, axis: Vec3): Transform {
        return this.rotateWorldRadians(angle, this.rotationMatrix().multVec3(axis));
    }
    localToWorld(vec: Vec3 | Vec4, ignoreScale?: boolean, ignoreRotation?: boolean, ignoreTranslation?: boolean): Vec3 | Vec4 {
        let mat = new Mat44(); // Identity
        if (!ignoreScale) {
            mat = this.scaleMatrix().multMat44(mat);
        }
        if (!ignoreRotation) {
            mat = this.rotationMatrix().multMat44(mat);
        }
        if (!ignoreTranslation) {
            mat = this.translationMatrix().multMat44(mat);
        }
        if (vec instanceof Vec4) {
            return mat.multVec4(vec);
        }
        return mat.multVec3(vec as Vec3);
    }
    worldToLocal(vec: Vec3 | Vec4, ignoreScale?: boolean, ignoreRotation?: boolean, ignoreTranslation?: boolean): Vec3 | Vec4 {
        let mat = new Mat44();
        if (!ignoreTranslation) {
            mat = this.inverseTranslationMatrix().multMat44(mat);
        }
        if (!ignoreRotation) {
            mat = this.inverseRotationMatrix().multMat44(mat);
        }
        if (!ignoreScale) {
            mat = this.inverseScaleMatrix().multMat44(mat);
        }
        if (vec instanceof Vec4) {
            return mat.multVec4(vec);
        }
        return mat.multVec3(vec as Vec3);
    }
    equals(that: Transform, epsilon?: number): boolean {
        return this.origin.equals(that.origin, epsilon) &&
            this.forward.equals(that.forward, epsilon) &&
            this.up.equals(that.up, epsilon) &&
            this.left.equals(that.left, epsilon) &&
            this.scale.equals(that.scale, epsilon);
    }
    toString(): string {
        return this.matrix().toString();
    }
    static identity(): Transform {
        return new Transform();
    }
    static random(): Transform {
        // Fix: Explicitly declare the type for the object literal to satisfy strict ArkTS checks
        const params: TransformParams = {
            origin: Vec3.random(),
            scale: Vec3.random()
        };
        const transform = new Transform(params);
        return transform.rotateForwardTo(Vec3.random());
    }
}
export default Transform;
