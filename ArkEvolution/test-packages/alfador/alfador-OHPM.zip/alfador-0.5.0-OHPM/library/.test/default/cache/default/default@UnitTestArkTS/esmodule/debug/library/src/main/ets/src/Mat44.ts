import Vec3 from "@normalized:N&&&alfador/src/main/ets/src/Vec3&0.4.7";
import Vec4 from "@normalized:N&&&alfador/src/main/ets/src/Vec4&0.4.7";
import Mat33 from "@normalized:N&&&alfador/src/main/ets/src/Mat33&0.4.7";
import { EPSILON } from "@normalized:N&&&alfador/src/main/ets/src/Epsilon&0.4.7";
class Mat44 {
    data: number[];
    constructor(that?: number[] | Mat44 | Mat33) {
        let source: number[] | undefined;
        if (that) {
            if (that instanceof Array) {
                source = that;
            }
            else if (that instanceof Mat44) {
                source = that.data;
            }
            else if (that instanceof Mat33) {
                // Mat33 to Mat44
                source = [
                    that.data[0], that.data[1], that.data[2], 0,
                    that.data[3], that.data[4], that.data[5], 0,
                    that.data[6], that.data[7], that.data[8], 0,
                    0, 0, 0, 1
                ];
            }
        }
        if (!source) {
            this.data = [
                1, 0, 0, 0,
                0, 1, 0, 0,
                0, 0, 1, 0,
                0, 0, 0, 1
            ];
        }
        else {
            if (source.length === 16) {
                this.data = source.slice(0);
            }
            else {
                this.data = new Array(16);
                for (let i = 0; i < 16; i++) {
                    this.data[i] = source[i]; // Potentially unsafe if source < 16, but handled by Mat33 logic above
                }
            }
        }
    }
    row(index: number, vec?: Vec3 | number[] | Vec4): Vec4 | Mat44 {
        if (vec) {
            const v: number[] = (vec instanceof Array) ? vec : (vec instanceof Vec4 ? [vec.x, vec.y, vec.z, vec.w] : [vec.x, vec.y, vec.z, 0]);
            this.data[0 + index] = v[0];
            this.data[4 + index] = v[1];
            this.data[8 + index] = v[2];
            this.data[12 + index] = v[3] !== undefined ? v[3] : 0;
            return this;
        }
        return new Vec4(this.data[0 + index], this.data[4 + index], this.data[8 + index], this.data[12 + index]);
    }
    col(index: number, vec?: Vec3 | number[] | Vec4): Vec4 | Mat44 {
        if (vec) {
            const v: number[] = (vec instanceof Array) ? vec : (vec instanceof Vec4 ? [vec.x, vec.y, vec.z, vec.w] : [vec.x, vec.y, vec.z, 0]);
            this.data[0 + index * 4] = v[0];
            this.data[1 + index * 4] = v[1];
            this.data[2 + index * 4] = v[2];
            this.data[3 + index * 4] = v[3] !== undefined ? v[3] : 0;
            return this;
        }
        return new Vec4(this.data[0 + index * 4], this.data[1 + index * 4], this.data[2 + index * 4], this.data[3 + index * 4]);
    }
    addMat33(that: Mat33 | number[]): Mat44 {
        const d = (that instanceof Array) ? that : that.data;
        return new Mat44([
            this.data[0] + d[0],
            this.data[1] + d[1],
            this.data[2] + d[2],
            this.data[3],
            this.data[4] + d[3],
            this.data[5] + d[4],
            this.data[6] + d[5],
            this.data[7],
            this.data[8] + d[6],
            this.data[9] + d[7],
            this.data[10] + d[8],
            this.data[11],
            this.data[12],
            this.data[13],
            this.data[14],
            this.data[15]
        ]);
    }
    addMat44(that: Mat44 | number[]): Mat44 {
        const d = (that instanceof Array) ? that : that.data;
        return new Mat44([
            this.data[0] + d[0],
            this.data[1] + d[1],
            this.data[2] + d[2],
            this.data[3] + d[3],
            this.data[4] + d[4],
            this.data[5] + d[5],
            this.data[6] + d[6],
            this.data[7] + d[7],
            this.data[8] + d[8],
            this.data[9] + d[9],
            this.data[10] + d[10],
            this.data[11] + d[11],
            this.data[12] + d[12],
            this.data[13] + d[13],
            this.data[14] + d[14],
            this.data[15] + d[15],
        ]);
    }
    subMat33(that: Mat33 | number[]): Mat44 {
        const d = (that instanceof Array) ? that : that.data;
        return new Mat44([
            this.data[0] - d[0],
            this.data[1] - d[1],
            this.data[2] - d[2],
            this.data[3],
            this.data[4] - d[3],
            this.data[5] - d[4],
            this.data[6] - d[5],
            this.data[7],
            this.data[8] - d[6],
            this.data[9] - d[7],
            this.data[10] - d[8],
            this.data[11],
            this.data[12],
            this.data[13],
            this.data[14],
            this.data[15]
        ]);
    }
    subMat44(that: Mat44 | number[]): Mat44 {
        const d = (that instanceof Array) ? that : that.data;
        return new Mat44([
            this.data[0] - d[0],
            this.data[1] - d[1],
            this.data[2] - d[2],
            this.data[3] - d[3],
            this.data[4] - d[4],
            this.data[5] - d[5],
            this.data[6] - d[6],
            this.data[7] - d[7],
            this.data[8] - d[8],
            this.data[9] - d[9],
            this.data[10] - d[10],
            this.data[11] - d[11],
            this.data[12] - d[12],
            this.data[13] - d[13],
            this.data[14] - d[14],
            this.data[15] - d[15],
        ]);
    }
    multVec3(that: Vec3 | number[]): Vec3 {
        if (that instanceof Array) {
            return new Vec3(this.data[0] * that[0] + this.data[4] * that[1] + this.data[8] * that[2] + this.data[12], this.data[1] * that[0] + this.data[5] * that[1] + this.data[9] * that[2] + this.data[13], this.data[2] * that[0] + this.data[6] * that[1] + this.data[10] * that[2] + this.data[14]);
        }
        return new Vec3(this.data[0] * that.x + this.data[4] * that.y + this.data[8] * that.z + this.data[12], this.data[1] * that.x + this.data[5] * that.y + this.data[9] * that.z + this.data[13], this.data[2] * that.x + this.data[6] * that.y + this.data[10] * that.z + this.data[14]);
    }
    multVec4(that: Vec4 | number[]): Vec4 {
        if (that instanceof Array) {
            return new Vec4(this.data[0] * that[0] + this.data[4] * that[1] + this.data[8] * that[2] + this.data[12] * that[3], this.data[1] * that[0] + this.data[5] * that[1] + this.data[9] * that[2] + this.data[13] * that[3], this.data[2] * that[0] + this.data[6] * that[1] + this.data[10] * that[2] + this.data[14] * that[3], this.data[3] * that[0] + this.data[7] * that[1] + this.data[11] * that[2] + this.data[15] * that[3]);
        }
        return new Vec4(this.data[0] * that.x + this.data[4] * that.y + this.data[8] * that.z + this.data[12] * that.w, this.data[1] * that.x + this.data[5] * that.y + this.data[9] * that.z + this.data[13] * that.w, this.data[2] * that.x + this.data[6] * that.y + this.data[10] * that.z + this.data[14] * that.w, this.data[3] * that.x + this.data[7] * that.y + this.data[11] * that.z + this.data[15] * that.w);
    }
    multScalar(that: number): Mat44 {
        return new Mat44([
            this.data[0] * that,
            this.data[1] * that,
            this.data[2] * that,
            this.data[3] * that,
            this.data[4] * that,
            this.data[5] * that,
            this.data[6] * that,
            this.data[7] * that,
            this.data[8] * that,
            this.data[9] * that,
            this.data[10] * that,
            this.data[11] * that,
            this.data[12] * that,
            this.data[13] * that,
            this.data[14] * that,
            this.data[15] * that
        ]);
    }
    multMat33(that: Mat33 | number[]): Mat44 {
        const d = (that instanceof Array) ? that : that.data;
        return new Mat44([
            this.data[0] * d[0] + this.data[4] * d[1] + this.data[8] * d[2],
            this.data[1] * d[0] + this.data[5] * d[1] + this.data[9] * d[2],
            this.data[2] * d[0] + this.data[6] * d[1] + this.data[10] * d[2],
            this.data[3] * d[0] + this.data[7] * d[1] + this.data[11] * d[2],
            this.data[0] * d[3] + this.data[4] * d[4] + this.data[8] * d[5],
            this.data[1] * d[3] + this.data[5] * d[4] + this.data[9] * d[5],
            this.data[2] * d[3] + this.data[6] * d[4] + this.data[10] * d[5],
            this.data[3] * d[3] + this.data[7] * d[4] + this.data[11] * d[5],
            this.data[0] * d[6] + this.data[4] * d[7] + this.data[8] * d[8],
            this.data[1] * d[6] + this.data[5] * d[7] + this.data[9] * d[8],
            this.data[2] * d[6] + this.data[6] * d[7] + this.data[10] * d[8],
            this.data[3] * d[6] + this.data[7] * d[7] + this.data[11] * d[8],
            this.data[12],
            this.data[13],
            this.data[14],
            this.data[15]
        ]);
    }
    multMat44(that: Mat44 | number[]): Mat44 {
        const d = (that instanceof Array) ? that : that.data;
        return new Mat44([
            this.data[0] * d[0] + this.data[4] * d[1] + this.data[8] * d[2] + this.data[12] * d[3],
            this.data[1] * d[0] + this.data[5] * d[1] + this.data[9] * d[2] + this.data[13] * d[3],
            this.data[2] * d[0] + this.data[6] * d[1] + this.data[10] * d[2] + this.data[14] * d[3],
            this.data[3] * d[0] + this.data[7] * d[1] + this.data[11] * d[2] + this.data[15] * d[3],
            this.data[0] * d[4] + this.data[4] * d[5] + this.data[8] * d[6] + this.data[12] * d[7],
            this.data[1] * d[4] + this.data[5] * d[5] + this.data[9] * d[6] + this.data[13] * d[7],
            this.data[2] * d[4] + this.data[6] * d[5] + this.data[10] * d[6] + this.data[14] * d[7],
            this.data[3] * d[4] + this.data[7] * d[5] + this.data[11] * d[6] + this.data[15] * d[7],
            this.data[0] * d[8] + this.data[4] * d[9] + this.data[8] * d[10] + this.data[12] * d[11],
            this.data[1] * d[8] + this.data[5] * d[9] + this.data[9] * d[10] + this.data[13] * d[11],
            this.data[2] * d[8] + this.data[6] * d[9] + this.data[10] * d[10] + this.data[14] * d[11],
            this.data[3] * d[8] + this.data[7] * d[9] + this.data[11] * d[10] + this.data[15] * d[11],
            this.data[0] * d[12] + this.data[4] * d[13] + this.data[8] * d[14] + this.data[12] * d[15],
            this.data[1] * d[12] + this.data[5] * d[13] + this.data[9] * d[14] + this.data[13] * d[15],
            this.data[2] * d[12] + this.data[6] * d[13] + this.data[10] * d[14] + this.data[14] * d[15],
            this.data[3] * d[12] + this.data[7] * d[13] + this.data[11] * d[14] + this.data[15] * d[15]
        ]);
    }
    divScalar(that: number): Mat44 {
        return new Mat44([
            this.data[0] / that,
            this.data[1] / that,
            this.data[2] / that,
            this.data[3] / that,
            this.data[4] / that,
            this.data[5] / that,
            this.data[6] / that,
            this.data[7] / that,
            this.data[8] / that,
            this.data[9] / that,
            this.data[10] / that,
            this.data[11] / that,
            this.data[12] / that,
            this.data[13] / that,
            this.data[14] / that,
            this.data[15] / that
        ]);
    }
    equals(that: Mat44 | number[], epsilon?: number): boolean {
        const d = (that instanceof Array) ? that : that.data;
        epsilon = epsilon === undefined ? 0 : epsilon;
        for (let i = 0; i < 16; i++) {
            if (!((this.data[i] === d[i]) || (Math.abs(this.data[i] - d[i]) <= epsilon))) {
                return false;
            }
        }
        return true;
    }
    transpose(): Mat44 {
        return new Mat44([
            this.data[0],
            this.data[4],
            this.data[8],
            this.data[12],
            this.data[1],
            this.data[5],
            this.data[9],
            this.data[13],
            this.data[2],
            this.data[6],
            this.data[10],
            this.data[14],
            this.data[3],
            this.data[7],
            this.data[11],
            this.data[15]
        ]);
    }
    inverse(): Mat44 {
        // col 0
        const m00 = this.data[5] * this.data[10] * this.data[15] - this.data[5] * this.data[11] * this.data[14] - this.data[9] * this.data[6] * this.data[15] + this.data[9] * this.data[7] * this.data[14] + this.data[13] * this.data[6] * this.data[11] - this.data[13] * this.data[7] * this.data[10];
        const m10 = -this.data[1] * this.data[10] * this.data[15] + this.data[1] * this.data[11] * this.data[14] + this.data[9] * this.data[2] * this.data[15] - this.data[9] * this.data[3] * this.data[14] - this.data[13] * this.data[2] * this.data[11] + this.data[13] * this.data[3] * this.data[10];
        const m20 = this.data[1] * this.data[6] * this.data[15] - this.data[1] * this.data[7] * this.data[14] - this.data[5] * this.data[2] * this.data[15] + this.data[5] * this.data[3] * this.data[14] + this.data[13] * this.data[2] * this.data[7] - this.data[13] * this.data[3] * this.data[6];
        const m30 = -this.data[1] * this.data[6] * this.data[11] + this.data[1] * this.data[7] * this.data[10] + this.data[5] * this.data[2] * this.data[11] - this.data[5] * this.data[3] * this.data[10] - this.data[9] * this.data[2] * this.data[7] + this.data[9] * this.data[3] * this.data[6];
        // col 1
        const m01 = -this.data[4] * this.data[10] * this.data[15] + this.data[4] * this.data[11] * this.data[14] + this.data[8] * this.data[6] * this.data[15] - this.data[8] * this.data[7] * this.data[14] - this.data[12] * this.data[6] * this.data[11] + this.data[12] * this.data[7] * this.data[10];
        const m11 = this.data[0] * this.data[10] * this.data[15] - this.data[0] * this.data[11] * this.data[14] - this.data[8] * this.data[2] * this.data[15] + this.data[8] * this.data[3] * this.data[14] + this.data[12] * this.data[2] * this.data[11] - this.data[12] * this.data[3] * this.data[10];
        const m21 = -this.data[0] * this.data[6] * this.data[15] + this.data[0] * this.data[7] * this.data[14] + this.data[4] * this.data[2] * this.data[15] - this.data[4] * this.data[3] * this.data[14] - this.data[12] * this.data[2] * this.data[7] + this.data[12] * this.data[3] * this.data[6];
        const m31 = this.data[0] * this.data[6] * this.data[11] - this.data[0] * this.data[7] * this.data[10] - this.data[4] * this.data[2] * this.data[11] + this.data[4] * this.data[3] * this.data[10] + this.data[8] * this.data[2] * this.data[7] - this.data[8] * this.data[3] * this.data[6];
        // col 2
        const m02 = this.data[4] * this.data[9] * this.data[15] - this.data[4] * this.data[11] * this.data[13] - this.data[8] * this.data[5] * this.data[15] + this.data[8] * this.data[7] * this.data[13] + this.data[12] * this.data[5] * this.data[11] - this.data[12] * this.data[7] * this.data[9];
        const m12 = -this.data[0] * this.data[9] * this.data[15] + this.data[0] * this.data[11] * this.data[13] + this.data[8] * this.data[1] * this.data[15] - this.data[8] * this.data[3] * this.data[13] - this.data[12] * this.data[1] * this.data[11] + this.data[12] * this.data[3] * this.data[9];
        const m22 = this.data[0] * this.data[5] * this.data[15] - this.data[0] * this.data[7] * this.data[13] - this.data[4] * this.data[1] * this.data[15] + this.data[4] * this.data[3] * this.data[13] + this.data[12] * this.data[1] * this.data[7] - this.data[12] * this.data[3] * this.data[5];
        const m32 = -this.data[0] * this.data[5] * this.data[11] + this.data[0] * this.data[7] * this.data[9] + this.data[4] * this.data[1] * this.data[11] - this.data[4] * this.data[3] * this.data[9] - this.data[8] * this.data[1] * this.data[7] + this.data[8] * this.data[3] * this.data[5];
        // col 3
        const m03 = -this.data[4] * this.data[9] * this.data[14] + this.data[4] * this.data[10] * this.data[13] + this.data[8] * this.data[5] * this.data[14] - this.data[8] * this.data[6] * this.data[13] - this.data[12] * this.data[5] * this.data[10] + this.data[12] * this.data[6] * this.data[9];
        const m13 = this.data[0] * this.data[9] * this.data[14] - this.data[0] * this.data[10] * this.data[13] - this.data[8] * this.data[1] * this.data[14] + this.data[8] * this.data[2] * this.data[13] + this.data[12] * this.data[1] * this.data[10] - this.data[12] * this.data[2] * this.data[9];
        const m23 = -this.data[0] * this.data[5] * this.data[14] + this.data[0] * this.data[6] * this.data[13] + this.data[4] * this.data[1] * this.data[14] - this.data[4] * this.data[2] * this.data[13] - this.data[12] * this.data[1] * this.data[6] + this.data[12] * this.data[2] * this.data[5];
        const m33 = this.data[0] * this.data[5] * this.data[10] - this.data[0] * this.data[6] * this.data[9] - this.data[4] * this.data[1] * this.data[10] + this.data[4] * this.data[2] * this.data[9] + this.data[8] * this.data[1] * this.data[6] - this.data[8] * this.data[2] * this.data[5];
        const inv = new Mat44([
            m00, m10, m20, m30,
            m01, m11, m21, m31,
            m02, m12, m22, m32,
            m03, m13, m23, m33
        ]);
        const det = this.data[0] * inv.data[0] +
            this.data[1] * inv.data[4] +
            this.data[2] * inv.data[8] +
            this.data[3] * inv.data[12];
        return inv.multScalar(1 / det);
    }
    decompose(): Record<string, Vec3> {
        const col0 = this.col(0) as Vec4;
        const col1 = this.col(1) as Vec4;
        const col2 = this.col(2) as Vec4;
        const col3 = this.col(3) as Vec4;
        return {
            "left": new Vec3(col0.x, col0.y, col0.z).normalize(),
            "up": new Vec3(col1.x, col1.y, col1.z).normalize(),
            "forward": new Vec3(col2.x, col2.y, col2.z).normalize(),
            "origin": new Vec3(col3.x, col3.y, col3.z),
            "scale": new Vec3(col0.length() as number, col1.length() as number, col2.length() as number)
        };
    }
    toString(): string {
        return this.data[0] + ', ' + this.data[4] + ', ' + this.data[8] + ', ' + this.data[12] + ',\n' +
            this.data[1] + ', ' + this.data[5] + ', ' + this.data[9] + ', ' + this.data[13] + ',\n' +
            this.data[2] + ', ' + this.data[6] + ', ' + this.data[10] + ', ' + this.data[14] + ',\n' +
            this.data[3] + ', ' + this.data[7] + ', ' + this.data[11] + ', ' + this.data[15];
    }
    toArray(): number[] {
        return this.data.slice(0);
    }
    static identity(): Mat44 {
        return new Mat44();
    }
    static scale(scale: Vec3 | number[] | number): Mat44 {
        if (typeof scale === "number") {
            return new Mat44([
                scale, 0, 0, 0,
                0, scale, 0, 0,
                0, 0, scale, 0,
                0, 0, 0, 1
            ]);
        }
        else if (scale instanceof Array) {
            return new Mat44([
                scale[0], 0, 0, 0,
                0, scale[1], 0, 0,
                0, 0, scale[2], 0,
                0, 0, 0, 1
            ]);
        }
        return new Mat44([
            scale.x, 0, 0, 0,
            0, scale.y, 0, 0,
            0, 0, scale.z, 0,
            0, 0, 0, 1
        ]);
    }
    static translation(translation: Vec3 | number[]): Mat44 {
        if (translation instanceof Array) {
            return new Mat44([
                1, 0, 0, 0,
                0, 1, 0, 0,
                0, 0, 1, 0,
                translation[0], translation[1], translation[2], 1
            ]);
        }
        return new Mat44([
            1, 0, 0, 0,
            0, 1, 0, 0,
            0, 0, 1, 0,
            translation.x, translation.y, translation.z, 1
        ]);
    }
    static rotationDegrees(angle: number, axis: Vec3) {
        return Mat44.rotationRadians(angle * Math.PI / 180, axis);
    }
    static rotationRadians(angle: number, axis: Vec3 | number[]): Mat44 {
        const axisVec = (axis instanceof Array) ? new Vec3(axis) : axis;
        if (axisVec.lengthSquared() === 0) {
            return Mat44.identity();
        }
        const normAxis = axisVec.normalize();
        const x = normAxis.x;
        const y = normAxis.y;
        const z = normAxis.z;
        const modAngle = (angle > 0) ? angle % (2 * Math.PI) : angle % (-2 * Math.PI);
        const s = Math.sin(modAngle);
        const c = Math.cos(modAngle);
        const one_c = 1.0 - c;
        const xx = x * x;
        const yy = y * y;
        const zz = z * z;
        const xy = x * y;
        const yz = y * z;
        const zx = z * x;
        const xs = x * s;
        const ys = y * s;
        const zs = z * s;
        return new Mat44([
            (one_c * xx) + c, (one_c * xy) + zs, (one_c * zx) - ys, 0,
            (one_c * xy) - zs, (one_c * yy) + c, (one_c * yz) + xs, 0,
            (one_c * zx) + ys, (one_c * yz) - xs, (one_c * zz) + c, 0,
            0, 0, 0, 1
        ]);
    }
    static rotationFromTo(fromVec: Vec3, toVec: Vec3): Mat44 {
        const from = new Vec3(fromVec).normalize();
        const to = new Vec3(toVec).normalize();
        const e: number = from.dot(to);
        const f = Math.abs(e);
        let x: Vec3;
        let u: Vec3;
        let v: Vec3;
        if (f > (1.0 - EPSILON)) {
            const fx = Math.abs(from.x);
            const fy = Math.abs(from.y);
            const fz = Math.abs(from.z);
            if (fx < fy) {
                if (fx < fz) {
                    x = new Vec3(1, 0, 0);
                }
                else {
                    x = new Vec3(0, 0, 1);
                }
            }
            else {
                if (fy < fz) {
                    x = new Vec3(0, 1, 0);
                }
                else {
                    x = new Vec3(0, 0, 1);
                }
            }
            u = x.sub(from);
            v = x.sub(to);
            const c1 = 2.0 / u.dot(u);
            const c2 = 2.0 / v.dot(v);
            const c3 = c1 * c2 * u.dot(v);
            return new Mat44([
                -c1 * u.x * u.x - c2 * v.x * v.x + c3 * v.x * u.x + 1.0,
                -c1 * u.y * u.x - c2 * v.y * v.x + c3 * v.y * u.x,
                -c1 * u.z * u.x - c2 * v.z * v.x + c3 * v.z * u.x,
                0.0,
                -c1 * u.x * u.y - c2 * v.x * v.y + c3 * v.x * u.y,
                -c1 * u.y * u.y - c2 * v.y * v.y + c3 * v.y * u.y + 1.0,
                -c1 * u.z * u.y - c2 * v.z * v.y + c3 * v.z * u.y,
                0.0,
                -c1 * u.x * u.z - c2 * v.x * v.z + c3 * v.x * u.z,
                -c1 * u.y * u.z - c2 * v.y * v.z + c3 * v.y * u.z,
                -c1 * u.z * u.z - c2 * v.z * v.z + c3 * v.z * u.z + 1.0,
                0.0,
                0.0,
                0.0,
                0.0,
                1.0
            ]);
        }
        v = from.cross(to);
        const factor = 1.0 / (1.0 + e);
        const ux = factor * v.x;
        const uz = factor * v.z;
        const c1 = ux * v.y;
        const c2 = ux * v.z;
        const c3 = uz * v.y;
        return new Mat44([
            e + ux * v.x,
            c1 + v.z,
            c2 - v.y,
            0.0,
            c1 - v.z,
            e + factor * v.y * v.y,
            c3 + v.x,
            0.0,
            c2 + v.y,
            c3 - v.x,
            e + uz * v.z,
            0.0,
            0.0,
            0.0,
            0.0,
            1.0
        ]);
    }
    static ortho(left: number, right: number, bottom: number, top: number, near: number, far: number): Mat44 {
        const mat = Mat44.identity();
        mat.data[0] = 2 / (right - left);
        mat.data[5] = 2 / (top - bottom);
        mat.data[10] = -2 / (far - near);
        mat.data[12] = -((right + left) / (right - left));
        mat.data[13] = -((top + bottom) / (top - bottom));
        mat.data[14] = -((far + near) / (far - near));
        return mat;
    }
    static perspective(fov: number, aspect: number, zMin: number, zMax: number): Mat44 {
        const yMax = zMin * Math.tan(fov * (Math.PI / 360.0));
        const yMin = -yMax;
        const xMin = yMin * aspect;
        const xMax = -xMin;
        const mat = Mat44.identity();
        mat.data[0] = (2 * zMin) / (xMax - xMin);
        mat.data[5] = (2 * zMin) / (yMax - yMin);
        mat.data[8] = (xMax + xMin) / (xMax - xMin);
        mat.data[9] = (yMax + yMin) / (yMax - yMin);
        mat.data[10] = -((zMax + zMin) / (zMax - zMin));
        mat.data[11] = -1;
        mat.data[14] = -((2 * (zMax * zMin)) / (zMax - zMin));
        mat.data[15] = 0;
        return mat;
    }
    static random(): Mat44 {
        const rot = Mat44.rotationRadians(Math.random() * 360, Vec3.random());
        const scale = Mat44.scale(Math.random() * 10);
        const translation = Mat44.translation(Vec3.random());
        return translation.multMat44(rot.multMat44(scale));
    }
}
export default Mat44;
