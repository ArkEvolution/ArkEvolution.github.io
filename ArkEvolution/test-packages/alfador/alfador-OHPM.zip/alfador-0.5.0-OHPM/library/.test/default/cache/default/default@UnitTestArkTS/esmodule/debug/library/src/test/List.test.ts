import MathTest from "@normalized:N&&&alfador/src/test/unit.test&0.4.7";
export default function testsuite() {
    MathTest();
}
