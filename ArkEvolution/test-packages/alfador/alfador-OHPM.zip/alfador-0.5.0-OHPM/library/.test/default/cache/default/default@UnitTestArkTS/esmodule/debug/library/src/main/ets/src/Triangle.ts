import Vec3 from "@normalized:N&&&alfador/src/main/ets/src/Vec3&0.4.7";
function closestPointOnEdge(a: Vec3, b: Vec3, point: Vec3): Vec3 {
    const ab = b.sub(a);
    const t = new Vec3(point).sub(a).dot(ab) / ab.dot(ab);
    let clampedT = t;
    if (t < 0)
        clampedT = 0;
    if (t > 1)
        clampedT = 1;
    return a.add(ab.multScalar(clampedT));
}
export interface TriangleParams {
    a?: Vec3 | number[];
    b?: Vec3 | number[];
    c?: Vec3 | number[];
}
export interface IntersectionResult {
    position: Vec3;
    normal: Vec3;
    t: number;
}
class Triangle {
    a: Vec3;
    b: Vec3;
    c: Vec3;
    constructor(a?: Vec3 | number[] | TriangleParams, b?: Vec3 | number[], c?: Vec3 | number[]) {
        if (a instanceof Array) {
            this.a = new Vec3(a);
            this.b = b ? new Vec3(b) : new Vec3(0, 0, 0);
            this.c = c ? new Vec3(c) : new Vec3(0, 0, 0);
        }
        else if (a instanceof Vec3) {
            this.a = a;
            this.b = b instanceof Vec3 ? b : new Vec3(1, 0, 0);
            this.c = c instanceof Vec3 ? c : new Vec3(1, 1, 0);
        }
        else if (typeof a === 'object' && a !== null) {
            // Fix: Use explicit type cast instead of 'any'
            const obj = a as TriangleParams;
            this.a = obj.a ? new Vec3(obj.a) : new Vec3(0, 0, 0);
            this.b = obj.b ? new Vec3(obj.b) : new Vec3(1, 0, 0);
            this.c = obj.c ? new Vec3(obj.c) : new Vec3(1, 1, 0);
        }
        else {
            this.a = new Vec3(0, 0, 0);
            this.b = new Vec3(1, 0, 0);
            this.c = new Vec3(1, 1, 0);
        }
    }
    radius(): number {
        const centroid: Vec3 = this.centroid();
        const aDist: number = Number(this.a.sub(centroid).length());
        const bDist: number = Number(this.b.sub(centroid).length());
        const cDist: number = Number(this.c.sub(centroid).length());
        return Math.max(aDist, Math.max(bDist, cDist));
    }
    centroid(): Vec3 {
        return this.a
            .add(this.b)
            .add(this.c)
            .divScalar(3);
    }
    normal(): Vec3 {
        const ab: Vec3 = this.b.sub(this.a);
        const ac: Vec3 = this.c.sub(this.a);
        return ab.cross(ac).normalize();
    }
    area(): number {
        const ab = this.b.sub(this.a);
        const ac = this.c.sub(this.a);
        return (ab.cross(ac).length() as number) / 2.0;
    }
    isInside(point: Vec3 | number[]): boolean {
        const p = (point instanceof Array) ? new Vec3(point) : point;
        const a = this.a.sub(p);
        const b = this.b.sub(p);
        const c = this.c.sub(p);
        const u = b.cross(c);
        const v = c.cross(a);
        if (u.dot(v) < 0.0)
            return false;
        const w = a.cross(b);
        if (u.dot(w) < 0.0)
            return false;
        return true;
    }
    intersect(origin: Vec3 | number[], direction: Vec3 | number[], ignoreBehind: boolean, ignoreBackface: boolean): IntersectionResult | null {
        const o = (origin instanceof Array) ? new Vec3(origin) : origin;
        const d = (direction instanceof Array) ? new Vec3(direction) : direction;
        const normal = this.normal();
        const dn = d.dot(normal);
        if (dn === 0)
            return null;
        const t = this.a.sub(o).dot(normal) / dn;
        if (ignoreBehind && t < 0)
            return null;
        if (ignoreBackface) {
            if ((t > 0 && dn > 0) || (t < 0 && dn < 0))
                return null;
        }
        const position = o.add(d.multScalar(t));
        if (!this.isInside(position))
            return null;
        // Use explicit object literal type implicitly by return type match
        const result: IntersectionResult = {
            position: position,
            normal: normal,
            t: t
        };
        return result;
    }
    closestPoint(point: Vec3 | number[]): Vec3 {
        const p = (point instanceof Array) ? new Vec3(point) : point;
        const e0 = closestPointOnEdge(this.a, this.b, p);
        const e1 = closestPointOnEdge(this.b, this.c, p);
        const e2 = closestPointOnEdge(this.c, this.a, p);
        const d0 = e0.sub(p).lengthSquared();
        const d1 = e1.sub(p).lengthSquared();
        const d2 = e2.sub(p).lengthSquared();
        if (d0 < d1) {
            return (d0 < d2) ? e0 : e2;
        }
        else {
            return (d1 < d2) ? e1 : e2;
        }
    }
    equals(that: Triangle, epsilon?: number): boolean {
        return this.a.equals(that.a, epsilon) &&
            this.b.equals(that.b, epsilon) &&
            this.c.equals(that.c, epsilon);
    }
    toString(): string {
        return this.a.toString() + ", " +
            this.b.toString() + ", " +
            this.c.toString();
    }
    static random(): Triangle {
        const a: Vec3 = Vec3.random();
        const b: Vec3 = Vec3.random();
        const c: Vec3 = Vec3.random();
        const centroid: Vec3 = a.add(b).add(c).divScalar(3);
        const aCent: Vec3 = a.sub(centroid);
        const bCent: Vec3 = b.sub(centroid);
        const cCent: Vec3 = c.sub(centroid);
        const aDist: number = Number(aCent.length());
        const bDist: number = Number(bCent.length());
        const cDist: number = Number(cCent.length());
        const maxDist: number = Math.max(Math.max(aDist, bDist), cDist);
        const scale: number = 1 / maxDist;
        return new Triangle(aCent.multScalar(scale), bCent.multScalar(scale), cCent.multScalar(scale));
    }
}
export default Triangle;
