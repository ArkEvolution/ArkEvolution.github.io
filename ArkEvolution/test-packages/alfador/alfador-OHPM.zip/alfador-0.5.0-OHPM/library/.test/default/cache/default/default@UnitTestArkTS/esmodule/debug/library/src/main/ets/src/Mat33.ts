import Vec3 from "@normalized:N&&&alfador/src/main/ets/src/Vec3&0.4.7";
import Mat44 from "@normalized:N&&&alfador/src/main/ets/src/Mat44&0.4.7";
import { EPSILON } from "@normalized:N&&&alfador/src/main/ets/src/Epsilon&0.4.7";
class Mat33 {
    data: number[];
    constructor(that?: number[] | Mat33 | Mat44) {
        let source: number[] | undefined;
        if (that) {
            if (that instanceof Array) {
                source = that;
            }
            else if (that instanceof Mat33) {
                source = that.data;
            }
            else if (that instanceof Mat44) {
                // Mat44 to Mat33
                source = [
                    that.data[0], that.data[1], that.data[2],
                    that.data[4], that.data[5], that.data[6],
                    that.data[8], that.data[9], that.data[10]
                ];
            }
        }
        if (!source) {
            this.data = [
                1, 0, 0,
                0, 1, 0,
                0, 0, 1
            ];
        }
        else {
            if (source.length === 9) {
                this.data = source.slice(0);
            }
            else {
                // Fallback or copy logic similar to Mat44 conversion
                this.data = new Array(9);
                this.data[0] = source[0];
                this.data[1] = source[1];
                this.data[2] = source[2];
                this.data[3] = source[3];
                this.data[4] = source[4];
                this.data[5] = source[5];
                this.data[6] = source[6];
                this.data[7] = source[7];
                this.data[8] = source[8];
            }
        }
    }
    row(index: number, vec?: Vec3 | number[]): Vec3 | Mat33 {
        if (vec) {
            const v = (vec instanceof Array) ? vec : [vec.x, vec.y, vec.z];
            this.data[0 + index] = v[0];
            this.data[3 + index] = v[1];
            this.data[6 + index] = v[2];
            return this;
        }
        return new Vec3(this.data[0 + index], this.data[3 + index], this.data[6 + index]);
    }
    col(index: number, vec?: Vec3 | number[]): Vec3 | Mat33 {
        if (vec) {
            const v = (vec instanceof Array) ? vec : [vec.x, vec.y, vec.z];
            this.data[0 + index * 3] = v[0];
            this.data[1 + index * 3] = v[1];
            this.data[2 + index * 3] = v[2];
            return this;
        }
        return new Vec3(this.data[0 + index * 3], this.data[1 + index * 3], this.data[2 + index * 3]);
    }
    static rotationDegrees(angle: number, axis: Vec3) {
        return Mat33.rotationRadians(angle * Math.PI / 180, axis);
    }
    static rotationRadians(angle: number, axis: Vec3 | number[]): Mat33 {
        const axisVec = (axis instanceof Array) ? new Vec3(axis) : axis;
        if (axisVec.lengthSquared() === 0) {
            return Mat33.identity();
        }
        const normAxis = axisVec.normalize();
        const x = normAxis.x;
        const y = normAxis.y;
        const z = normAxis.z;
        const modAngle = (angle > 0) ? angle % (2 * Math.PI) : angle % (-2 * Math.PI);
        const s = Math.sin(modAngle);
        const c = Math.cos(modAngle);
        const one_c = 1.0 - c;
        // Pre-calculate
        const xx = x * x;
        const yy = y * y;
        const zz = z * z;
        const xy = x * y;
        const yz = y * z;
        const zx = z * x;
        const xs = x * s;
        const ys = y * s;
        const zs = z * s;
        return new Mat33([
            (one_c * xx) + c, (one_c * xy) + zs, (one_c * zx) - ys,
            (one_c * xy) - zs, (one_c * yy) + c, (one_c * yz) + xs,
            (one_c * zx) + ys, (one_c * yz) - xs, (one_c * zz) + c
        ]);
    }
    addMat33(that: Mat33 | number[]): Mat33 {
        const d = (that instanceof Array) ? that : that.data;
        return new Mat33([
            this.data[0] + d[0],
            this.data[1] + d[1],
            this.data[2] + d[2],
            this.data[3] + d[3],
            this.data[4] + d[4],
            this.data[5] + d[5],
            this.data[6] + d[6],
            this.data[7] + d[7],
            this.data[8] + d[8],
        ]);
    }
    addMat44(that: Mat44 | number[]): Mat33 {
        const d = (that instanceof Array) ? that : that.data;
        return new Mat33([
            this.data[0] + d[0],
            this.data[1] + d[1],
            this.data[2] + d[2],
            this.data[3] + d[4],
            this.data[4] + d[5],
            this.data[5] + d[6],
            this.data[6] + d[8],
            this.data[7] + d[9],
            this.data[8] + d[10],
        ]);
    }
    subMat33(that: Mat33 | number[]): Mat33 {
        const d = (that instanceof Array) ? that : that.data;
        return new Mat33([
            this.data[0] - d[0],
            this.data[1] - d[1],
            this.data[2] - d[2],
            this.data[3] - d[3],
            this.data[4] - d[4],
            this.data[5] - d[5],
            this.data[6] - d[6],
            this.data[7] - d[7],
            this.data[8] - d[8],
        ]);
    }
    subMat44(that: Mat44 | number[]): Mat33 {
        const d = (that instanceof Array) ? that : that.data;
        return new Mat33([
            this.data[0] - d[0],
            this.data[1] - d[1],
            this.data[2] - d[2],
            this.data[3] - d[4],
            this.data[4] - d[5],
            this.data[5] - d[6],
            this.data[6] - d[8],
            this.data[7] - d[9],
            this.data[8] - d[10],
        ]);
    }
    multVec3(that: Vec3 | number[]): Vec3 {
        if (that instanceof Array) {
            return new Vec3(this.data[0] * that[0] + this.data[3] * that[1] + this.data[6] * that[2], this.data[1] * that[0] + this.data[4] * that[1] + this.data[7] * that[2], this.data[2] * that[0] + this.data[5] * that[1] + this.data[8] * that[2]);
        }
        return new Vec3(this.data[0] * that.x + this.data[3] * that.y + this.data[6] * that.z, this.data[1] * that.x + this.data[4] * that.y + this.data[7] * that.z, this.data[2] * that.x + this.data[5] * that.y + this.data[8] * that.z);
    }
    multScalar(that: number): Mat33 {
        return new Mat33([
            this.data[0] * that,
            this.data[1] * that,
            this.data[2] * that,
            this.data[3] * that,
            this.data[4] * that,
            this.data[5] * that,
            this.data[6] * that,
            this.data[7] * that,
            this.data[8] * that
        ]);
    }
    multMat33(that: Mat33 | number[]): Mat33 {
        const d = (that instanceof Array) ? that : that.data;
        return new Mat33([
            this.data[0] * d[0] + this.data[3] * d[1] + this.data[6] * d[2],
            this.data[1] * d[0] + this.data[4] * d[1] + this.data[7] * d[2],
            this.data[2] * d[0] + this.data[5] * d[1] + this.data[8] * d[2],
            this.data[0] * d[3] + this.data[3] * d[4] + this.data[6] * d[5],
            this.data[1] * d[3] + this.data[4] * d[4] + this.data[7] * d[5],
            this.data[2] * d[3] + this.data[5] * d[4] + this.data[8] * d[5],
            this.data[0] * d[6] + this.data[3] * d[7] + this.data[6] * d[8],
            this.data[1] * d[6] + this.data[4] * d[7] + this.data[7] * d[8],
            this.data[2] * d[6] + this.data[5] * d[7] + this.data[8] * d[8]
        ]);
    }
    multMat44(that: Mat44 | number[]): Mat33 {
        const d = (that instanceof Array) ? that : that.data;
        return new Mat33([
            this.data[0] * d[0] + this.data[3] * d[1] + this.data[6] * d[2],
            this.data[1] * d[0] + this.data[4] * d[1] + this.data[7] * d[2],
            this.data[2] * d[0] + this.data[5] * d[1] + this.data[8] * d[2],
            this.data[0] * d[4] + this.data[3] * d[5] + this.data[6] * d[6],
            this.data[1] * d[4] + this.data[4] * d[5] + this.data[7] * d[6],
            this.data[2] * d[4] + this.data[5] * d[5] + this.data[8] * d[6],
            this.data[0] * d[8] + this.data[3] * d[9] + this.data[6] * d[10],
            this.data[1] * d[8] + this.data[4] * d[9] + this.data[7] * d[10],
            this.data[2] * d[8] + this.data[5] * d[9] + this.data[8] * d[10]
        ]);
    }
    divScalar(that: number): Mat33 {
        return new Mat33([
            this.data[0] / that,
            this.data[1] / that,
            this.data[2] / that,
            this.data[3] / that,
            this.data[4] / that,
            this.data[5] / that,
            this.data[6] / that,
            this.data[7] / that,
            this.data[8] / that
        ]);
    }
    equals(that: Mat33 | number[], epsilon?: number): boolean {
        const d = (that instanceof Array) ? that : that.data;
        epsilon = epsilon === undefined ? 0 : epsilon;
        return ((this.data[0] === d[0]) || (Math.abs(this.data[0] - d[0]) <= epsilon)) &&
            ((this.data[1] === d[1]) || (Math.abs(this.data[1] - d[1]) <= epsilon)) &&
            ((this.data[2] === d[2]) || (Math.abs(this.data[2] - d[2]) <= epsilon)) &&
            ((this.data[3] === d[3]) || (Math.abs(this.data[3] - d[3]) <= epsilon)) &&
            ((this.data[4] === d[4]) || (Math.abs(this.data[4] - d[4]) <= epsilon)) &&
            ((this.data[5] === d[5]) || (Math.abs(this.data[5] - d[5]) <= epsilon)) &&
            ((this.data[6] === d[6]) || (Math.abs(this.data[6] - d[6]) <= epsilon)) &&
            ((this.data[7] === d[7]) || (Math.abs(this.data[7] - d[7]) <= epsilon)) &&
            ((this.data[8] === d[8]) || (Math.abs(this.data[8] - d[8]) <= epsilon));
    }
    transpose(): Mat33 {
        return new Mat33([
            this.data[0],
            this.data[3],
            this.data[6],
            this.data[1],
            this.data[4],
            this.data[7],
            this.data[2],
            this.data[5],
            this.data[8]
        ]);
    }
    inverse(): Mat33 {
        // col 0
        const m00 = this.data[4] * this.data[8] - this.data[7] * this.data[5];
        const m10 = -this.data[1] * this.data[8] + this.data[7] * this.data[2];
        const m20 = this.data[1] * this.data[5] - this.data[4] * this.data[2];
        // col 1
        const m01 = -this.data[3] * this.data[8] + this.data[6] * this.data[5];
        const m11 = this.data[0] * this.data[8] - this.data[6] * this.data[2];
        const m21 = -this.data[0] * this.data[5] + this.data[3] * this.data[2];
        // col 2
        const m02 = this.data[3] * this.data[7] - this.data[6] * this.data[4];
        const m12 = -this.data[0] * this.data[7] + this.data[6] * this.data[1];
        const m22 = this.data[0] * this.data[4] - this.data[3] * this.data[1];
        const inv = new Mat33([
            m00, m10, m20,
            m01, m11, m21,
            m02, m12, m22
        ]);
        // calculate determinant
        const det = this.data[0] * inv.data[0] + this.data[1] * inv.data[3] + this.data[2] * inv.data[6];
        // return
        return inv.multScalar(1 / det);
    }
    decompose(): Record<string, Vec3> {
        const col0 = this.col(0) as Vec3;
        const col1 = this.col(1) as Vec3;
        const col2 = this.col(2) as Vec3;
        return {
            "left": col0.normalize(),
            "up": col1.normalize(),
            "forward": col2.normalize(),
            "scale": new Vec3(col0.length() as number, col1.length() as number, col2.length() as number)
        };
    }
    toString(): string {
        return this.data[0] + ', ' + this.data[3] + ', ' + this.data[6] + ',\n' +
            this.data[1] + ', ' + this.data[4] + ', ' + this.data[7] + ',\n' +
            this.data[2] + ', ' + this.data[5] + ', ' + this.data[8];
    }
    toArray(): number[] {
        return this.data.slice(0);
    }
    static identity(): Mat33 {
        return new Mat33();
    }
    static scale(scale: Vec3 | number[] | number): Mat33 {
        if (typeof scale === "number") {
            return new Mat33([
                scale, 0, 0,
                0, scale, 0,
                0, 0, scale
            ]);
        }
        else if (scale instanceof Array) {
            return new Mat33([
                scale[0], 0, 0,
                0, scale[1], 0,
                0, 0, scale[2]
            ]);
        }
        return new Mat33([
            scale.x, 0, 0,
            0, scale.y, 0,
            0, 0, scale.z
        ]);
    }
    static rotationFromTo(fromVec: Vec3, toVec: Vec3): Mat33 {
        const from = new Vec3(fromVec).normalize();
        const to = new Vec3(toVec).normalize();
        const e: number = from.dot(to);
        const f = Math.abs(e);
        let x: Vec3;
        let u: Vec3;
        let v: Vec3;
        if (f > (1.0 - EPSILON)) {
            // "from" and "to" almost parallel
            // nearly orthogonal
            const fx = Math.abs(from.x);
            const fy = Math.abs(from.y);
            const fz = Math.abs(from.z);
            if (fx < fy) {
                if (fx < fz) {
                    x = new Vec3(1, 0, 0);
                }
                else {
                    x = new Vec3(0, 0, 1);
                }
            }
            else {
                if (fy < fz) {
                    x = new Vec3(0, 1, 0);
                }
                else {
                    x = new Vec3(0, 0, 1);
                }
            }
            u = x.sub(from);
            v = x.sub(to);
            const c1 = 2.0 / u.dot(u);
            const c2 = 2.0 / v.dot(v);
            const c3 = c1 * c2 * u.dot(v);
            // set matrix entries
            return new Mat33([
                -c1 * u.x * u.x - c2 * v.x * v.x + c3 * v.x * u.x + 1.0,
                -c1 * u.y * u.x - c2 * v.y * v.x + c3 * v.y * u.x,
                -c1 * u.z * u.x - c2 * v.z * v.x + c3 * v.z * u.x,
                -c1 * u.x * u.y - c2 * v.x * v.y + c3 * v.x * u.y,
                -c1 * u.y * u.y - c2 * v.y * v.y + c3 * v.y * u.y + 1.0,
                -c1 * u.z * u.y - c2 * v.z * v.y + c3 * v.z * u.y,
                -c1 * u.x * u.z - c2 * v.x * v.z + c3 * v.x * u.z,
                -c1 * u.y * u.z - c2 * v.y * v.z + c3 * v.y * u.z,
                -c1 * u.z * u.z - c2 * v.z * v.z + c3 * v.z * u.z + 1.0
            ]);
        }
        // the most common case, unless "from"="to", or "to"=-"from"
        v = from.cross(to);
        const factor = 1.0 / (1.0 + e); // optimization by Gottfried Chen
        const ux = factor * v.x;
        const uz = factor * v.z;
        const c1 = ux * v.y;
        const c2 = ux * v.z;
        const c3 = uz * v.y;
        return new Mat33([
            e + ux * v.x,
            c1 + v.z,
            c2 - v.y,
            c1 - v.z,
            e + factor * v.y * v.y,
            c3 + v.x,
            c2 + v.y,
            c3 - v.x,
            e + uz * v.z
        ]);
    }
    static random(): Mat33 {
        const rot = Mat33.rotationRadians(Math.random() * 360, Vec3.random());
        const scale = Mat33.scale(Math.random() * 10);
        return rot.multMat33(scale);
    }
}
export default Mat33;
