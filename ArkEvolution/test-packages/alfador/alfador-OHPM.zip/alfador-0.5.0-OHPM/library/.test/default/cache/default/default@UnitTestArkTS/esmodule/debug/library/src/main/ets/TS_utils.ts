export function callInvokeFunction(func: Function, thisArg: ESObject, ...argArray: ESObject[]): ESObject {
    return func.call(thisArg, argArray);
}
export function _getPrototype(obj: ESObject): ESObject {
    return obj.prototype;
}
