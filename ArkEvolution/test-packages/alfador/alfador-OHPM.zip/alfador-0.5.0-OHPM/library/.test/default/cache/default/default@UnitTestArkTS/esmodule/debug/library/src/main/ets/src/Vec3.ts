import { EPSILON } from "@normalized:N&&&alfador/src/main/ets/src/Epsilon&0.4.7";
class Vec3 {
    x: number;
    y: number;
    z: number;
    constructor(x?: number | Vec3 | number[], y?: number, z?: number) {
        if (x instanceof Vec3) {
            this.x = x.x;
            this.y = x.y;
            this.z = x.z;
        }
        else if (x instanceof Array) {
            this.x = x[0];
            this.y = x[1];
            this.z = x[2];
        }
        else if (typeof x === 'number') {
            this.x = x;
            this.y = y || 0.0;
            this.z = z || 0.0;
        }
        else {
            this.x = 0.0;
            this.y = 0.0;
            this.z = 0.0;
        }
    }
    negate(): Vec3 {
        return new Vec3(-this.x, -this.y, -this.z);
    }
    add(that: Vec3 | number[]): Vec3 {
        if (that instanceof Array) {
            return new Vec3(this.x + that[0], this.y + that[1], this.z + that[2]);
        }
        return new Vec3(this.x + that.x, this.y + that.y, this.z + that.z);
    }
    sub(that: Vec3 | number[]): Vec3 {
        if (that instanceof Array) {
            return new Vec3(this.x - that[0], this.y - that[1], this.z - that[2]);
        }
        return new Vec3(this.x - that.x, this.y - that.y, this.z - that.z);
    }
    multScalar(that: number): Vec3 {
        return new Vec3(this.x * that, this.y * that, this.z * that);
    }
    divScalar(that: number): Vec3 {
        return new Vec3(this.x / that, this.y / that, this.z / that);
    }
    dot(that: Vec3 | number[]): number {
        if (that instanceof Array) {
            return (this.x * that[0]) + (this.y * that[1]) + (this.z * that[2]);
        }
        return (this.x * that.x) + (this.y * that.y) + (this.z * that.z);
    }
    cross(that: Vec3 | number[]): Vec3 {
        if (that instanceof Array) {
            return new Vec3((this.y * that[2]) - (that[1] * this.z), (-this.x * that[2]) + (that[0] * this.z), (this.x * that[1]) - (that[0] * this.y));
        }
        return new Vec3((this.y * that.z) - (that.y * this.z), (-this.x * that.z) + (that.x * this.z), (this.x * that.y) - (that.x * this.y));
    }
    length(length?: number): number | Vec3 {
        if (length === undefined) {
            let len = this.dot(this);
            if (Math.abs(len - 1.0) < EPSILON) {
                return len;
            }
            else {
                return Math.sqrt(len);
            }
        }
        return this.normalize().multScalar(length);
    }
    lengthSquared(): number {
        return this.dot(this);
    }
    equals(that: Vec3 | number[], epsilon?: number): boolean {
        let x: number, y: number, z: number;
        if (that instanceof Array) {
            x = that[0];
            y = that[1];
            z = that[2];
        }
        else {
            x = that.x;
            y = that.y;
            z = that.z;
        }
        const eps = epsilon === undefined ? 0 : epsilon;
        return (this.x === x || Math.abs(this.x - x) <= eps) &&
            (this.y === y || Math.abs(this.y - y) <= eps) &&
            (this.z === z || Math.abs(this.z - z) <= eps);
    }
    normalize(): Vec3 {
        const mag = this.length() as number;
        if (mag !== 0) {
            return new Vec3(this.x / mag, this.y / mag, this.z / mag);
        }
        return new Vec3();
    }
    projectOntoPlane(n: Vec3): Vec3 {
        const dist = this.dot(n);
        return this.sub(n.multScalar(dist));
    }
    unsignedAngleRadians(that: Vec3 | number[], normal?: Vec3 | number[]): number {
        const a = this;
        const b = (that instanceof Array) ? new Vec3(that) : that;
        const cross = a.cross(b);
        let n: Vec3;
        if (normal) {
            n = (normal instanceof Array) ? new Vec3(normal) : normal;
        }
        else {
            n = new Vec3(cross);
        }
        const pa = a.projectOntoPlane(n).normalize();
        const pb = b.projectOntoPlane(n).normalize();
        const dot = pa.dot(pb);
        let angle = Math.atan2(pa.cross(pb).length() as number, dot);
        if (n.dot(cross) < 0) {
            if (angle >= Math.PI * 0.5) {
                angle = Math.PI + Math.PI - angle;
            }
            else {
                angle = 2 * Math.PI - angle;
            }
        }
        return angle;
    }
    unsignedAngleDegrees(that: Vec3 | number[], normal?: Vec3 | number[]): number {
        return this.unsignedAngleRadians(that, normal) * (180 / Math.PI);
    }
    toString(): string {
        return this.x + ", " + this.y + ", " + this.z;
    }
    toArray(): number[] {
        return [this.x, this.y, this.z];
    }
    static random(): Vec3 {
        return new Vec3(Math.random(), Math.random(), Math.random()).normalize();
    }
}
export default Vec3;
