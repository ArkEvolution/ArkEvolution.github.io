import { EPSILON } from "@normalized:N&&&alfador/src/main/ets/src/Epsilon&0.4.7";
class Vec4 {
    x: number;
    y: number;
    z: number;
    w: number;
    constructor(x?: number | Vec4 | number[] | Record<string, number>, y?: number, z?: number, w?: number) {
        if (x instanceof Vec4) {
            this.x = x.x;
            this.y = x.y;
            this.z = x.z;
            this.w = x.w;
        }
        else if (x instanceof Array) {
            this.x = x[0];
            this.y = x[1];
            this.z = x[2];
            this.w = x[3] || 0.0;
        }
        else if (typeof x === 'number') {
            this.x = x;
            this.y = y || 0.0;
            this.z = z || 0.0;
            this.w = w || 0.0;
        }
        else if (typeof x === 'object' && x !== null) {
            // Handle generic object with x,y,z,w
            const obj = x as Record<string, number>;
            this.x = obj.x || 0.0;
            this.y = obj.y || 0.0;
            this.z = obj.z || 0.0;
            this.w = obj.w || 0.0;
        }
        else {
            this.x = 0.0;
            this.y = 0.0;
            this.z = 0.0;
            this.w = 0.0;
        }
    }
    negate(): Vec4 {
        return new Vec4(-this.x, -this.y, -this.z, -this.w);
    }
    add(that: Vec4 | number[]): Vec4 {
        if (that instanceof Array) {
            return new Vec4(this.x + that[0], this.y + that[1], this.z + that[2], this.w + that[3]);
        }
        return new Vec4(this.x + that.x, this.y + that.y, this.z + that.z, this.w + that.w);
    }
    sub(that: Vec4 | number[]): Vec4 {
        if (that instanceof Array) {
            return new Vec4(this.x - that[0], this.y - that[1], this.z - that[2], this.w - that[3]);
        }
        return new Vec4(this.x - that.x, this.y - that.y, this.z - that.z, this.w - that.w);
    }
    multScalar(that: number): Vec4 {
        return new Vec4(this.x * that, this.y * that, this.z * that, this.w * that);
    }
    divScalar(that: number): Vec4 {
        return new Vec4(this.x / that, this.y / that, this.z / that, this.w / that);
    }
    dot(that: Vec4 | number[]): number {
        if (that instanceof Array) {
            return (this.x * that[0]) +
                (this.y * that[1]) +
                (this.z * that[2]) +
                (this.w * that[3]);
        }
        return (this.x * that.x) +
            (this.y * that.y) +
            (this.z * that.z) +
            (this.w * that.w);
    }
    length(length?: number): number | Vec4 {
        if (length === undefined) {
            let len = this.dot(this);
            if (Math.abs(len - 1.0) < EPSILON) {
                return len;
            }
            else {
                return Math.sqrt(len);
            }
        }
        return this.normalize().multScalar(length);
    }
    lengthSquared(): number {
        return this.dot(this);
    }
    equals(that: Vec4 | number[], epsilon?: number): boolean {
        let x: number, y: number, z: number, w: number;
        if (that instanceof Array) {
            x = that[0];
            y = that[1];
            z = that[2];
            w = that[3];
        }
        else {
            x = that.x;
            y = that.y;
            z = that.z;
            w = that.w;
        }
        epsilon = epsilon === undefined ? 0 : epsilon;
        return (this.x === x || Math.abs(this.x - x) <= epsilon) &&
            (this.y === y || Math.abs(this.y - y) <= epsilon) &&
            (this.z === z || Math.abs(this.z - z) <= epsilon) &&
            (this.w === w || Math.abs(this.w - w) <= epsilon);
    }
    normalize(): Vec4 {
        const mag = this.length() as number;
        if (mag !== 0) {
            return new Vec4(this.x / mag, this.y / mag, this.z / mag, this.w / mag);
        }
        return new Vec4();
    }
    toString(): string {
        return this.x + ', ' + this.y + ', ' + this.z + ', ' + this.w;
    }
    toArray(): number[] {
        return [this.x, this.y, this.z, this.w];
    }
    static random(): Vec4 {
        return new Vec4(Math.random(), Math.random(), Math.random(), Math.random()).normalize();
    }
}
export default Vec4;
