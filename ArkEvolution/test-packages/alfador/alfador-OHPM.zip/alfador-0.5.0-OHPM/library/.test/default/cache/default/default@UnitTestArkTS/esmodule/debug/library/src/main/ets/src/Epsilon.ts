/**
 * Epsilon constant for floating point comparisons.
 */
export const EPSILON = 0.00000000001;
