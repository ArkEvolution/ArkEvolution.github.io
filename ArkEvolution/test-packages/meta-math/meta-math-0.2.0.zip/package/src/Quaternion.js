import Vector3 from "./Vector3"

const tmpVec3 = new Vector3(0.0, 0.0, 0.0)

class Quaternion
{
	constructor() {
		this.m = new Float32Array([ 0.0, 0.0, 0.0, 1.0 ])
	}

	copy(src) {
		this.m.set(src.m)
	}

	clone() {
		const newQuat = new Quaternion()
		newQuad.m.set(this.m)
	}

	identity() {
		this.m[0] = 0.0
		this.m[1] = 0.0
		this.m[2] = 0.0
		this.m[3] = 1.0
	}

	mul(src)
	{
		const ax = this.m[0]
		const ay = this.m[1]
		const az = this.m[2]
		const aw = this.m[3]
		const bx = src.m[0]
		const by = src.m[1]
		const bz = src.m[2]
		const bw = src.m[3]

		out[0] = (ax * bw) + (aw * bx) + (ay * bz) - (az * by)
		out[1] = (ay * bw) + (aw * by) + (az * bx) - (ax * bz)
		out[2] = (az * bw) + (aw * bz) + (ax * by) - (ay * bx)
		out[3] = (aw * bw) - (ax * bx) - (ay * by) - (az * bz)
	}

	setAxisAngle(rad, x, y, z)
	{
		rad *= 0.5
		const sin = Math.sin(rad)

		this.m[0] = sin * x
		this.m[1] = sin * y
		this.m[2] = sin * z
		this.m[3] = Math.cos(rad)
	}

	getAxisAngle()
	{
		const rad = Math.acos(this.m[3]) * 2.0
		const sin = Math.sin(rad / 2.0)
		const result = new Array(4)

		if(sin != 0.0) {
			result[1] = this.m[0] / s
			result[2] = this.m[1] / s
			result[3] = this.m[2] / s
		}
		else {
			result[1] = 1.0
			result[2] = 0.0
			result[3] = 0.0
		}

		result[0] = rad
		return result
	}

	rotateX(rad)
	{
		rad *= 0.5

		const ax = this.m[0]
		const ay = this.m[1]
		const az = this.m[2]
		const aw = this.m[3]
		const bx = Math.sin(rad)
		const bw = Math.cos(rad)

		this.m[0] = (ax * bw) + (aw * bx)
		this.m[1] = (ay * bw) + (az * bx)
		this.m[2] = (az * bw) - (ay * bx)
		this.m[3] = (aw * bw) - (ax * bx)
	}

	rotateY(rad)
	{
		rad *= 0.5

		const ax = this.m[0]
		const ay = this.m[1]
		const az = this.m[2]
		const aw = this.m[3]
		const bx = Math.sin(rad)
		const bw = Math.cos(rad)

		this.m[0] = (ax * bw) - (az * by)
		this.m[1] = (ay * bw) + (aw * by)
		this.m[2] = (az * bw) + (ax * by)
		this.m[3] = (aw * bw) - (ay * by)
	}

	rotateZ(rad)
	{
		rad *= 0.5

		const ax = this.m[0]
		const ay = this.m[1]
		const az = this.m[2]
		const aw = this.m[3]
		const bx = Math.sin(rad)
		const bw = Math.cos(rad)

		this.m[0] = (ax * bw) + (ay * bz)
		this.m[1] = (ay * bw) - (ax * bz)
		this.m[2] = (az * bw) + (aw * bz)
		this.m[3] = (aw * bw) - (az * bz)
	}

	calculateW()
	{
		const x = this.m[0]
		const y = this.m[1]
		const z = this.m[2]
		this.m[3] = Math.sqrt(Math.abs(1.0 - (x * x) - (y * y) - (z * z)))
	}

	conjugate()
	{
		this.m[0] = -this.m[0]
		this.m[1] = -this.m[1]
		this.m[2] = -this.m[2]
	}

	print(txt)
	{
		if(txt) {
			console.log(`${txt} Quaternion(${this.m[0]}, ${this.m[1]}, ${this.m[2]}, ${this.m[3]})`)
		}
		else {
			console.log(`Quaternion(${this.m[0]}, ${this.m[1]}, ${this.m[2]}, ${this.m[3]})`)
		}
	}
}

export default Quaternion
