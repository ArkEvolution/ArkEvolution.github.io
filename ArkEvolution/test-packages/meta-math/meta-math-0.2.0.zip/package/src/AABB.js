
export default class AABB
{
	constructor(x, y, width, height)
	{
		this.x = x || 0
		this.y = y || 0
		this.width = width || 0
		this.height = height || 0

		this.halfWidth = this.width / 2
		this.halfHeight = this.height / 2
		this.pivotPosX = this.width * this.pivotX
		this.pivotPosY = this.height * this.pivotY

		this.minX = this.x
		this.minY = this.y
		this.maxX = this.x + this.width
		this.maxY = this.y + this.height
	}

	set(x, y, width, height)
	{
		this.x = x || 0
		this.y = y || 0
		this.width = width || 0
		this.height = height || 0

		this.halfWidth = this.width / 2
		this.halfHeight = this.height / 2
		this.pivotPosX = this.width * this.pivotX
		this.pivotPosY = this.height * this.pivotY

		this.minX = this.x
		this.minY = this.y
		this.maxX = this.x + this.width
		this.maxY = this.y + this.height
	}

	position(x, y)
	{
		this.x = x
		this.y = y
		this.minX = this.x - this.pivotPosX
		this.minY = this.y - this.pivotPosY
		this.maxX = this.minX + this.width
		this.maxY = this.minY + this.height
	}

	move(x, y)
	{
		this.x += x
		this.y += y
		this.minX += x
		this.minY += y
		this.maxX += x
		this.maxY += y
	}

	resize(width, height)
	{
		this.width = width
		this.height = height
		this.halfWidth = width / 2
		this.halfHeight = height / 2
		this.pivotPosX = this.width * this.pivotX
		this.pivotPosY = this.height * this.pivotY

		this.minX = this.x - this.pivotPosX
		this.minY = this.y - this.pivotPosY
		this.maxX = this.minX + this.width
		this.maxY = this.minY + this.height
	}

	pivot(x, y)
	{
		if(y === undefined) { y = x }

		this.pivotX = x
		this.pivotY = y
		this.pivotPosX = this.width * this.pivotX
		this.pivotPosY = this.height * this.pivotY

		this.minX = this.x - this.pivotPosX
		this.minY = this.y - this.pivotPosY
		this.maxX = this.minX + this.width
		this.maxY = this.minY + this.height
	}

	vsAABB(src)
	{
		if(this.maxX < src.minX || this.minX > src.maxX) { return false }
		if(this.maxY < src.minY || this.minY > src.maxY) { return false }

		return true
	}

	vsBorderAABB(src)
	{
		if(this.maxX <= src.minX || this.minX >= src.maxX) { return false }
		if(this.maxY <= src.minY || this.minY >= src.maxY) { return false }

		return true
	}

	vsAABBIntersection(src)
	{
		if(this.maxX < src.minX || this.minX > src.maxX) { return 0 }
		if(this.maxY < src.minY || this.minY > src.maxY) { return 0 }

		if(this.minX > src.minX || this.minY > src.minY) { return 1 }
		if(this.maxX < src.maxX || this.maxY < src.maxY) { return 1 }

		return 2
	}

	vsPoint(x, y)
	{
		if(this.minX > x || this.maxX < x) { return false }
		if(this.minY > y || this.maxY < y) { return false }

		return true
	}

	vsBorderPoint(x, y)
	{
		if(this.minX >= x || this.maxX <= x) { return false }
		if(this.minY >= y || this.maxY <= y) { return false }

		return true
	}

	getSqrDistance(x, y)
	{
		let tmp
		let sqDist = 0

		if(x < this.minX) {
			tmp = (this.minX - x)
			sqDist += tmp * tmp
		}
		if(x > this.maxX) {
			tmp = (x - this.maxX)
			sqDist += tmp * tmp
		}

		if(y < this.minY) {
			tmp = (this.minY - y)
			sqDist += tmp * tmp
		}
		if(y > this.maxY) {
			tmp = (y - this.maxY)
			sqDist += tmp * tmp
		}

		return sqDist
	}

	getDistanceVsAABB(aabb)
	{
		const centerX = this.minX + ((this.maxX - this.minX) / 2)
		const centerY = this.minY + ((this.maxY - this.minY) / 2)
		const srcCenterX = aabb.minX + ((aabb.maxY - aabb.minY) / 2)
		const srcCenterY = aabb.minY + ((aabb.maxY - aabb.minY) / 2)

		const diffX = srcCenterX - centerX
		const diffY = srcCenterY - centerY

		return Math.sqrt((diffX * diffX) + (diffY * diffY))
	}

	isUndefined() {
		return (this.maxY === undefined)
	}

	print(str)
	{
		if(str)
		{
			console.log("(AABB) " + str + " minX: " + this.minX + " minY: " + this.minY
				+ " maxX: " + this.maxX + " maxY: " + this.maxY)
		}
		else
		{
			console.log("(AABB) minX: " + this.minX + " minY: " + this.minY
				+ " maxX: " + this.maxX + " maxY: " + this.maxY)
		}
	}
}
