
class Matrix3
{
	constructor(matrix)
	{
		if(matrix) {
			this.m = new Float32Array(matrix)
		}
		else {
			this.m = new Float32Array(9)
			this.m[0] = 1.0
			this.m[4] = 1.0
			this.m[8] = 1.0
		}
	}

	copy(src) {
		this.m.set(src.m)
	}

	clone() {
		const m = new Matrix3(this.m)
		return m
	}

	set(matrix) {
		this.m.assing(matrix)
	}

	identity()
	{
		this.m[0] = 1.0
		this.m[1] = 0.0
		this.m[2] = 0.0

		this.m[3] = 0.0
		this.m[4] = 1.0
		this.m[5] = 0.0

		this.m[6] = 0.0
		this.m[7] = 0.0
		this.m[8] = 1.0
	}

	translate(x, y)
	{
		const a00 = this.m[0]
		const a01 = this.m[1]
		const a02 = this.m[2]
		const a10 = this.m[3]
		const a11 = this.m[4]
		const a12 = this.m[5]
		const a20 = this.m[6]
		const a21 = this.m[7]
		const a22 = this.m[8]

		this.m[0] = a00
		this.m[1] = a01
		this.m[2] = a02

		this.m[3] = a10
		this.m[4] = a11
		this.m[5] = a12

		this.m[6] = x * a00 + y * a10 + a20
		this.m[7] = x * a01 + y * a11 + a21
		this.m[8] = x * a02 + y * a12 + a22
	}

	rotate(rad)
	{
		const a00 = this.m[0]
		const a01 = this.m[1]
		const a02 = this.m[2]
		const a10 = this.m[3]
		const a11 = this.m[4]
		const a12 = this.m[5]

		const s = Math.sin(rad)
		const c = Math.cos(rad)

		this.m[0] = c * a00 + s * a10
		this.m[1] = c * a01 + s * a11
		this.m[2] = c * a02 + s * a12

		this.m[3] = c * a10 - s * a00
		this.m[4] = c * a11 - s * a01
		this.m[5] = c * a12 - s * a02
	}

	scale(x, y)
	{
		this.m[0] *= x
		this.m[1] *= x
		this.m[2] *= x

		this.m[3] *= y
		this.m[4] *= y
		this.m[5] *= y
	}

	mul(src)
	{
		const a00 = this.m[0]
		const a01 = this.m[1]
		const a02 = this.m[2]
		const a10 = this.m[3]
		const a11 = this.m[4]
		const a12 = this.m[5]
		const a20 = this.m[6]
		const a21 = this.m[7]
		const a22 = this.m[8]

		const b00 = src.m[0]
		const b01 = src.m[1]
		const b02 = src.m[2]
		const b10 = src.m[3]
		const b11 = src.m[4]
		const b12 = src.m[5]
		const b20 = src.m[6]
		const b21 = src.m[7]
		const b22 = src.m[8]

		this.m[0] = b00 * a00 + b01 * a10 + b02 * a20
		this.m[1] = b00 * a01 + b01 * a11 + b02 * a21
		this.m[2] = b00 * a02 + b01 * a12 + b02 * a22

		this.m[3] = b10 * a00 + b11 * a10 + b12 * a20
		this.m[4] = b10 * a01 + b11 * a11 + b12 * a21
		this.m[5] = b10 * a02 + b11 * a12 + b12 * a22

		this.m[6] = b20 * a00 + b21 * a10 + b22 * a20
		this.m[7] = b20 * a01 + b21 * a11 + b22 * a21
		this.m[8] = b20 * a02 + b21 * a12 + b22 * a22
	}

	transpose()
	{
		const m01 = this.m[1]
		const m02 = this.m[2]
		const m12 = this.m[5]

		this.m[1] = this.m[3]
		this.m[2] = this.m[6]
		this.m[3] = m01
		this.m[5] = this.m[7]
		this.m[6] = m02
		this.m[7] = m12
	}

	invert()
	{
		const a00 = this.m[0]
		const a01 = this.m[1]
		const a02 = this.m[2]
		const a10 = this.m[3]
		const a11 = this.m[4]
		const a12 = this.m[5]
		const a20 = this.m[6]
		const a21 = this.m[7]
		const a22 = this.m[8]

		const b01 = a22 * a11 - a12 * a21
		const b11 = -a22 * a10 + a12 * a20
		const b21 = a21 * a10 - a11 * a20

		let det = a00 * b01 + a01 * b11 + a02 * b21

		if(!det) {
			this.identity()
			return
		}

		det = 1.0 / det

		this.m[0] = b01 * det
		this.m[1] = (-a22 * a01 + a02 * a21) * det
		this.m[2] = (a12 * a01 - a02 * a11) * det
		this.m[3] = b11 * det
		this.m[4] = (a22 * a00 - a02 * a20) * det
		this.m[5] = (-a12 * a00 + a02 * a10) * det
		this.m[6] = b21 * det
		this.m[7] = (-a21 * a00 + a01 * a20) * det
		this.m[8] = (a11 * a00 - a01 * a10) * det
	}

	normalFromMatrix4(src)
	{
		const a00 = src.m[0]
		const a01 = src.m[1]
		const a02 = src.m[2]
		const a03 = src.m[3]
		const a10 = src.m[4]
		const a11 = src.m[5]
		const a12 = src.m[6]
		const a13 = src.m[7]
		const a20 = src.m[8]
		const a21 = src.m[9]
		const a22 = src.m[10]
		const a23 = src.m[11]
		const a30 = src.m[12]
		const a31 = src.m[13]
		const a32 = src.m[14]
		const a33 = src.m[15]

		const b00 = a00 * a11 - a01 * a10
		const b01 = a00 * a12 - a02 * a10
		const b02 = a00 * a13 - a03 * a10
		const b03 = a01 * a12 - a02 * a11
		const b04 = a01 * a13 - a03 * a11
		const b05 = a02 * a13 - a03 * a12
		const b06 = a20 * a31 - a21 * a30
		const b07 = a20 * a32 - a22 * a30
		const b08 = a20 * a33 - a23 * a30
		const b09 = a21 * a32 - a22 * a31
		const b10 = a21 * a33 - a23 * a31
		const b11 = a22 * a33 - a23 * a32

		let det = (b00 * b11) - (b01 * b10) + (b02 * b09) + (b03 * b08) - (b04 * b07) + (b05 * b06)

		if(!det) {
			this.identity()
			return
		}

		det = 1.0 / det

		this.m[0] = (a11 * b11 - a12 * b10 + a13 * b09) * det
		this.m[1] = (a12 * b08 - a10 * b11 - a13 * b07) * det
		this.m[2] = (a10 * b10 - a11 * b08 + a13 * b06) * det

		this.m[3] = (a02 * b10 - a01 * b11 - a03 * b09) * det
		this.m[4] = (a00 * b11 - a02 * b08 + a03 * b07) * det
		this.m[5] = (a01 * b08 - a00 * b10 - a03 * b06) * det

		this.m[6] = (a31 * b05 - a32 * b04 + a33 * b03) * det
		this.m[7] = (a32 * b02 - a30 * b05 - a33 * b01) * det
		this.m[8] = (a30 * b04 - a31 * b02 + a33 * b00) * det
	}

	fromMatrix4(src)
	{
		this.m[0] = src.m[0]
		this.m[1] = src.m[1]
		this.m[2] = src.m[2]
		this.m[3] = src.m[4]
		this.m[4] = src.m[5]
		this.m[5] = src.m[6]
		this.m[6] = src.m[8]
		this.m[7] = src.m[9]
		this.m[8] = src.m[10]
	}

	fromQuaternion(q)
	{
		const x = q.x
		const y = q.y
		const z = q.z
		const w = q.w

		const x2 = x + x
		const y2 = y + y
		const z2 = z + z

		const xx = x * x2
		const yx = y * x2
		const yy = y * y2
		const zx = z * x2
		const zy = z * y2
		const zz = z * z2
		const wx = w * x2
		const wy = w * y2
		const wz = w * z2

		this.m[0] = 1 - yy - zz
		this.m[3] = yx - wz
		this.m[6] = zx + wy

		this.m[1] = yx + wz
		this.m[4] = 1 - xx - zz
		this.m[7] = zy - wx

		this.m[2] = zx - wy
		this.m[5] = zy + wx
		this.m[8] = 1 - xx - yy
	}

	print()
	{
		return `Matrix3(${this.m[0]}, ${this.m[1]}, ${this.m[2]},
         ${this.m[3]}, ${this.m[4]}, ${this.m[5]},
         ${this.m[6]}, ${this.m[7]}, ${this.m[8]})`
	}
}

export default Matrix3
