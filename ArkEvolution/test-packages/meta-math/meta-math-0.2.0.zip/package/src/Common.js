
const radians = function(degrees) {
	return degrees * Math.PI / 180
}
 
const degrees = function(radians) {
	return radians * 180 / Math.PI
}

const EPSILON = 0.000001

export {
	radians,
	degrees,
	EPSILON
}