# File: README.md

# meta-math
基于 meta-math 原库 v0.1.7 版本进行适配的 ArkTS 3D 数学库。

## 安装 (Install)
```sh
ohpm install meta-math
```

## 版本说明 (Version Note)
本库已升级适配至 meta-math v0.1.7。

**核心变更 (Key Changes)**：
- **性能重构**：`Vector2` 和 `Vector3` 类进行了底层重构。为了适应 ArkTS 的性能最佳实践，移除了对 `Float32Array` 的强依赖，改为直接使用 `x`, `y`, `z` 属性存储数据。
    - 旧有的 `.v` (Float32Array) 属性改为懒加载（lazy-loaded），仅在调用 `toFloat32Array()` 或访问兼容接口时创建。
- **新功能**：新增了完整的 `Quaternion` (四元数) 模块，用于处理 3D 旋转。
- **API 扩展**：增加了大量标量运算方法（如 `addScalar`）和矩阵辅助方法（如 `Matrix4.lookAt`）。