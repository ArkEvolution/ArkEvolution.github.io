// TS2ArkTS-SessionId-16
export default class AABB {
    constructor(x: any, y: any, width: any, height: any) {
        this.x = x || 0;
        this.y = y || 0;
        this.width = width || 0;
        this.height = height || 0;
        this.halfWidth = this.width / 2;
        this.halfHeight = this.height / 2;
        this.pivotPosX = this.width * this.pivotX;
        this.pivotPosY = this.height * this.pivotY;
        this.minX = this.x;
        this.minY = this.y;
        this.maxX = this.x + this.width;
        this.maxY = this.y + this.height;
    }
    set(x: any, y: any, width: any, height: any): void {
        this.x = x || 0;
        this.y = y || 0;
        this.width = width || 0;
        this.height = height || 0;
        this.halfWidth = this.width / 2;
        this.halfHeight = this.height / 2;
        this.pivotPosX = this.width * this.pivotX;
        this.pivotPosY = this.height * this.pivotY;
        this.minX = this.x;
        this.minY = this.y;
        this.maxX = this.x + this.width;
        this.maxY = this.y + this.height;
    }
    position(x: any, y: any): void {
        this.x = x;
        this.y = y;
        this.minX = this.x - this.pivotPosX;
        this.minY = this.y - this.pivotPosY;
        this.maxX = this.minX + this.width;
        this.maxY = this.minY + this.height;
    }
    move(x: any, y: any): void {
        this.x += x;
        this.y += y;
        this.minX += x;
        this.minY += y;
        this.maxX += x;
        this.maxY += y;
    }
    resize(width: any, height: any): void {
        this.width = width;
        this.height = height;
        this.halfWidth = width / 2;
        this.halfHeight = height / 2;
        this.pivotPosX = this.width * this.pivotX;
        this.pivotPosY = this.height * this.pivotY;
        this.minX = this.x - this.pivotPosX;
        this.minY = this.y - this.pivotPosY;
        this.maxX = this.minX + this.width;
        this.maxY = this.minY + this.height;
    }
    pivot(x: any, y: any): void {
        if (y === undefined) {
            y = x;
        }
        this.pivotX = x;
        this.pivotY = y;
        this.pivotPosX = this.width * this.pivotX;
        this.pivotPosY = this.height * this.pivotY;
        this.minX = this.x - this.pivotPosX;
        this.minY = this.y - this.pivotPosY;
        this.maxX = this.minX + this.width;
        this.maxY = this.minY + this.height;
    }
    vsAABB(src: any): boolean {
        if (this.maxX < src.minX || this.minX > src.maxX) {
            return false;
        }
        if (this.maxY < src.minY || this.minY > src.maxY) {
            return false;
        }
        return true;
    }
    vsBorderAABB(src: any): boolean {
        if (this.maxX <= src.minX || this.minX >= src.maxX) {
            return false;
        }
        if (this.maxY <= src.minY || this.minY >= src.maxY) {
            return false;
        }
        return true;
    }
    vsAABBIntersection(src: any): 0 | 1 | 2 {
        if (this.maxX < src.minX || this.minX > src.maxX) {
            return 0;
        }
        if (this.maxY < src.minY || this.minY > src.maxY) {
            return 0;
        }
        if (this.minX > src.minX || this.minY > src.minY) {
            return 1;
        }
        if (this.maxX < src.maxX || this.maxY < src.maxY) {
            return 1;
        }
        return 2;
    }
    vsPoint(x: any, y: any): boolean {
        if (this.minX > x || this.maxX < x) {
            return false;
        }
        if (this.minY > y || this.maxY < y) {
            return false;
        }
        return true;
    }
    vsBorderPoint(x: any, y: any): boolean {
        if (this.minX >= x || this.maxX <= x) {
            return false;
        }
        if (this.minY >= y || this.maxY <= y) {
            return false;
        }
        return true;
    }
    getSqrDistance(x: any, y: any): number {
        let tmp: number;
        let sqDist = 0;
        if (x < this.minX) {
            tmp = (this.minX - x);
            sqDist += tmp * tmp;
        }
        if (x > this.maxX) {
            tmp = (x - this.maxX);
            sqDist += tmp * tmp;
        }
        if (y < this.minY) {
            tmp = (this.minY - y);
            sqDist += tmp * tmp;
        }
        if (y > this.maxY) {
            tmp = (y - this.maxY);
            sqDist += tmp * tmp;
        }
        return sqDist;
    }
    getDistanceVsAABB(aabb: any): number {
        const centerX: number = (this.minX as any) + (((this.maxX as any) - (this.minX as any)) / 2);
        const centerY: number = (this.minY as any) + (((this.maxY as any) - (this.minY as any)) / 2);
        const srcCenterX: number = (aabb.minX as any) + (((aabb.maxY as any) - (aabb.minY as any)) / 2);
        const srcCenterY: number = (aabb.minY as any) + (((aabb.maxY as any) - (aabb.minY as any)) / 2);
        const diffX = srcCenterX - centerX;
        const diffY = srcCenterY - centerY;
        return Math.sqrt((diffX * diffX) + (diffY * diffY));
    }
    isUndefined(): boolean {
        return (this.maxY === undefined);
    }
    print(str: any): void {
        if (str) {
            console.log("(AABB) " + str + " minX: " + this.minX + " minY: " + this.minY
                + " maxX: " + this.maxX + " maxY: " + this.maxY);
        }
        else {
            console.log("(AABB) minX: " + this.minX + " minY: " + this.minY
                + " maxX: " + this.maxX + " maxY: " + this.maxY);
        }
    }
    x: any;
    y: any;
    width: any;
    height: any;
    halfWidth: number;
    halfHeight: number;
    pivotPosX: number;
    pivotPosY: number;
    minX: any;
    minY: any;
    maxX: any;
    maxY: any;
    pivotX: any;
    pivotY: any;
}
