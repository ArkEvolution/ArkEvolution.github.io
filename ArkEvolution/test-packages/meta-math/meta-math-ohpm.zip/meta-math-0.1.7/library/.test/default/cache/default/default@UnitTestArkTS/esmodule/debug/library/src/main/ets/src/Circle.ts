// TS2ArkTS-SessionId-17
export default class Circle {
    constructor(x: any, y: any, radius: any) {
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.minX = (x as number) - (radius as number);
        this.minY = (y as number) - (radius as number);
        this.maxX = (x as number) + (radius as number);
        this.maxY = (y as number) + (radius as number);
    }
    position(x: any, y: any): void {
        this.x = x;
        this.y = y;
        this.minX = (x as number) - (this.radius as number);
        this.minY = (y as number) - (this.radius as number);
        this.maxX = (x as number) + (this.radius as number);
        this.maxY = (y as number) + (this.radius as number);
    }
    move(addX: any, addY: any): void {
        this.x = (this.x as number) + (addX as number);
        this.y = (this.y as number) + (addY as number);
        this.minX = (this.minX as number) + (addX as number);
        this.minY = (this.minY as number) + (addY as number);
        this.maxX = (this.maxX as number) + (addX as number);
        this.maxY = (this.maxY as number) + (addY as number);
    }
    vsPoint(x: any, y: any): boolean {
        return (((this.x as number) - (x as number)) * 2) + (((this.y as number) - (y as number)) * 2) <= ((this.radius as number) * 2);
    }
    vsAABB(aabb: any): void {
    }
    vsCircle(circle: any): boolean {
        const dx = ((circle as Record<string, any>).x as number) - (this.x as number);
        const dy = ((circle as Record<string, any>).y as number) - (this.y as number);
        const radii = (this.radius as number) + ((circle as Record<string, any>).radius as number);
        if ((dx * dx) + (dy * dy) < (radii * radii)) {
            return true;
        }
        return false;
    }
    overlapCircle(circle: any): 0 | 1 | 2 {
        const distance = Math.sqrt(((this.x as number) - ((circle as Record<string, any>).x as number)) * ((this.y as number) - ((circle as Record<string, any>).y as number)));
        if (distance > ((this.radius as number) + ((circle as Record<string, any>).radius as number))) {
            return 0;
        }
        // Overlap:
        else if (distance <= Math.abs((this.radius as number) + ((circle as Record<string, any>).radius as number))) {
            return 1;
        }
        return 2;
    }
    print(str: any): void {
        if (str) {
            console.log("[" + str + "] x:", this.x, "y:", this.y, "raidus:", this.radius);
        }
        else {
            console.log("x:", this.x, "y:", this.y, "raidus:", this.radius);
        }
    }
    x: any;
    y: any;
    radius: any;
    minX: number;
    minY: number;
    maxX: any;
    maxY: any;
}
