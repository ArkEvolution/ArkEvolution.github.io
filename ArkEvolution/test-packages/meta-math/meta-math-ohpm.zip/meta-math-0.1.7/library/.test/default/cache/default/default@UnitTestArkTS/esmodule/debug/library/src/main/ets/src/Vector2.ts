export default class Vector2 {
    x: number;
    y: number;
    v: Float32Array | null;
    constructor(x?: number, y?: number) {
        this.x = x || 0.0;
        this.y = y || 0.0;
        this.v = null;
    }
    reset(): void {
        this.x = 0.0;
        this.y = 0.0;
    }
    set(x: number, y: number): void {
        this.x = x;
        this.y = y;
    }
    add(x: number, y: number): void {
        this.x += x;
        this.y += y;
    }
    addScalar(value: number): void {
        this.x += value;
        this.y += value;
    }
    addValues(x: number, y: number): void {
        this.x += x;
        this.y += y;
    }
    addVec(vec: Vector2): void {
        this.x += vec.x;
        this.y += vec.y;
    }
    sub(x: number, y: number): void {
        this.x -= x;
        this.y -= y;
    }
    subScalar(value: number): void {
        this.x -= value;
        this.y -= value;
    }
    subValues(x: number, y: number): void {
        this.x -= x;
        this.y -= y;
    }
    subVec(vec: Vector2): void {
        this.x -= vec.x;
        this.y -= vec.y;
    }
    mul(x: number, y: number): void {
        this.x *= x;
        this.y *= y;
    }
    mulScalar(value: number): void {
        this.x *= value;
        this.y *= value;
    }
    mulValues(x: number, y: number): void {
        this.x *= x;
        this.y *= y;
    }
    mulVec(vec: Vector2): void {
        this.x *= vec.x;
        this.y *= vec.y;
    }
    div(x: number, y: number): void {
        this.x /= x;
        this.y /= y;
    }
    divScalar(value: number): void {
        this.x /= value;
        this.y /= value;
    }
    divValues(x: number, y: number): void {
        this.x /= x;
        this.y /= y;
    }
    divVec(vec: Vector2): void {
        this.x /= vec.x;
        this.y /= vec.y;
    }
    length(): number {
        return Math.sqrt((this.x * this.x) + (this.y * this.y));
    }
    normalize(): void {
        const length = Math.sqrt((this.x * this.x) + (this.y * this.y));
        if (length > 0) {
            this.x /= length;
            this.y /= length;
        }
        else {
            this.x = 0;
            this.y = 0;
        }
    }
    dot(vec: Vector2): number {
        return ((this.x * this.x) + (this.y * this.y));
    }
    truncate(max: number): void {
        const length = Math.sqrt((this.x * this.x) + (this.y * this.y));
        if (length > max) {
            this.x *= max / length;
            this.y *= max / length;
        }
    }
    limit(max: number): void {
        if (this.x > max) {
            this.x = max;
        }
        else if (this.x < -max) {
            this.x = -max;
        }
        if (this.y > max) {
            this.y = max;
        }
        else if (this.y < -max) {
            this.y = -max;
        }
    }
    clamp(minX: number, minY: number, maxX: number, maxY: number): void {
        this.x = Math.min(Math.max(this.x, minX), maxX);
        this.y = Math.min(Math.max(this.y, minY), maxY);
    }
    lengthSq(): number {
        return ((this.x * this.x) + (this.y * this.y));
    }
    heading(): number {
        const angle = Math.atan2(-this.y, this.x);
        return -angle + Math.PI * 0.5;
    }
    perp(): void {
        const tmpX = this.x;
        this.x = -this.y;
        this.y = tmpX;
    }
    reflect(normal: Vector2): void {
        const value = this.dot(normal);
        this.x -= 2 * value * normal.x;
        this.y -= 2 * value * normal.y;
    }
    toFloat32Array(): Float32Array {
        if (!this.v) {
            this.v = new Float32Array([this.x, this.y]);
        }
        else {
            this.v[0] = this.x;
            this.v[1] = this.y;
        }
        return this.v;
    }
    print(str?: string): void {
        if (str) {
            console.log(`[vec "${str}"] x: ${this.x} y: ${this.y}`);
        }
        else {
            console.log(`[vec] x: ${this.x} y: ${this.y}`);
        }
    }
}
