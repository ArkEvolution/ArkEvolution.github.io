import { describe, it, expect } from "@normalized:N&&&@ohos/hypium/index&1.0.21";
import Vector2 from "@normalized:N&&&meta-math/src/main/ets/src/Vector2&0.0.1";
import Vector3 from "@normalized:N&&&meta-math/src/main/ets/src/Vector3&0.0.1";
import Matrix3 from "@normalized:N&&&meta-math/src/main/ets/src/Matrix3&0.0.1";
import Matrix4 from "@normalized:N&&&meta-math/src/main/ets/src/Matrix4&0.0.1";
import Quaternion from "@normalized:N&&&meta-math/src/main/ets/src/Quaternion&0.0.1";
import { EPSILON } from "@normalized:N&&&meta-math/src/main/ets/src/Common&0.0.1";
export default function mathTests() {
    describe('MathLibraryTests', () => {
        // 1. 测试 Vector2 的加法和属性访问
        it('Vector2_Add_ShouldUpdateComponents', 0, () => {
            let v1 = new Vector2(1, 2);
            let v2 = new Vector2(3, 4);
            v1.addVec(v2);
            // 验证 x, y 属性更新
            expect(v1.x).assertEqual(4);
            expect(v1.y).assertEqual(6);
            // 验证底层 Float32Array 同步更新 (懒加载机制)
            let arr = v1.toFloat32Array();
            expect(arr[0]).assertEqual(4);
            expect(arr[1]).assertEqual(6);
        });
        // 2. 测试 Vector3 的叉积 (Cross Product)
        it('Vector3_Cross_ShouldReturnPerpendicularVector', 0, () => {
            // X轴 叉乘 Y轴 应该得到 Z轴
            let v1 = new Vector3(1, 0, 0);
            let v2 = new Vector3(0, 1, 0);
            v1.cross(v2);
            expect(v1.x).assertEqual(0);
            expect(v1.y).assertEqual(0);
            expect(v1.z).assertEqual(1);
        });
        // 3. 测试 Vector3 的归一化 (Normalize)
        it('Vector3_Normalize_ShouldResultInUnitLength', 0, () => {
            let v = new Vector3(0, 3, 4); // 长度为 5
            v.normalize();
            expect(v.x).assertEqual(0);
            expect(v.y).assertClose(0.6, EPSILON); // 3/5
            expect(v.z).assertClose(0.8, EPSILON); // 4/5
            expect(v.length()).assertClose(1.0, EPSILON);
        });
        // 4. 测试 Matrix3 的单位矩阵初始化
        it('Matrix3_Identity_ShouldBeInitializedCorrectly', 0, () => {
            let m3 = new Matrix3();
            m3.identity();
            expect(m3.m[0]).assertEqual(1); // m11
            expect(m3.m[4]).assertEqual(1); // m22
            expect(m3.m[8]).assertEqual(1); // m33
            expect(m3.m[1]).assertEqual(0); // m12
        });
        // 5. 测试 Matrix4 的 LookAt 方法
        it('Matrix4_LookAt_ShouldCreateViewMatrix', 0, () => {
            let m4 = new Matrix4();
            let eye = [0, 0, 10];
            let center = [0, 0, 0];
            let up = [0, 1, 0];
            // 从 (0,0,10) 看向原点，这应该是一个简单的平移矩阵的逆矩阵
            m4.lookAt(eye, center, up);
            // 检查位置分量 (m12, m13, m14)
            // 注意：LookAt 生成的是视图矩阵，通常包含旋转和平移
            // 对于这个简单的例子，它应该将相机位置变换到原点
            // 具体数值取决于实现细节（左手/右手坐标系），这里主要测试方法调用不崩溃且有数值变化
            expect(m4.m[15]).assertEqual(1);
            expect(Math.abs(m4.m[14]) > 0).assertTrue(); // Z translation component should exist
        });
        // 6. 测试 Vector3 应用 Matrix4 变换 (位移)
        it('Vector3_ApplyMatrix4_Translation', 0, () => {
            let v = new Vector3(1, 1, 1);
            let m4 = new Matrix4();
            m4.identity();
            m4.translate(2, 3, 4); // x+2, y+3, z+4
            v.applyMatrix4(m4);
            expect(v.x).assertEqual(3);
            expect(v.y).assertEqual(4);
            expect(v.z).assertEqual(5);
        });
        // 7. 测试 Quaternion 设置轴角旋转
        it('Quaternion_SetAxisAngle_ShouldCreateCorrectValues', 0, () => {
            let q = new Quaternion();
            // 绕 Y 轴旋转 180 度 (PI)
            q.setAxisAngle(Math.PI, 0, 1, 0);
            // cos(PI/2) = 0 (w), sin(PI/2) = 1 (xyz * 1)
            // 修复：使用 < EPSILON 替代 assertClose(0, ...) 以避免 assertClose 在接近 0 时使用相对误差导致测试失败
            expect(Math.abs(q.m[0]) < EPSILON).assertTrue(); // x
            expect(q.m[1]).assertClose(1, EPSILON); // y
            expect(Math.abs(q.m[2]) < EPSILON).assertTrue(); // z
            expect(Math.abs(q.m[3]) < EPSILON).assertTrue(); // w
        });
        // 8. 测试 Vector3 应用 Quaternion 旋转
        it('Vector3_ApplyQuaternion_ShouldRotateVector', 0, () => {
            let v = new Vector3(1, 0, 0); // X 轴向量
            let q = new Quaternion();
            // 绕 Y 轴旋转 90 度 (PI/2) -> X 轴向量应该变为 -Z 或 Z (取决于坐标系手性)
            q.setAxisAngle(Math.PI / 2, 0, 1, 0);
            v.applyQuaternion(q);
            // 修复：同上，对接近 0 的值使用直接比较
            expect(Math.abs(v.x) < EPSILON).assertTrue();
            expect(Math.abs(v.y) < EPSILON).assertTrue();
            // 长度应保持为 1
            expect(v.length()).assertClose(1.0, EPSILON);
        });
        // 9. 测试 Matrix4 的透视投影 (Perspective)
        it('Matrix4_Perspective_ShouldNotBeIdentity', 0, () => {
            let m4 = new Matrix4();
            m4.perspective(Math.PI / 4, 1.6, 0.1, 100);
            // 透视矩阵不应该是单位矩阵
            expect(m4.m[0]).not().assertEqual(1);
            expect(m4.m[11]).assertEqual(-1); // 标准透视矩阵的特征
        });
        // 10. 测试 Vector2 的距离计算
        it('Vector3_DistanceTo_ShouldReturnCorrectDistance', 0, () => {
            let v1 = new Vector3(0, 0, 0);
            let v2 = new Vector3(3, 4, 0);
            let dist = v1.distanceTo(v2);
            expect(dist).assertEqual(5); // 3-4-5 三角形
        });
    });
}
