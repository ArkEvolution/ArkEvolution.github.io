import mathTests from "@normalized:N&&&meta-math/src/test/MathTests.test&0.0.1";
export default function testsuite() {
    mathTests();
}
