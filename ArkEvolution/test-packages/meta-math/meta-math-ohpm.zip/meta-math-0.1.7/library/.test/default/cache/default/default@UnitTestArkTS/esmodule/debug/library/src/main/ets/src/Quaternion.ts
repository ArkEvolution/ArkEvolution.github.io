import Vector3 from "@normalized:N&&&meta-math/src/main/ets/src/Vector3&0.0.1";
const tmpVec3 = new Vector3(0.0, 0.0, 0.0);
export default class Quaternion {
    m: Float32Array;
    constructor() {
        this.m = new Float32Array([0.0, 0.0, 0.0, 1.0]);
    }
    copy(src: Quaternion): void {
        this.m.set(src.m);
    }
    clone(): Quaternion {
        const newQuat = new Quaternion();
        newQuat.m.set(this.m);
        return newQuat;
    }
    identity(): void {
        this.m[0] = 0.0;
        this.m[1] = 0.0;
        this.m[2] = 0.0;
        this.m[3] = 1.0;
    }
    mul(src: Quaternion): void {
        const ax = this.m[0];
        const ay = this.m[1];
        const az = this.m[2];
        const aw = this.m[3];
        const bx = src.m[0];
        const by = src.m[1];
        const bz = src.m[2];
        const bw = src.m[3];
        this.m[0] = (ax * bw) + (aw * bx) + (ay * bz) - (az * by);
        this.m[1] = (ay * bw) + (aw * by) + (az * bx) - (ax * bz);
        this.m[2] = (az * bw) + (aw * bz) + (ax * by) - (ay * bx);
        this.m[3] = (aw * bw) - (ax * bx) - (ay * by) - (az * bz);
    }
    setAxisAngle(rad: number, x: number, y: number, z: number): void {
        rad *= 0.5;
        const sin = Math.sin(rad);
        this.m[0] = sin * x;
        this.m[1] = sin * y;
        this.m[2] = sin * z;
        this.m[3] = Math.cos(rad);
    }
    getAxisAngle(): number[] {
        const rad = Math.acos(this.m[3]) * 2.0;
        const sin = Math.sin(rad / 2.0);
        const result = new Array<number>(4);
        if (sin != 0.0) {
            result[1] = this.m[0] / sin;
            result[2] = this.m[1] / sin;
            result[3] = this.m[2] / sin;
        }
        else {
            result[1] = 1.0;
            result[2] = 0.0;
            result[3] = 0.0;
        }
        result[0] = rad;
        return result;
    }
    rotateX(rad: number): void {
        rad *= 0.5;
        const ax = this.m[0];
        const ay = this.m[1];
        const az = this.m[2];
        const aw = this.m[3];
        const bx = Math.sin(rad);
        const bw = Math.cos(rad);
        this.m[0] = (ax * bw) + (aw * bx);
        this.m[1] = (ay * bw) + (az * bx);
        this.m[2] = (az * bw) - (ay * bx);
        this.m[3] = (aw * bw) - (ax * bx);
    }
    rotateY(rad: number): void {
        rad *= 0.5;
        const ax = this.m[0];
        const ay = this.m[1];
        const az = this.m[2];
        const aw = this.m[3];
        const bx = Math.sin(rad);
        const bw = Math.cos(rad);
        this.m[0] = (ax * bw) - (az * bx);
        this.m[1] = (ay * bw) + (aw * bx);
        this.m[2] = (az * bw) + (ax * bx);
        this.m[3] = (aw * bw) - (ay * bx);
    }
    rotateZ(rad: number): void {
        rad *= 0.5;
        const ax = this.m[0];
        const ay = this.m[1];
        const az = this.m[2];
        const aw = this.m[3];
        const bx = Math.sin(rad);
        const bw = Math.cos(rad);
        this.m[0] = (ax * bw) + (ay * bx);
        this.m[1] = (ay * bw) - (ax * bx);
        this.m[2] = (az * bw) + (aw * bx);
        this.m[3] = (aw * bw) - (az * bx);
    }
    calculateW(): void {
        const x = this.m[0];
        const y = this.m[1];
        const z = this.m[2];
        this.m[3] = Math.sqrt(Math.abs(1.0 - (x * x) - (y * y) - (z * z)));
    }
    conjugate(): void {
        this.m[0] = -this.m[0];
        this.m[1] = -this.m[1];
        this.m[2] = -this.m[2];
    }
    print(txt?: string): void {
        if (txt) {
            console.log(`${txt} Quaternion(${this.m[0]}, ${this.m[1]}, ${this.m[2]}, ${this.m[3]})`);
        }
        else {
            console.log(`Quaternion(${this.m[0]}, ${this.m[1]}, ${this.m[2]}, ${this.m[3]})`);
        }
    }
}
