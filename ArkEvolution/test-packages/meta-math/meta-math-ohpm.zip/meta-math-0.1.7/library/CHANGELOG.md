# File: CHANGELOG.md

# Changelog

## [v0.1.7] 
### Added
- **Quaternion**: 新增 `Quaternion` 类，支持四元数的基本运算、轴角设置 (`setAxisAngle`)、旋转操作 (`rotateX/Y/Z`) 及与向量的交互。
- **Matrix4**: 新增 `lookAt(eye, center, up)` 方法，用于生成视图矩阵。
- **Color**: 新增基础 `Color` 类结构。
- **Common**: 新增 `EPSILON` 常量定义，用于浮点数精度比较。
- **Vector2/Vector3**:
    - 新增 `toFloat32Array()` 方法，用于获取兼容 WebGL 的类型化数组。
    - 新增标量运算系列方法：`addScalar`, `subScalar`, `mulScalar`, `divScalar`。
    - 新增值运算系列方法：`addValues`, `subValues`, `mulValues`, `divValues`。
    - **Vector3**: 新增 `lerp` (线性插值), `cross` (叉积), `distanceTo`, `distanceToSquared`, `applyMatrix4`, `applyQuaternion` 等方法。

### Changed
- **Refactoring (Breaking Change)**:
    - `Vector2` 和 `Vector3` 的构造函数不再默认创建 `Float32Array`。数据现在存储在 `this.x`, `this.y`, `(this.z)` 属性中以提高性能。
    - 涉及底层 `this.v` 访问的代码建议迁移至新的属性访问方式，或使用 `toFloat32Array()` 获取数组引用。
- **Matrix4**:
    - 优化了 `rotate` 方法中的向量归一化逻辑，增加了 `EPSILON` 检查以防止除零错误。
    - 修复了 `applyMatrix4` 中引用错误的变量名 bug。

### Fixed
- 修正了 `Quaternion` 原始实现中 `mul` 方法未定义 `out` 变量的问题。
- 修正了 `Quaternion` 中 `getAxisAngle` 方法变量引用错误 (`s` -> `sin`)。

## [v0.1.1] 2025.08
- 基于[meta-math-0.1.1]()原库0.1.1版本进行适配
