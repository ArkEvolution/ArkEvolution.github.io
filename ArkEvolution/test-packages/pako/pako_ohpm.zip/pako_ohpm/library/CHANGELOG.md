# Changelog
## [v1.0.0] 2025.03
- 基于[pako](https://www.npmjs.com/package/pako)原库2.1.0版本进行适配
## [v1.0.1] 2025.03
- 基于[pako](https://www.npmjs.com/package/pako)原库2.1.0版本进行适配，支持 @kit.ArkTS.util.TextEncoder
## [v1.0.2] 2025.03
- 基于[pako](https://www.npmjs.com/package/pako)原库2.1.0版本进行适配，压缩成单独文件pako.ets
## [v1.0.3] 2025.03
- 基于[pako](https://www.npmjs.com/package/pako)原库2.1.0版本进行适配，支持taskpool多线程并发