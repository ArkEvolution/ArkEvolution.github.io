# pako
基于pako原库2.1.0版本进行适配, 所有功能代码已经转换为`ArkTS`文件

## Install
```sh
ohpm install pako_arkts
```

Examples / API
--------------

```javascript
import * as Pako from 'pako_arkts'
const chunk1 = new Uint8Array([1, 2, 3, 4, 5, 6, 7, 8, 9]);
const chunk2 = new Uint8Array([10, 11, 12, 13, 14, 15, 16, 17, 18, 19]);
const chunk3 = new Uint8Array([101, 111, 121, 131, 141, 151, 161, 171, 181, 191]);

const deflate = new Pako.Deflate({ level: 3, strategy: Pako.constants.Z_HUFFMAN_ONLY });

deflate.push(chunk1, false);
deflate.push(chunk3, Pako.constants.Z_PARTIAL_FLUSH);
deflate.push(chunk2, true); // true -> last chunk

if (deflate.err !== Pako.constants.Z_OK) {
  throw new Error(deflate.err.toString());
}

console.log(deflate.result)
```

Notes
-----

Pako does not contain some specific zlib functions:

- __deflate__ -  methods `deflateCopy`, `deflateBound`, `deflateParams`,
  `deflatePending`, `deflatePrime`, `deflateTune`.
- __inflate__ - methods `inflateCopy`, `inflateMark`,
  `inflatePrime`, `inflateGetDictionary`, `inflateSync`, `inflateSyncPoint`, `inflateUndermine`.
- High level inflate/deflate wrappers (classes) may not support some flush
  modes.

License
-------

- MIT - all files, except `/lib/zlib` folder
- ZLIB - `/lib/zlib` content
