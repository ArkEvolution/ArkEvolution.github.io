import { appTasks } from '@ohos/hvigor-ohos-plugin';

export default {
/* Built-in plugin of Hvigor. It cannot be modified. */
    system: appTasks,
/* Custom plugin to extend the functionality of Hvigor. */
    plugins:[]
}