import MathTestSuite from "@normalized:N&&&emath/src/test/unit.test&0.0.2";
export default function testsuite() {
    MathTestSuite();
}
