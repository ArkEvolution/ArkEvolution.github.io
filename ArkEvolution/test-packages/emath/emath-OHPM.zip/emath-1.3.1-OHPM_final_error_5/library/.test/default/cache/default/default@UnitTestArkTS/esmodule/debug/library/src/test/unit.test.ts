import { fractions, expression, MCF, LCM, primeFact, isPrime } from "@normalized:N&&&emath/src/main/ets/lib/number&0.0.2";
import { max, min, sort_min } from "@normalized:N&&&emath/src/main/ets/lib/compare&0.0.2";
import { describe, it, expect } from "@normalized:N&&&@ohos/hypium/index&1.0.21";
export default function MathTestSuite() {
    describe('FractionsTest', () => {
        it('should_create_fraction_correctly', 0, () => {
            const f = new fractions(4, 2);
            expect(f.denominator).assertEqual(4);
            expect(f.numerator).assertEqual(2);
        });
        it('should_calculate_value_correctly', 0, () => {
            // 2 / 4 = 0.5
            const f = new fractions(4, 2);
            expect(f.value()).assertEqual(0.5);
        });
        it('should_throw_error_when_denominator_is_zero', 0, () => {
            try {
                new fractions(0, 1);
                expect(true).assertFalse(); // 不应到达这里
            }
            catch (e) {
                expect(e.message).assertEqual("Denominator can't is 0!");
            }
        });
        it('should_reduce_fraction', 0, () => {
            const f = new fractions(10, 5);
            const reduced = f.reduction();
            expect(reduced.denominator).assertEqual(2);
            expect(reduced.numerator).assertEqual(1);
        });
    });
    describe('NumberUtilsTest', () => {
        it('should_detect_prime_numbers', 0, () => {
            expect(isPrime(7)).assertTrue();
            expect(isPrime(10)).assertFalse();
        });
        it('should_factorize_prime_numbers', 0, () => {
            const factors = primeFact(12);
            expect(factors.length).assertEqual(3);
            // 12 = 2 * 2 * 3
            expect(factors.sort().toString()).assertEqual([2, 2, 3].sort().toString());
        });
        it('should_calculate_MCF_and_LCM', 0, () => {
            // 注意：当前库代码实现的 MCF 返回的是最大共享质因数
            // 12(2,2,3) 与 18(2,3,3) 的共享质因数集合为 [2,2,3]，其中最大值为 3
            expect(MCF(12, 18)).assertEqual(3);
            // LCM 依赖于 MCF 的结果：(12/3) * (18/3) * 3 = 72
            expect(LCM(12, 18)).assertEqual(72);
        });
    });
    describe('ExpressionTest', () => {
        it('should_parse_basic_expression', 0, () => {
            // 库代码已实现优先级：1 + (2 * 3) = 7
            expect(expression("1 + 2 * 3")).assertEqual(7);
        });
        it('should_parse_division', 0, () => {
            expect(expression("10 / 5")).assertEqual(2);
        });
        it('should_parse_multiple_expressions_as_array', 0, () => {
            // 库代码要求使用连续的等号（=====）作为多表达式定界符来返回数组
            const multiExp = "1 + 1\n=====\n5 * 2";
            const result = expression(multiExp) as number[];
            expect(Array.isArray(result)).assertTrue();
            expect(result[0]).assertEqual(2);
            expect(result[1]).assertEqual(10);
        });
        it('should_parse_multi_line_fraction', 0, () => {
            // 测试库中通过 "-" 重复构建的分数线格式
            const fractionExp = "4 + 6\n-----\n2 + 3";
            const result = expression(fractionExp);
            expect(result).assertEqual(2); // (4+6)/(2+3) = 10/5 = 2
        });
    });
    describe('CompareTest', () => {
        it('should_find_max_and_min', 0, () => {
            const list = [10, 5, 20, 1];
            expect(max(list)).assertEqual(20);
            expect(min(list)).assertEqual(1);
        });
        it('should_sort_numeric_arrays', 0, () => {
            const list = [3, 1, 2];
            const sorted = sort_min(list) as number[];
            expect(sorted[0]).assertEqual(1);
            expect(sorted[2]).assertEqual(3);
        });
    });
}
