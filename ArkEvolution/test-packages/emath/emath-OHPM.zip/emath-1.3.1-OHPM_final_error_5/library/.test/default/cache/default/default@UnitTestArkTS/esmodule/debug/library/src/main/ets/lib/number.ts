import { stack } from "@normalized:N&&&emath/src/main/ets/lib/dataStruct&0.0.2";
// Default value of infinity
let inf = 100;
export function setInf(num: number): void {
    inf = num;
}
export class fractions {
    denominator: number;
    numerator: number;
    constructor(denominator: number, numerator: number) {
        this.denominator = denominator;
        this.numerator = numerator;
        if (this.denominator === 0) {
            throw new Error("Denominator can't is 0!");
        }
    }
    value(): number {
        return (this.numerator / this.denominator);
    }
    reduction(): fractions {
        // Note: Assuming 'maximum' implies GCD logic from context or helper
        const gcdValue = this.gcd(this.denominator, this.numerator);
        const newFraction = new fractions(this.denominator / gcdValue, this.numerator / gcdValue);
        return newFraction;
    }
    toReduction(): void {
        const reductionNumber = this.reduction();
        this.denominator = reductionNumber.denominator;
        this.numerator = reductionNumber.numerator;
    }
    private gcd(a: number, b: number): number {
        if (b === 0) {
            return a;
        }
        return this.gcd(b, a % b);
    }
}
interface OptPriority {
    opt: string;
    priority: number;
}
interface NumResult {
    num: number;
    index: number;
}
interface FillItem {
    name: string;
    value: string;
}
export interface SigmaInit {
    name: string;
    value: number;
}
/**
 * Parse the expression of the string arithmetic and get the result.
 */
export function expression(exp: string): number | number[] {
    const lines: string[] = exp.split("\n");
    const exps: string[] = exp.split(/={5,}/g);
    if (exps.length > 1) {
        // Many expressions
        const reses: number[] = [];
        for (let i = 0; i < exps.length; i++) {
            const result = expression(exps[i]);
            if (typeof result === 'number') {
                reses.push(result);
            }
            // Note: Nested arrays not fully supported in this return type to keep it simple,
            // but logic follows diff.
        }
        return reses;
    }
    else {
        // Check for Sigma or Fraction formats
        // Condition: No special chars like _, \, and not "x(..)=.." and not "==" and not "--"
        if (exp.search(/[_\\]/g) === -1 &&
            exp.search(/[a-zA-z]\s*\([\s\S]*\)\s*=/g) === -1 &&
            exp.search(/={2,}/g) === -1 &&
            exp.search(/-{2,}/g) === -1) {
            // Four arithmetic operation (The core Stack-based parser)
            // Handle negative numbers: (-5) -> (0-5)
            exp = exp.replace(/\(\s*(-\d+\.{0,1}\d*\s*)\)/g, "0" + "$1");
            const optArr: OptPriority[] = [
                { opt: '+', priority: 1 },
                { opt: '-', priority: 1 },
                { opt: '*', priority: 2 },
                { opt: '/', priority: 2 },
                { opt: '%', priority: 2 },
            ];
            const priority = (opt: string): number => {
                for (let i = 0; i < optArr.length; i++) {
                    if (opt == optArr[i].opt)
                        return optArr[i].priority;
                }
                return -1;
            };
            const isNum = (c: string): boolean => {
                return c >= '0' && c <= '9';
            };
            const toNum = (str: string, pos: number): NumResult => {
                let sztmp = "";
                let currentPos = pos;
                // Loop while char is digit, dot, or power symbol
                while (currentPos < str.length &&
                    ((str[currentPos] >= '0' && str[currentPos] <= '9') ||
                        str[currentPos] == '.' ||
                        str[currentPos] == "^")) {
                    sztmp += str.charAt(currentPos);
                    currentPos++;
                }
                // Handle power ^
                const sztmpArr = sztmp.split("^");
                let val = Number(sztmpArr[sztmpArr.length - 1]);
                for (let i = sztmpArr.length - 2; i >= 0; i--) {
                    val = Math.pow(Number(sztmpArr[i]), val);
                }
                return { num: val, index: currentPos };
            };
            const numStack = new stack<number>();
            const optStack = new stack<string>();
            let i = 0;
            while (true) {
                if (i >= exp.length && optStack.empty()) {
                    break;
                }
                if (i < exp.length && exp.charAt(i).match(/\s/)) {
                    i++;
                }
                else if (i < exp.length && isNum(exp.charAt(i))) {
                    const tmp = toNum(exp, i);
                    numStack.push(tmp.num);
                    i = tmp.index;
                }
                else {
                    // Operator or brackets
                    if (i >= exp.length && optStack.empty()) {
                        break;
                    }
                    if (optStack.empty()) {
                        if (i < exp.length) {
                            optStack.push(exp.charAt(i));
                            i++;
                        }
                        else {
                            break; // Safety break
                        }
                    }
                    else {
                        const topOpt = optStack.top();
                        if (i < exp.length && (exp.charAt(i) == "(" || (topOpt && priority(exp.charAt(i)) > priority(topOpt)))) {
                            optStack.push(exp.charAt(i));
                            i++;
                        }
                        else if (i < exp.length && exp.charAt(i) == ")" && topOpt == "(") {
                            optStack.pop();
                            i++;
                        }
                        else {
                            // Calculate
                            const opttmp = optStack.pop();
                            const numa = numStack.pop();
                            const numb = numStack.pop();
                            if (opttmp && numa !== undefined && numb !== undefined) {
                                let res = 0;
                                switch (opttmp) {
                                    case "+":
                                        res = numb + numa;
                                        break;
                                    case "-":
                                        res = numb - numa;
                                        break;
                                    case "*":
                                        res = numb * numa;
                                        break;
                                    case "/":
                                        res = numb / numa;
                                        break;
                                    case "%":
                                        res = numb % numa;
                                        break;
                                    default:
                                        throw new Error("Don't have this operator!");
                                }
                                numStack.push(res);
                            }
                            // Note: If i hasn't advanced, we loop again to compare the current char with the new top
                        }
                    }
                }
            }
            return numStack.top() ?? 0;
        }
        else if (exp.search(/==/g) !== -1) {
            // Sigma / Summation logic
            // Structure assumption based on diff:
            // z
            // ==
            //  /
            //  | expression
            //  \
            // ==
            // x=y
            let index = -1;
            const fills: FillItem[] = [];
            let tmp: string[];
            for (let i = 0; i < lines.length; i++) {
                if (lines[i].search(/\s*==\s*/) !== -1) {
                    index = i - 1;
                    break;
                }
            }
            if (lines[1] != "==") {
                // Complex sigma
                for (let i = 0; i < index; i++) {
                    if (lines[i].search(/^\s*$/) !== -1)
                        continue;
                    tmp = lines[i].replace(/\s*(\S)\s*=\s*(\S)\s*/g, "$1=$2").split("=");
                    if (tmp.length >= 2) {
                        fills.push({ name: tmp[0], value: tmp[1] });
                    }
                }
                let countStr = lines[index];
                let countNum = 0;
                if (countStr.search(/inf/g) !== -1 || countStr.search(/∞/g) !== -1) {
                    countNum = inf;
                }
                else {
                    countNum = Number(countStr);
                }
                let expression_ = "";
                // Extracting expression between the sigma bars
                for (let i = (index + 3); i < (lines.length - 3); i++) {
                    expression_ += lines[i].replace(/^\s\|\s*([\s\S]*)/g, "$1");
                    if ((i + 1) < (lines.length - 3)) {
                        expression_ += "\n";
                    }
                }
                // Apply pre-fills
                for (let i = 0; i < fills.length; i++) {
                    expression_ = expression_.replace(new RegExp(fills[i].name, 'g'), fills[i].value);
                }
                const lastLine = lines[lines.length - 1].split(/\s*=\s*/g);
                return sigma(expression_, countNum, {
                    name: lastLine[0],
                    value: Number(lastLine[1])
                } as SigmaInit);
            }
            else {
                // Simple sigma
                let countStr = lines[0];
                let countNum = 0;
                if (countStr.search(/inf/g) !== -1 || countStr.search(/∞/g) !== -1) {
                    countNum = inf;
                }
                else {
                    countNum = Number(countStr);
                }
                let expression_ = "";
                for (let i = 3; i < (lines.length - 3); i++) {
                    expression_ += lines[i].replace(/^\s\|\s*([\s\S]*)/g, "$1");
                    if ((i + 1) < (lines.length - 3)) {
                        expression_ += "\n";
                    }
                }
                const lastLine = lines[lines.length - 1].split(/\s*=\s*/g);
                return sigma(expression_, countNum, {
                    name: lastLine[0],
                    value: Number(lastLine[1])
                } as SigmaInit);
            }
        }
        else if (exp.search(/-{3,}/g) !== -1) {
            // Fraction representation with dashes
            let maxLine = "";
            for (let i = 0; i < lines.length; i++) {
                if (lines[i].search(/^-+$/g) !== -1) {
                    if (lines[i].length > maxLine.length) {
                        maxLine = lines[i];
                    }
                }
            }
            // Split by the longest dash line
            const tmp = exp.split(maxLine);
            if (tmp.length >= 2) {
                const up = tmp[0];
                const down = tmp[1];
                return (expression(up) as number) / (expression(down) as number);
            }
            return 0;
        }
        else {
            console.error("Expression format not supported or implementation missing.");
            return 0;
        }
    }
}
/**
 * Sigma function
 */
export function sigma(exp: string, count: number, init: SigmaInit): number {
    let sum = 0;
    let newExp: string;
    let currentValue = init.value;
    for (let i = 0; i < count; i++) {
        newExp = exp.replace(new RegExp(init.name, 'g'), currentValue.toString());
        sum += (expression(newExp) as number);
        currentValue++;
    }
    return sum;
}
export function MCF(a: number, b: number): number {
    const primeOfA: number[] = primeFact(a);
    const primeOfB: number[] = primeFact(b);
    const commonFactors: number[] = commonFactor(primeOfA, primeOfB);
    if (commonFactors.length === 0)
        return 1;
    let max: number = commonFactors[0];
    for (let i = 1; i < commonFactors.length; i++) {
        if (max < commonFactors[i]) {
            max = commonFactors[i];
        }
    }
    return max;
}
export function LCM(a: number, b: number): number {
    const MCFA: number = MCF(a, b);
    // Be careful with direct assignment to parameters in ArkTS/TS, logic is fine but stylistic warning
    const newA = a / MCFA;
    const newB = b / MCFA;
    return newA * newB * MCFA;
}
export function commonFactor(a: number[], b: number[]): number[] {
    const commonFactors: number[] = [];
    for (let i = 0; i < a.length; i++) {
        for (let j = 0; j < b.length; j++) {
            if (a[i] === b[j]) {
                commonFactors.push(a[i]);
                // Optimization: break inner loop to avoid duplicates if that's intended,
                // but original diff logic simply pushes. Assuming basic intersection.
                break;
            }
        }
    }
    return commonFactors;
}
export function primeFact(n: number): number[] {
    const primeNumbers: number[] = [];
    const arr: number[] = prime(Math.sqrt(n));
    let tempN = n;
    for (let i = 0; i < arr.length; i++) {
        while (tempN % arr[i] === 0) {
            primeNumbers.push(arr[i]);
            tempN /= arr[i];
        }
    }
    if (tempN !== 1) {
        primeNumbers.push(tempN);
    }
    return primeNumbers;
}
export function prime(max: number): number[] {
    const primes: number[] = [];
    for (let i = 2; i < max; i++) {
        if (isPrime(i)) {
            primes.push(i);
        }
    }
    return primes;
}
export function isPrime(n: number): boolean {
    if (n <= 1)
        return false;
    let yes: boolean = true;
    for (let i: number = 2; i <= Math.sqrt(n); i++) {
        if (n % i == 0) {
            yes = false;
            break;
        }
    }
    return yes;
}
