/**
 * @file dataStruct.ets
 * @desc Data structures implementation (Stack, Queue, PriorityQueue)
 * @author ArkTS Expert
 */
/**
 * Data structure: Stack
 */
export class stack<T> {
    private value: T[] = [];
    constructor() {
        this.value = [];
    }
    /**
     * Get the top value of stack
     */
    top(): T | undefined {
        if (this.value.length === 0) {
            return undefined;
        }
        return this.value[this.value.length - 1];
    }
    /**
     * Remove the last value of stack
     */
    pop(): T | undefined {
        return this.value.pop();
    }
    /**
     * Push value to stack
     */
    push(item: T): void {
        this.value.push(item);
    }
    /**
     * Check if stack is empty
     */
    empty(): boolean {
        return this.value.length === 0;
    }
}
/**
 * Data structure: Queue
 */
export class queue<T> {
    private value: T[] = [];
    constructor() {
        this.value = [];
    }
    /**
     * Get the front value of queue
     */
    front(): T | undefined {
        if (this.value.length === 0) {
            return undefined;
        }
        return this.value[0];
    }
    /**
     * Get the back value of queue
     */
    back(): T | undefined {
        if (this.value.length === 0) {
            return undefined;
        }
        return this.value[this.value.length - 1];
    }
    /**
     * Remove the last value of queue (Note: Standard queue pop usually removes from front,
     * but keeping consistent with provided diff logic which acts more like a stack/list manipulation
     * or the diff implies specific behavior. Based on diff: splice(length-1, 1) removes from back)
     */
    pop(): T | undefined {
        return this.value.pop();
    }
    /**
     * Push value
     */
    push(item: T): void {
        this.value.push(item);
    }
    /**
     * Check if queue is empty
     */
    empty(): boolean {
        return this.value.length === 0;
    }
}
/**
 * Data structure: Priority Queue
 */
export class priority_queue<T> {
    private value: T[] = [];
    constructor() {
        this.value = [];
    }
    /**
     * Get the value with max priority (based on > operator)
     */
    top(): T | undefined {
        if (this.value.length === 0) {
            return undefined;
        }
        return this.value[this.getMaxIndex()];
    }
    front(): T | undefined {
        return this.value[0];
    }
    back(): T | undefined {
        return this.value[this.value.length - 1];
    }
    private getMaxIndex(): number {
        if (this.value.length === 0)
            return -1;
        let index = 0;
        let max = this.value[0];
        for (let i = 1; i < this.value.length; i++) {
            if (max < this.value[i]) {
                max = this.value[i];
                index = i;
            }
        }
        return index;
    }
    /**
     * Remove the max value
     */
    pop(): void {
        const idx = this.getMaxIndex();
        if (idx !== -1) {
            this.value.splice(idx, 1);
        }
    }
    push(item: T): void {
        this.value.push(item);
    }
    empty(): boolean {
        return this.value.length === 0;
    }
}
