import native from "@normalized:N&&&emath/src/main/ets/lib/nativeMath&0.0.2";
import * as number from "@normalized:N&&&emath/src/main/ets/lib/number&0.0.2";
import * as compare from "@normalized:N&&&emath/src/main/ets/lib/compare&0.0.2";
import * as dataStruct from "@normalized:N&&&emath/src/main/ets/lib/dataStruct&0.0.2";
export { native, number, compare, dataStruct };
