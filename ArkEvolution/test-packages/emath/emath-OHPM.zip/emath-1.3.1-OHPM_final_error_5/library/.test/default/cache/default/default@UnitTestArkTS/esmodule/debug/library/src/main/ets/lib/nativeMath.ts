// TS2ArkTS-SessionId-16
export default Math;
