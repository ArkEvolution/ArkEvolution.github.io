import type { fractions } from './number';
// Define a union type for numbers and fractions
export type NumericLike = number | fractions;
export function max(numbers: NumericLike[]): NumericLike {
    let maxNum: number;
    let result: NumericLike = numbers[0];
    if (typeof numbers[0] === "number") {
        maxNum = numbers[0];
    }
    else {
        maxNum = numbers[0].value();
    }
    for (let i = 1; i < numbers.length; i++) {
        let currentValue: number = 0;
        if (typeof numbers[i] === 'number') {
            currentValue = numbers[i] as number;
        }
        else {
            currentValue = (numbers[i] as fractions).value();
        }
        if (currentValue > maxNum) {
            maxNum = currentValue;
            result = numbers[i];
        }
    }
    return result;
}
export function min(numbers: NumericLike[]): NumericLike {
    let minNum: number;
    let result: NumericLike = numbers[0];
    if (typeof numbers[0] === "number") {
        minNum = numbers[0];
    }
    else {
        minNum = numbers[0].value();
    }
    for (let i = 1; i < numbers.length; i++) {
        const currentValue = typeof numbers[i] === "number"
            ? (numbers[i] as number)
            : (numbers[i] as fractions).value();
        if (currentValue < minNum) {
            minNum = currentValue;
            result = numbers[i];
        }
    }
    return result;
}
/**
 * Sort numbers with a custom comparator
 * @param numbers Array of numbers
 * @param cmp Comparator function returning boolean (true if swap needed/condition met)
 */
export function sort(numbers: number[], cmp: (a: number, b: number) => boolean): number[] {
    let tmp: number;
    for (let i = 0; i < numbers.length; i++) {
        for (let j = 0; j < (numbers.length - 1); j++) {
            // Using the cmp function to decide order
            if (cmp(numbers[j], numbers[j + 1])) {
                tmp = numbers[j];
                numbers[j] = numbers[j + 1];
                numbers[j + 1] = tmp;
            }
        }
    }
    return numbers;
}
export function sort_min(numbers: NumericLike[]): NumericLike[] {
    let tmp: NumericLike;
    for (let i: number = 0; i < numbers.length; i++) {
        for (let j: number = 0; j < (numbers.length - 1); j++) {
            if (typeof numbers[j] === "number") {
                if ((numbers[j] as number) > (numbers[j + 1] as number)) {
                    tmp = numbers[j];
                    numbers[j] = numbers[j + 1];
                    numbers[j + 1] = tmp;
                }
            }
            else {
                if ((numbers[j] as fractions).value() > (numbers[j + 1] as fractions).value()) {
                    tmp = numbers[j];
                    numbers[j] = numbers[j + 1];
                    numbers[j + 1] = tmp;
                }
            }
        }
    }
    return numbers;
}
export function sort_max(numbers: NumericLike[]): NumericLike[] {
    let tmp: NumericLike;
    for (let i: number = 0; i < numbers.length; i++) {
        for (let j: number = 0; j < (numbers.length - 1); j++) {
            if (typeof numbers[j] === "number") {
                if ((numbers[j] as number) < (numbers[j + 1] as number)) {
                    tmp = numbers[j];
                    numbers[j] = numbers[j + 1];
                    numbers[j + 1] = tmp;
                }
            }
            else {
                if ((numbers[j] as fractions).value() < (numbers[j + 1] as fractions).value()) {
                    tmp = numbers[j];
                    numbers[j] = numbers[j + 1];
                    numbers[j + 1] = tmp;
                }
            }
        }
    }
    return numbers;
}
