# Changelog
## [v0.0.2] - 2025-10
- [cite_start]**新增数据结构模块**: 新增 `dataStruct` 库，包含 `stack` (栈)、`queue` (队列) 和 `priority_queue` (优先队列) 的实现 [cite: 33, 34, 40, 46]。
- **表达式解析增强 (`expression`)**:
    - [cite_start]引入栈 (`stack`) 结构处理四则运算，支持通过括号 `()` 和运算符优先级 (`+`, `-`, `*`, `/`, `%`) 正确解析复杂表达式 [cite: 80, 98, 109]。
    - [cite_start]新增对多重表达式的支持，支持使用 `=====` 分隔符处理多个表达式 [cite: 75]。
    - [cite_start]新增 Sigma ($\sum$) 求和功能支持，包括 `sigma` 函数实现及表达式解析逻辑 [cite: 128, 176]。
    - [cite_start]优化分数除法解析逻辑，支持通过长横线自动识别分子分母 [cite: 163, 167]。
- [cite_start]**比较模块更新**: `compare` 库新增 `sort` 排序函数 [cite: 22, 31]。
- [cite_start]**配置项**: `number` 库新增 `setInf` 函数用于配置无穷大值的定义 [cite: 174]。
- **文档与规范**:
    - [cite_start]全面补充 `compare`, `number`, `nativeMath` 等模块的 JSDoc 注释 [cite: 17, 58, 61]。
    - [cite_start]重构 `nativeMath` 导出逻辑，优化 `Math` 对象属性的遍历导出 [cite: 60]。
    - [cite_start]引入 `prettify` 和 `linenumber` 脚本用于文档生成 [cite: 1, 10]。

## [v0.0.1] 2025.08
- 基于[Emath-2.0.0]()原库0.0.1版本进行适配
