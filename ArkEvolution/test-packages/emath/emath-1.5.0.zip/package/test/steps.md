DEMO: Create a tool for drawing function images
-------------------------------------------------

### File structure
function images
|- index.js
|- public
    |- index.html
    |- css
        |- index.css
    |- js
        |- index.js

### First: Installation dependence
#### Dependency list
- emath
- express
- body-parser
#### Installation
- `npm install emath`
- `npm install express`
- `npm install body-parser`

### Second: Require dependence
```javascript
var emath = require("emath");
var express = require("express");
var bodyParser = require("body-parser");
```

### Third: Create web app
```javascript
var app = express();
app.listen(8181);
```

### Fourth: Setting up routing
```javascript
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public'));
```

### Fifth: coding the index.html
### Sixth: coding the draw bg
### Seventh: coding the show function and hide function