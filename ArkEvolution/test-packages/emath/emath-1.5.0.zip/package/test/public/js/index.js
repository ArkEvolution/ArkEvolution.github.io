var canvas = document.getElementById("panel");
var ctx = canvas.getContext("2d");
canvas.width = 1200;
canvas.height = 600;
var position = {
    number: {
        xStart: -10,
        xEnd: 10,
        xRange: 20,
        yStart: -20,
        yEnd: 20,
        yRange: 20,
        margin: {
            x: 0,
            y: 0
        },
        count: {
            x: 24,
            y: 12
        },
        update: function () {
            this.xRange = this.xEnd - this.xStart;
            this.yRange = this.yEnd - this.yStart;
            this.margin.x = this.xRange / this.count.x;
            this.margin.y = this.yRange / this.count.y;
        }
    },
    margin: {
        x: 0,
        y: 0,
        update: function () {
            this.x = canvas.width / position.number.count.x;
            this.y = canvas.height / position.number.count.y;
        }
    },
    middle: {
        x: canvas.width / 2,
        y: canvas.height / 2
    },
    update: function () {
        this.number.update();
        this.margin.update();
    }
};
function drawBG() {
    position.update();

    ctx.fillStyle = "#fa0";
    ctx.textAlign = "center";
    ctx.font = "bold 10px Arial";

    ctx.lineWidth = 1;
    ctx.strokeStyle = "#f00";
    for (var i = 0 ; i <= canvas.width ; i += position.margin.x){
        ctx.beginPath();
        ctx.moveTo(i,0);
        ctx.lineTo(i,canvas.height);
        ctx.stroke();
        ctx.closePath();
        ctx.beginPath();
        if ((position.number.xStart + (i / position.margin.x) * position.number.margin.x).toFixed(2) == 0){
            continue;
        }
        ctx.fillText((position.number.xStart + (i / position.margin.x) * position.number.margin.x).toFixed(2),i,position.middle.y - 10);
        ctx.closePath();
    }

    ctx.strokeStyle = "#00f";
    for (var i = 0 ; i <= canvas.height ; i += position.margin.y){
        ctx.beginPath();
        ctx.moveTo(0,i);
        ctx.lineTo(canvas.width,i);
        ctx.stroke();
        ctx.closePath();
        ctx.beginPath();
        if ((position.number.yStart + (i / position.margin.y) * position.number.margin.y).toFixed(2) == 0){
            continue;
        }
        ctx.fillText((position.number.yStart + (i / position.margin.y) * position.number.margin.y).toFixed(2),position.middle.x + 10,i);
        ctx.closePath();
    }

    ctx.font = "bold 20px Arial";
    ctx.fillText("0.00",position.middle.x,position.middle.y);

    ctx.beginPath();
    ctx.lineWidth = 3;
    ctx.moveTo(position.middle.x,0);
    ctx.lineTo(position.middle.x,canvas.height);
    ctx.strokeStyle = "#000";
    ctx.stroke();
    ctx.closePath();

    ctx.beginPath();
    ctx.lineWidth = 3;
    ctx.moveTo(0,position.middle.y);
    ctx.lineTo(canvas.width,position.middle.y);
    ctx.strokeStyle = "#000";
    ctx.stroke();
    ctx.closePath();

}
drawBG();

var chars = document.getElementsByClassName("chars")[0];
var buttons = document.getElementsByClassName("button");
for (var i = 0 ; i < buttons.length ; i++){
    buttons[i].onclick = function () {
        if (this.innerHTML == "×"){
            document.getElementById("function").value += "*";
            return;
        }
        if (this.innerHTML == "÷"){
            document.getElementById("function").value += "/";
            return;
        }
        document.getElementById("function").value += this.innerHTML;
    };
}

function show() {
    chars.style.display = "block";
}

function hide() {
    chars.style.display = "none";
}