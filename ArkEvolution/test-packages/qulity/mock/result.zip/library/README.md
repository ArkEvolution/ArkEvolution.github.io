# Qulity
## A data management utility for OpenHarmony

[[Contribute](#issues-contributing--license)] [[Documentation](https://github.com/QSmally/Qulity/blob/master/Documentation/Index.md)]

> Qulity is a utility module for **OpenHarmony (ArkTS)** which provides enhanced versions of the native Map & other classes with additional methods and optimisations.

# Main Features
* [Collection](https://github.com/QSmally/Qulity/blob/master/Documentation/Collection.md): An enhanced Map class.
* [DataStore](https://github.com/QSmally/Qulity/blob/master/Documentation/DataStore.md): An optimised dictionary.
* [Manager](https://github.com/QSmally/Qulity/blob/master/Documentation/Manager.md): Integrated instance manager.
* [Queue](https://github.com/QSmally/Qulity/blob/master/Documentation/Queue.md): An element ordering integration.

## Links
* [Documentations](https://github.com/QSmally/Qulity/blob/master/Documentation/Index.md)
* [Github](https://github.com/QSmally/Qulity)
* [Discord Server](https://qdb.qbot.eu/discord)

## Install/Import

Install via `ohpm`:

```bash
ohpm install qulity
```

Import into your ArkTS project:

```typescript
import { Collection, DataStore, Manager, Queue } from "qulity";
// ...
```

# Usage

## [Collection](https://github.com/QSmally/Qulity/blob/master/Documentation/Collection.md)
An extended Map with additional utility methods.

```typescript
import { Collection } from "qulity";

const collection = new Collection<string, any>();
```

## [DataStore](https://github.com/QSmally/Qulity/blob/master/Documentation/DataStore.md)
Base class that manages the creation, retrieval, and deletion of a specific data model.

```typescript
import { DataStore } from "qulity";

interface UserProfile {
    Name: string;
    Job: string;
}

const dataStore = new DataStore<UserProfile>();

// Set a data model into the DataStore.
dataStore.set("b0ce7d", {
    Name: "Smally",
    Job:  "Software Engineer"
});

// Resolve a data model to be used.
const model = dataStore.resolve("b0ce7d");

// Last Recently Resolved model gets cached.
// Or resolve a model and, if the cached model is
// the one you requested, that gets returned.
const cached = dataStore.LRR;
```

## [Manager](https://github.com/QSmally/Qulity/blob/master/Documentation/Manager.md)
Manages the API methods of data models and holds its cache.

```typescript
import { Manager } from "qulity";

// Create an instance from the Manager.
class UserManager extends Manager {
    public Client: any;

    constructor (Client: any, ...Options: any[]) {
        super(...Options);
        this.Client = Client;
    }

    get Admins () { 
        return this.Cache.filter((User: any) => User.Admin); 
    }

    Ban (UserId: string) {
        const User = this.Cache.resolve(UserId);
        if (User && !User.Admin) User.Ban(); // Custom from User instance.
    }
}

const Users = new UserManager(Client, GuildUsers, User);
const myClient = Users.Client; // Access your own variables in the Manager.
const admins = Users.Admins;   // Automatically get all administrators.
const cache = Users.Cache;     // All 'Users' as DataStore.

// Access methods within the Manager.
Users.Ban("d34hg3o");
```

## [Queue](https://github.com/QSmally/Qulity/blob/master/Documentation/Queue.md)
A manager for ordering values and iterating over them.

```typescript
import { Queue } from "qulity";

const queue = new Queue(Shards);

// Iterate over the Queue items.
queue.iterate(async (Shard: any, Cache: any) => {
    const { Token } = Cache.resolve(Shard.Id);
    // Log into the shard and caches it.
    await Shard.Login(Token);
    Cache.set(Shard.Id, Shard);
}, BaseCache);
```

# Issues, Contributing & License
If you've found a bug or want to suggest a feature, please ensure that it hasn't already been reported/suggested - Then, feel free to create an [issue](https://github.com/QSmally/Qulity/issues)! If you'd like to contribute to the project, feel free to fork [the repository](https://github.com/QSmally/Qulity) and create a pull request.

This module is licensed under [Apache 2.0](http://www.apache.org/licenses/LICENSE-2.0).