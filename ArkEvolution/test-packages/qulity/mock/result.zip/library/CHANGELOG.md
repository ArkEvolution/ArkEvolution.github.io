# CHANGELOG.md

# Changelog

All notable changes to this project will be documented in this file.

## [2.0.0]

### 🚀 Features & Enhancements

* **Collection**: Completely rewritten `Collection` class with a massive set of new utility methods:
    * `first(Amount)`, `last(Amount)`: Retrieve elements from start or end.
    * `find(Fn)`, `filter(Fn)`, `sweep(Fn)`: Advanced searching and filtering.
    * `partition(Fn)`: Split collection into multiple groups based on criteria.
    * `map(Fn)`, `reduce(Fn)`: Functional programming helpers.
    * `merge(...)`, `intersect(Secondary)`, `difference(Secondary)`: Set operations.
    * `sort(Fn)`: Sort collection in place.
    * `clone()`, `implement(...)`, `tap(Fn)`: Chainable utilities.
* **BaseManager**: Refactored `Manager` into `BaseManager` (exported as `Manager` for compatibility) with streamlined caching logic.
* **DataStore**: Now includes strict type checking for Keys (`string` | `number`) and Models (`function` | `object`) upon insertion.

### 🛠 Refactoring & Breaking Changes

* **Queue Removed**: The `Queue` class and its integrations have been completely **removed** from the library.
* **DataStore LRR**: Removed `LRR` (Last Recently Resolved) property from `DataStore` to improve performance and remove stateful side-effects on read operations.
* **Directory Structure**:
    * Moved `Collection` to `lib/Base/Collection.js`.
    * Moved `DataStore` to `lib/Managers/DataStore.js`.
    * Moved/Renamed `Manager` to `lib/Managers/BaseManager.js`.
    * Removed `lib/Maps/` and `lib/Integrations/` directories.

### 🐛 Fixes & Polish

* Updated copyright year to 2021.
* Improved documentation comments (JSDoc) across all core files.
* Standardized constructor signatures for `Collection` and `DataStore`.

## [v1.3.4] 2025.08
- 基于[qulity-1.3.4]()原库1.3.4版本进行适配