import unitTest from "@normalized:N&&&qulity/src/test/unit.test&0.0.1";
export default function testsuite() {
    unitTest();
}
