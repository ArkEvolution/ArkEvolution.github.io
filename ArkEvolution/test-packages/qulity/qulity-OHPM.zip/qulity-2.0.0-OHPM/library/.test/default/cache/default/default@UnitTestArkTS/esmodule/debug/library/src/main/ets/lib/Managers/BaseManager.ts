import Collection from "@normalized:N&&&qulity/src/main/ets/lib/Base/Collection&0.0.1";
export default class BaseManager {
    public cache: Collection;
    private holds: any | null;
    /**
     * Manages the API methods of data models and holds its cache.
     * @param {Array|Object} [Iterable] Optional initial values of this Manager.
     * @param {Function} [Holds] An optional data stricture belonging to this Manager.
     */
    constructor(Iterable: any = {}, Holds: any | null = null) {
        this.cache = new Collection();
        this.holds = Holds;
        if (Iterable instanceof Array) {
            for (let i = 0; i < Iterable.length; i++) {
                const entry: any = Iterable[i];
                if (entry instanceof Array && entry.length >= 2) {
                    this.cache.set(entry[0], entry[1]);
                }
            }
        }
        else {
            const keys = Object.keys(Iterable);
            for (let i = 0; i < keys.length; i++) {
                const key: string = keys[i];
                this.cache.set(key, Iterable[key]);
            }
        }
    }
    /**
     * Inserts an instance into this Manager's cache.
     */
    add(Id: string, Model: any): BaseManager | null {
        if (typeof Id !== "string")
            return null;
        if (this.cache.has(Id))
            return null;
        if (this.holds && !(Model instanceof (this.holds as any)))
            return null;
        this.cache.set(Id, Model);
        return this;
    }
    /**
     * Removes an instance from this Manager's cache.
     */
    remove(Id: string): BaseManager | null {
        if (typeof Id !== "string")
            return null;
        if (!this.cache.has(Id))
            return null;
        this.cache.delete(Id);
        return this;
    }
    /**
     * Resolves an instance of this Manager.
     */
    resolve(IdOrInstance: any): any {
        if (this.holds && IdOrInstance instanceof (this.holds as any))
            return this.holds;
        if (typeof IdOrInstance !== "string")
            return null;
        return this.cache.get(IdOrInstance);
    }
}
