import { describe, it, expect } from "@normalized:N&&&@ohos/hypium/index&1.0.21";
import Collection from "@normalized:N&&&qulity/src/main/ets/lib/Base/Collection&0.0.1";
export default function unitTest() {
    describe('CollectionTest', () => {
        // 1. 测试构造函数
        it('should_construct_from_object', 0, () => {
            const initial: any = { "key1": "value1", "key2": "value2" };
            const col: Collection = new Collection(initial);
            expect(col.size).assertEqual(2);
            expect(col.get("key1") as string).assertEqual("value1");
        });
        it('should_construct_from_array_entries', 0, () => {
            const initial: any = [["keyA", 100], ["keyB", 200]];
            const col: Collection = new Collection(initial);
            expect(col.size).assertEqual(2);
            expect(col.get("keyB") as number).assertEqual(200);
        });
        // 2. 测试基本 Map 操作
        it('should_perform_basic_map_operations', 0, () => {
            const col: Collection = new Collection();
            col.set("test", "data");
            expect(col.size).assertEqual(1);
            expect(col.has("test")).assertTrue();
            expect(col.get("test") as string).assertEqual("data");
            const deleted: boolean = col.delete("test");
            expect(deleted).assertTrue();
            expect(col.size).assertEqual(0);
        });
        // 3. 测试转换方法
        it('should_convert_to_arrays_and_object', 0, () => {
            const col: Collection = new Collection([["a", 1], ["b", 2]]);
            const valArr: any[] = col.toArray();
            expect(valArr.length).assertEqual(2);
            expect(valArr[0] as number).assertEqual(1);
            const keyArr: any[] = col.toKeyArray();
            expect(keyArr.length).assertEqual(2);
            expect(keyArr[0] as string).assertEqual("a");
            const obj: any = col.toPairObject();
            expect(obj["a"] as number).assertEqual(1);
            expect(obj["b"] as number).assertEqual(2);
        });
        // 4. 测试查找方法 (first, last)
        it('first_and_last_should_return_correct_elements', 0, () => {
            const col: Collection = new Collection([["a", 1], ["b", 2], ["c", 3]]);
            // 单个元素
            expect(col.first() as number).assertEqual(1);
            expect(col.last() as number).assertEqual(3);
            // 多个元素 (返回新的 Collection)
            const firstTwo: Collection = col.first(2) as Collection;
            expect(firstTwo.size).assertEqual(2);
            expect(firstTwo.get("a") as number).assertEqual(1);
            expect(firstTwo.get("b") as number).assertEqual(2);
            const lastTwo: Collection = col.last(2) as Collection;
            expect(lastTwo.size).assertEqual(2);
            expect(lastTwo.get("b") as number).assertEqual(2);
            expect(lastTwo.get("c") as number).assertEqual(3);
        });
        // 5. 测试高阶函数 (find, filter, sweep, partition)
        it('find_should_return_matching_element', 0, () => {
            const col: Collection = new Collection([["u1", { age: 20 }], ["u2", { age: 30 }]]);
            const found: any = col.find((val: any) => val.age === 30);
            expect(found.age as number).assertEqual(30);
        });
        it('filter_should_return_filtered_collection', 0, () => {
            const col: Collection = new Collection([["a", 10], ["b", 20], ["c", 30]]);
            const filtered: Collection = col.filter((val: number) => val > 15);
            expect(filtered.size).assertEqual(2);
            expect(filtered.has("a")).assertFalse();
            expect(filtered.has("b")).assertTrue();
            expect(filtered.has("c")).assertTrue();
        });
        it('sweep_should_remove_items_and_return_count', 0, () => {
            const col: Collection = new Collection([["a", 1], ["b", 2], ["c", 3], ["d", 4]]);
            // 删除偶数
            const count: number = col.sweep((val: number) => val % 2 === 0);
            expect(count).assertEqual(2);
            expect(col.size).assertEqual(2);
            expect(col.has("b")).assertFalse();
            expect(col.has("d")).assertFalse();
        });
        it('partition_should_split_collection', 0, () => {
            const col: Collection = new Collection([["a", 1], ["b", 2], ["c", 3]]);
            // 分割奇数和偶数
            const parts: Collection[] = col.partition((val: number) => val % 2 !== 0);
            expect(parts.length).assertEqual(2);
            // parts[0] 满足条件 (奇数)
            expect(parts[0].size).assertEqual(2);
            expect(parts[0].has("a")).assertTrue();
            // parts[1] 不满足条件 (偶数)
            expect(parts[1].size).assertEqual(1);
            expect(parts[1].has("b")).assertTrue();
        });
        // 6. 测试数据处理 (map, reduce)
        it('map_should_transform_values', 0, () => {
            const col: Collection = new Collection([["a", 1], ["b", 2]]);
            const mapped: any[] = col.map((val: number) => val * 10);
            expect(mapped.length).assertEqual(2);
            expect(mapped[0] as number).assertEqual(10);
            expect(mapped[1] as number).assertEqual(20);
        });
        it('reduce_should_accumulate_values', 0, () => {
            const col: Collection = new Collection([["a", 1], ["b", 2], ["c", 3]]);
            const sum: any = col.reduce((acc: number, val: number) => acc + val, 0);
            expect(sum as number).assertEqual(6);
        });
        // 7. 测试集合管理 (merge, intersect, difference)
        it('merge_should_combine_collections', 0, () => {
            const col1: Collection = new Collection([["a", 1]]);
            const col2: Collection = new Collection([["b", 2]]);
            const merged: Collection = col1.merge(col2);
            expect(merged.size).assertEqual(2);
            expect(merged.get("a") as number).assertEqual(1);
            expect(merged.get("b") as number).assertEqual(2);
            // 原集合不应改变
            expect(col1.size).assertEqual(1);
        });
        it('intersect_and_difference_should_work_correctly', 0, () => {
            const col1: Collection = new Collection([["a", 1], ["b", 2]]);
            const col2: Collection = new Collection([["b", 2], ["c", 3]]);
            // 交集 (都有 'b')
            const intersection: Collection = col1.intersect(col2);
            expect(intersection.size).assertEqual(1);
            expect(intersection.get("b") as number).assertEqual(2);
            // 差集 ('a' 在 1 不在 2, 'c' 在 2 不在 1)
            const diff: Collection = col1.difference(col2);
            expect(diff.size).assertEqual(2);
            expect(diff.has("a")).assertTrue();
            expect(diff.has("c")).assertTrue();
            expect(diff.has("b")).assertFalse();
        });
        // 8. 测试排序
        it('sort_should_order_collection', 0, () => {
            const col: Collection = new Collection([["a", 30], ["b", 10], ["c", 20]]);
            // 按值升序排序
            col.sort((v1: number, v2: number) => v1 - v2);
            const keys: any[] = col.toKeyArray();
            expect(keys[0] as string).assertEqual("b"); // 10
            expect(keys[1] as string).assertEqual("c"); // 20
            expect(keys[2] as string).assertEqual("a"); // 30
            // 验证内部 Map 顺序是否真正改变 (通过 toArray)
            const vals: any[] = col.toArray();
            expect(vals[0] as number).assertEqual(10);
        });
    });
}
