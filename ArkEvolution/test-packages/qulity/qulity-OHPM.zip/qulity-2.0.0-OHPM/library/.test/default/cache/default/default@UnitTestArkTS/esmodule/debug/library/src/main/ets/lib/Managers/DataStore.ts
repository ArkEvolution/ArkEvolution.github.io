import Collection from "@normalized:N&&&qulity/src/main/ets/lib/Base/Collection&0.0.1";
export default class DataStore extends Collection {
    /**
     * Base class that manages the creation, retrieval and deletion of a specific data model.
     * @param {Array|Object} [Iterable] Optional initial values of this DataStore.
     */
    constructor(Iterable: any = {}) {
        super();
        if (Iterable instanceof Array) {
            for (let i = 0; i < Iterable.length; i++) {
                const entry: any = Iterable[i];
                if (entry instanceof Array && entry.length >= 2) {
                    this.set(entry[0], entry[1]);
                }
            }
        }
        else {
            const keys = Object.keys(Iterable);
            for (let i = 0; i < keys.length; i++) {
                const key: string = keys[i];
                this.set(key, Iterable[key]);
            }
        }
    }
    /**
     * Sets a model into the DataStore.
     * @param {String|Number} Key Key of the model to be inserted.
     * @param {Function|Object} Model The data model to set into the DataStore.
     */
    // 使用 ESObject 作为返回类型，以兼容 Map.set 的 this 返回类型检查
    set(Key: string | number, Model: any): any {
        const typeModel = typeof Model;
        const typeKey = typeof Key;
        if (typeModel !== "function" && typeModel !== "object")
            return this;
        if (typeKey !== "string" && typeKey !== "number")
            return this;
        super.set(Key, Model);
        return this;
    }
    /**
     * Resolves a data model.
     * @param {String|Number} Key Key of the model to be resolved.
     */
    resolve(Key: string | number): any {
        const typeKey = typeof Key;
        if (typeKey !== "string" && typeKey !== "number")
            return null;
        return super.get(Key);
    }
}
