// TS2ArkTS-SessionId-13
export default class Collection extends Map<any, any> {
    /**
     * An extended JavaScript Map with additional optimisations, properties and methods.
     * @param {Array|Object} [Iterable] Optional initial values of this Collection.
     */
    constructor(Iterable: any = null) {
        super();
        if (Iterable) {
            if (Iterable instanceof Array) {
                for (let i: number = 0; i < Iterable.length; i++) {
                    const entry: any = Iterable[i];
                    // 确保是 [key, val] 格式
                    if (entry instanceof Array && entry.length >= 2) {
                        this.set(entry[0], entry[1]);
                    }
                }
            }
            else {
                const keys: string[] = Object.keys(Iterable);
                for (let i: number = 0; i < keys.length; i++) {
                    const key: string = keys[i];
                    this.set(key, Iterable[key]);
                }
            }
        }
    }
    /**
     * Amount of key/value pairs in this Collection.
     */
    get size(): number {
        return super.size;
    }
    // 移除了 set 重写，直接继承 Map 的 set 方法以避免类型冲突
    delete(Key: any): boolean {
        return super.delete(Key);
    }
    get(Key: any): any {
        return super.get(Key);
    }
    has(Key: any): boolean {
        return super.has(Key);
    }
    // ---------------------------------------------------------------- Migration units
    toArray(): any[] {
        return Array.from(super.values());
    }
    toKeyArray(): any[] {
        return Array.from(super.keys());
    }
    /**
     * Creates an ordered object of all the entries of this Collection.
     */
    toPairObject(): any {
        const obj: Record<string, any> = {};
        const iter: IterableIterator<[
            any,
            any
        ]> = super.entries();
        let result: IteratorResult<[
            any,
            any
        ]> = iter.next();
        while (!result.done) {
            const entry: [
                any,
                any
            ] = result.value;
            obj[String(entry[0])] = entry[1];
            result = iter.next();
        }
        return obj;
    }
    // ---------------------------------------------------------------- Lookup functions
    first(Amount: number = 1): any {
        if (typeof Amount !== "number")
            return null;
        if (Amount === 1)
            return super.values().next().value;
        if (Amount < 0)
            return this.last(Amount * -1);
        if (Amount === 0)
            return null;
        const Amt: number = Math.min(this.size, Amount);
        const Arr: any[] = new Array<any>(Amt);
        // 修复：使用 entries() 获取 [key, val]，以便传入 Collection 构造函数
        const Iter: IterableIterator<[
            any,
            any
        ]> = super.entries();
        for (let i: number = 0; i < Amt; i++) {
            Arr[i] = Iter.next().value;
        }
        return new Collection(Arr);
    }
    last(Amount: number = 1): any {
        if (typeof Amount !== "number")
            return null;
        if (Amount === 1) {
            const arr: any[] = this.toArray();
            return arr[arr.length - 1];
        }
        if (Amount < 0)
            return this.first(Amount * -1);
        if (Amount === 0)
            return null;
        const Amt: number = Math.min(this.size, Amount);
        // 修复：使用 entries() 获取 [key, val]，以便传入 Collection 构造函数
        // 显式声明类型为 [ESObject, ESObject][]
        const entries: [
            any,
            any
        ][] = Array.from(super.entries());
        const Sliced: [
            any,
            any
        ][] = entries.slice(entries.length - Amt).reverse();
        return new Collection(Sliced);
    }
    find(Fn: any): any {
        if (typeof Fn !== "function")
            return null;
        const entries: [
            any,
            any
        ][] = Array.from(super.entries());
        for (let i: number = 0; i < entries.length; i++) {
            const entry: [
                any,
                any
            ] = entries[i];
            // 显式调用 Fn as ESObject
            if ((Fn as any)(entry[1], entry[0], this))
                return entry[1];
        }
        return undefined;
    }
    filter(Fn: any): Collection {
        if (typeof Fn !== "function")
            return new Collection();
        const Results: Collection = new Collection();
        const entries: [
            any,
            any
        ][] = Array.from(super.entries());
        for (let i: number = 0; i < entries.length; i++) {
            const entry: [
                any,
                any
            ] = entries[i];
            if ((Fn as any)(entry[1], entry[0], this))
                Results.set(entry[0], entry[1]);
        }
        return Results;
    }
    sweep(Fn: any): number {
        if (typeof Fn !== "function")
            return 0;
        const PrevSize: number = this.size;
        const entries: [
            any,
            any
        ][] = Array.from(super.entries());
        for (let i: number = 0; i < entries.length; i++) {
            const entry: [
                any,
                any
            ] = entries[i];
            if ((Fn as any)(entry[1], entry[0], this))
                super.delete(entry[0]);
        }
        return PrevSize - this.size || 0;
    }
    partition(Fn: any, Length?: number): Collection[] {
        if (typeof Fn !== "function")
            return [];
        const Results: Collection[] = [];
        const entries: [
            any,
            any
        ][] = Array.from(super.entries());
        for (let i: number = 0; i < entries.length; i++) {
            const entry: [
                any,
                any
            ] = entries[i];
            const Key: any = entry[0];
            const Val: any = entry[1];
            const Condition: any = (Fn as any)(Val, Key, this);
            let Idx: number;
            if (typeof Condition === 'number') {
                Idx = Condition;
            }
            else {
                Idx = Condition ? 0 : 1;
            }
            if (!Results[Idx])
                Results[Idx] = new Collection();
            Results[Idx].set(Key, Val);
        }
        const targetLen: number = Length || Results.length;
        for (let i: number = 0; i < targetLen; i++) {
            if (!Results[i])
                Results[i] = new Collection();
        }
        return Results;
    }
    reduce(Fn: any, Initial?: any): any {
        if (typeof Fn !== "function")
            return null;
        const entries: [
            any,
            any
        ][] = Array.from(super.entries());
        let Accumulator: any;
        let StartIndex: number = 0;
        if (Initial !== undefined) {
            Accumulator = Initial;
        }
        else {
            if (entries.length === 0)
                return undefined;
            Accumulator = entries[0][1];
            StartIndex = 1;
        }
        for (let i: number = StartIndex; i < entries.length; i++) {
            const entry: [
                any,
                any
            ] = entries[i];
            Accumulator = (Fn as any)(Accumulator, entry[1], entry[0], this);
        }
        return Accumulator;
    }
    map(Fn: any): any[] {
        if (typeof Fn !== "function")
            return [];
        const Arr: any[] = new Array<any>(this.size);
        const entries: [
            any,
            any
        ][] = Array.from(super.entries());
        for (let i: number = 0; i < entries.length; i++) {
            const entry: [
                any,
                any
            ] = entries[i];
            Arr[i] = (Fn as any)(entry[1], entry[0], i, this);
        }
        return Arr;
    }
    // ---------------------------------------------------------------- Conditionals
    exists(Fn: any): boolean {
        if (typeof Fn !== "function")
            return false;
        const entries: [
            any,
            any
        ][] = Array.from(super.entries());
        for (let i: number = 0; i < entries.length; i++) {
            const entry: [
                any,
                any
            ] = entries[i];
            if ((Fn as any)(entry[1], entry[0], this))
                return true;
        }
        return false;
    }
    some(Fn: any): boolean {
        return this.exists(Fn);
    }
    every(Fn: any): boolean {
        if (typeof Fn !== "function")
            return false;
        const entries: [
            any,
            any
        ][] = Array.from(super.entries());
        for (let i: number = 0; i < entries.length; i++) {
            const entry: [
                any,
                any
            ] = entries[i];
            if (!(Fn as any)(entry[1], entry[0], this))
                return false;
        }
        return true;
    }
    // ---------------------------------------------------------------- Collection management
    clone(): Collection {
        return new Collection(this.toPairObject());
    }
    merge(...Collections: Collection[]): Collection {
        const Clone: Collection = this.clone();
        for (let i: number = 0; i < Collections.length; i++) {
            const Col: Collection = Collections[i];
            const iter: IterableIterator<[
                any,
                any
            ]> = Col.entries();
            let res: IteratorResult<[
                any,
                any
            ]> = iter.next();
            while (!res.done) {
                Clone.set(res.value[0], res.value[1]);
                res = iter.next();
            }
        }
        return Clone;
    }
    implement(...Collections: Collection[]): Collection {
        for (let i: number = 0; i < Collections.length; i++) {
            const Col: Collection = Collections[i];
            const iter: IterableIterator<[
                any,
                any
            ]> = Col.entries();
            let res: IteratorResult<[
                any,
                any
            ]> = iter.next();
            while (!res.done) {
                this.set(res.value[0], res.value[1]);
                res = iter.next();
            }
        }
        return this;
    }
    intersect(Secondary: Collection): Collection {
        return this.filter((_: any, Key: any) => Secondary.has(Key));
    }
    difference(Secondary: Collection): Collection {
        const diff1: Collection = this.filter((_: any, Key: any) => !Secondary.has(Key));
        const diff2: Collection = Secondary.filter((_: any, Key: any) => !this.has(Key));
        return diff1.implement(diff2);
    }
    tap(Fn: any): Collection {
        if (typeof Fn === "function")
            (Fn as any)(this, this.size);
        return this;
    }
    each(Fn: any): Collection {
        if (typeof Fn === "function") {
            const entries: [
                any,
                any
            ][] = Array.from(super.entries());
            for (let i: number = 0; i < entries.length; i++) {
                const entry: [
                    any,
                    any
                ] = entries[i];
                (Fn as any)(entry[1], entry[0], this);
            }
        }
        return this;
    }
    sort(Fn: any): Collection {
        if (typeof Fn !== "function")
            return this;
        // 显式声明回调参数为 Tuple
        const entries: [
            any,
            any
        ][] = Array.from(super.entries());
        super.clear();
        entries.sort((a: [
            any,
            any
        ], b: [
            any,
            any
        ]) => {
            return Number((Fn as any)(a[1], b[1], [a[0], a[1]]));
        });
        for (let i: number = 0; i < entries.length; i++) {
            this.set(entries[i][0], entries[i][1]);
        }
        return this;
    }
}
