import Collection from "@normalized:N&&&qulity/src/main/ets/lib/Base/Collection&0.0.1";
import BaseManager from "@normalized:N&&&qulity/src/main/ets/lib/Managers/BaseManager&0.0.1";
import DataStore from "@normalized:N&&&qulity/src/main/ets/lib/Managers/DataStore&0.0.1";
export { Collection, BaseManager as Manager, DataStore };
