/**
 * Coordinate dimensions used in the vector types.
 */
export declare const x = 0;
export declare const y = 1;
export declare const z = 2;
export declare const w = 3;
/**
 * Vector is represented by an array of numbers.
 */
export declare type Vector = number[];
/**
 * Initialize a zero vector with dim components.
 * @param dim Vector dimension.
 */
export declare function zero(dim: number): Vector;
/**
 * Initializes a vector with the same value in all components.
 * @param dim Vector dimension.
 * @param value Value for components.
 */
export declare function unif(dim: number, value: number): Vector;
/**
 * Return a copy of the input vector but with different dimension.
 * @param vec The input vector.
 * @param dim The dimension of the new vector.
 * @param pad The value used to pad the new vector, if dimension is greater
 * than originally.
 */
export declare function redim(vec: Vector, dim: number, pad?: number): Vector;
/**
 * Returns the vector dimension, i.e. number of components.
 */
export declare function dimension(v: Vector): number;
/**
 * Return one or more components of the vector in arbitrary order. The components
 * returned depend on the dimensions specified in the coords argument. Note that
 * the same component can occur multiple times in coords. So, it is valid to call
 * the function like this:
 *
 * swizzle ([x, x, y])
 */
export declare function swizzle(v: Vector, ...coords: number[]): Vector;
/**
 * The lenght of the vector squared. Faster to calculate than the actual length,
 * and useful for comparing vector magnitudes.
 */
export declare function lenSqr(v: Vector): number;
/**
 * Length of the vector.
 */
export declare function len(v: Vector): number;
/**
 * Invert a vector.
 * @param v Vector to be inverted.
 * @param out Result vector.
 */
export declare function inv(v: Vector, out?: Vector): Vector;
/**
 * Add the second vector to the first one componentwise.
 * @param v Input vector.
 * @param other Vector or number to be added.
 * @param out Result vector.
 */
export declare function add(v: Vector, other: Vector | number, out?: Vector): Vector;
/**
 * Subtract the second vector from the first one componentwise.
 * @param v Input vector.
 * @param other Vector or number to be subtracted.
 * @param out Result vector.
 */
export declare function sub(v: Vector, other: Vector | number, out?: Vector): Vector;
/**
 * Multiply the first vector with the second one componentwise.
 * @param v Input vector.
 * @param other Multiplier vector or number.
 * @param out Result vector.
 */
export declare function mul(v: Vector, other: Vector | number, out?: Vector): Vector;
/**
 * Divide the first vector by the second one componentwise.
 * @param v Input vector.
 * @param other Divider vector or number.
 * @param out Result vector.
 */
export declare function div(v: Vector, other: Vector | number, out?: Vector): Vector;
/**
 * Normalize a vector.
 */
export declare function norm(v: Vector, out?: Vector): Vector;
/**
 * Checks if the first vector is same as the second one.
 * @param v1 First vector
 * @param v2 Second vector
 */
export declare function equals(v1: Vector, v2: Vector): boolean;
/**
 * Checks if the first vector is approximately same as the second one.
 * @param v1 First vector
 * @param v2 Second vector
 * @param epsilon The maximum allowed difference of any component.
 */
export declare function approxEquals(v1: Vector, v2: Vector, epsilon?: number): boolean;
/**
 * Return the dot product of two vectors.
 * @param v Input vector.
 * @param other Other vector of the dot product.
 */
export declare function dot(v: Vector, other: Vector): number;
/**
 * Return the cross product of two vectors. The vectors must be 3-dimensional.
 * @param v Input vector.
 * @param other The other vector of the cross product.
 * @param out Result vector.
 */
export declare function cross(v: Vector, other: Vector, out?: Vector): Vector;
/**
 * Replace components of the vector with their absolute values.
 * @param v Input vector.
 * @param out Result vector.
 */
export declare function abs(v: Vector, out?: Vector): Vector;
/**
 * Run the components of the vector through Math.floor function.
 * @param v Input vector.
 * @param out Result vector.
 */
export declare function floor(v: Vector, out?: Vector): Vector;
/**
 * Run the components of the vector through Math.ceil function.
 * @param v Input vector.
 * @param out Result vector.
 */
export declare function ceil(v: Vector, out?: Vector): Vector;
/**
 * Run the components of the vector through Math.round function.
 * @param v Input vector.
 * @param out Result vector.
 */
export declare function round(v: Vector, out?: Vector): Vector;
/**
 * Run the components of the vector through FMath.fract function.
 * @param v Input vector.
 * @param out Result vector.
 */
export declare function fract(v: Vector, out?: Vector): Vector;
/**
 * Calculate the minimum of two vectors componentwise.
 * @param v The input vector.
 * @param other The vector to compare with.
 * @param out Result vector.
 */
export declare function min(v: Vector, other: Vector, out?: Vector): Vector;
/**
 * Calculate the maximum of two vectors componentwise.
 * @param v The input vector.
 * @param other The vector to compare with.
 * @param out Result vector.
 */
export declare function max(v: Vector, other: Vector, out?: Vector): Vector;
/**
 * Clamp the components of a vector to a given range.
 * @param v The input vector.
 * @param min Minimum component value.
 * @param max Maximum component value.
 * @param out Result vector.
 */
export declare function clamp(v: Vector, min: number, max: number, out?: Vector): Vector;
/**
 * Calculate the interpolated vector in a given position [0, 1].
 * @param v The input vector.
 * @param other The vector to be interpolated to.
 * @param interPos The position between 0 and 1, zero representing v and one other.
 * @param out Result vector.
 */
export declare function mix(v: Vector, other: Vector, interPos: number, out?: Vector): Vector;
/**
 * Return a vector of zeros and ones depending if the input vector components are
 * greater or less than the edge value.
 * @param v The input vector.
 * @param edge The edge to which the components are compared.
 * @param out Result vector.
 */
export declare function step(v: Vector, edge: number, out?: Vector): Vector;
/**
 * Return a vector with components in range [0, 1] depending on how close the
 * input vector values are to the lower and upper edge value. If a component is
 * less that lower edge it gets value 0. Conversely, if it is greater than the
 * upper edge, it gets value 1. If a component is between lower and upper edge,
 * its value is smoothly interpolated between zero and one.
 * @param v The input vector.
 * @param edgeLower The lower edge to which the components are compared.
 * @param edgeUpper The upper edge to which the components are compared.
 * @param out Result vector.
 */
export declare function smoothStep(v: Vector, edgeLower: number, edgeUpper: number, out?: Vector): Vector;
/**
 * Returns the string representation of a vector formatted like this: [x y z]
 */
export declare function toString(v: Vector): string;
