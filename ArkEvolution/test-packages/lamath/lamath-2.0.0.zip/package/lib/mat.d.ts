import { Vector } from "./vec";
/**
 * The matrix is represented by an array of numbers. The first two numbers of
 * the array contain the number of rows and columns in the matrix respectively.
 */
export declare type Matrix = number[];
export declare function dimensions(m: Matrix): [number, number];
export declare function element(m: Matrix, row: number, column: number): number;
export declare function create(rows: number, cols: number): Matrix;
export declare function fromArray(rows: number, cols: number, array: number[]): Matrix;
export declare function zero(rows: number, cols: number): Matrix;
export declare function identity(dim: number): Matrix;
export declare function translation(dim: number, offsets: number[]): Matrix;
export declare function scaling(dim: number, factors: number[]): Matrix;
export declare function rotationX(dim: number, angle: number): Matrix;
export declare function rotationY(dim: number, angle: number): Matrix;
export declare function rotationZ(dim: number, angle: number): Matrix;
export declare function perspective(left: number, right: number, bottom: number, top: number, zNear: number, zFar: number): Matrix;
export declare function orthographic(left: number, right: number, bottom: number, top: number, zNear: number, zFar: number): Matrix;
export declare function lookAt(direction: Vector, up: Vector): Matrix;
export declare function add(mat: Matrix, other: Matrix | number, out?: Matrix): Matrix;
export declare function sub(mat: Matrix, other: Matrix | number, out?: Matrix): Matrix;
export declare function mul(mat: Matrix, other: Matrix | number): Matrix;
export declare function transform(mat: Matrix, vec: Vector): Vector;
export declare function transpose(mat: Matrix): Matrix;
export declare function determinant(mat: Matrix): number;
export declare function invert(mat: Matrix): Matrix;
export declare function equals(mat: Matrix, other: Matrix): boolean;
export declare function approxEquals(mat: Matrix, other: Matrix, epsilon?: number): boolean;
export declare function toString(mat: Matrix): string;
export declare function toArray(mat: Matrix): number[];
export declare function toFloat32Array(mat: Matrix): Float32Array;
