/**
 * Clone a 2D array.
 * @param array - The array to be cloned.
 */
export declare function clone<T>(array: T[][]): T[][];
/**
 * Fill an array of a specified size with a same value.
 * @param value The value used to fill an array.
 * @param count Number of times the value is repeated.
 */
export declare function repeat<T>(value: T, count: number): T[];
/**
 * Return the sum of numbers in an array.
 * @param array The array to be summed.
 */
export declare function sum(array: number[]): number;
/**
 * The flatMap() method first maps each element using a mapping function,
 * then flattens the result into a new array.
 * @param array The array of items to be flattened.
 * @param selector Function that returns an array for a given item.
 */
export declare function flatMap<T, U>(array: T[], selector: (item: T) => U[]): U[];
