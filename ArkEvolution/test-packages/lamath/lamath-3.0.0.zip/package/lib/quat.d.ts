import { Vec3 } from "./vec";
import { Mat3 } from "./mat";
/**
 * Note quoternion must have exactly 4 elements even though the type signature
 * does note show it.
 */
export declare type Quat = [number, Vec3];
export declare function ident(): Quat;
export declare function isReal(quat: Quat): boolean;
export declare function isPure(quat: Quat): boolean;
export declare function lenSqr([s, vec]: Quat): number;
export declare function len(quat: Quat): number;
export declare function isNorm(quat: Quat): boolean;
export declare function norm(quat: Quat): Quat;
export declare function fromAxisAngle(angle: number, axis: Vec3): Quat;
export declare function toMatrix(quat: Quat): Mat3;
export declare function inv(quat: Quat): Quat;
export declare function conj([s, vec]: Quat): Quat;
export declare function mul([s1, [x1, y1, z1]]: Quat, [s2, [x2, y2, z2]]: Quat): Quat;
export declare function rotate(quat: Quat, vec: Vec3): Vec3;
export declare function lerp([s1, v1]: Quat, [s2, v2]: Quat, interPos: number): Quat;
export declare function slerp(quat1: Quat, quat2: Quat, interPos: number): Quat;
export declare function equals(quat: Quat, other: Quat): boolean;
export declare function approxEquals(quat: Quat, other: Quat, epsilon?: number): boolean;
export declare function toString(quat: Quat): string;
