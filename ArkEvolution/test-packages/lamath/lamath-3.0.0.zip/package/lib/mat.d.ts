import { Vector, Vec3 } from "./vec";
/**
 * The matrix is represented by an array of numbers. The first two numbers of
 * the array contain the number of rows and columns in the matrix respectively.
 */
export declare type Matrix = number[];
export declare type Mat2 = [number, number, number, number, number, number];
export declare type Mat3 = [number, number, number, number, number, number, number, number, number, number, number];
export declare type Mat4 = [number, number, number, number, number, number, number, number, number, number, number, number, number, number, number, number, number, number];
export declare type SquareMatrix = Mat2 | Mat3 | Mat4;
export declare function dimensions(m: Matrix): [number, number];
export declare function element(m: Matrix, row: number, column: number): number;
export declare function create<M extends Matrix>(rows: number, cols: number): M;
export declare function fromArray<M extends Matrix>(rows: number, cols: number, array: number[]): M;
export declare function redim<M extends Matrix>(m: Matrix, rows: number, cols: number, pad?: number): M;
export declare function zero<M extends Matrix>(rows: number, cols: number): M;
export declare function identity<M extends SquareMatrix>(dim: number): M;
export declare function toMat3(m: Mat2): Mat3;
export declare function toMat4(m: Mat2 | Mat3): Mat4;
export declare function translation<M extends SquareMatrix>(dim: number, offsets: number[]): M;
export declare function scaling<M extends SquareMatrix>(dim: number, factors: number[]): M;
export declare function rotationX<M extends Mat3 | Mat4>(dim: number, angle: number): M;
export declare function rotationY<M extends Mat3 | Mat4>(dim: number, angle: number): M;
export declare function rotationZ<M extends SquareMatrix>(dim: number, angle: number): M;
export declare function perspective(left: number, right: number, bottom: number, top: number, zNear: number, zFar: number): Mat4;
export declare function orthographic(left: number, right: number, bottom: number, top: number, zNear: number, zFar: number): Mat4;
export declare function lookAt(direction: Vec3, up: Vec3): Mat4;
export declare function add<M extends Matrix>(mat: M, other: M | number, out?: M): M;
export declare function sub<M extends Matrix>(mat: M, other: M | number, out?: M): M;
export declare function mul(mat: Matrix, other: Matrix | number): Matrix;
export declare function transform<V extends Vector>(mat: SquareMatrix, vec: V): V;
export declare function transpose(mat: Matrix): Matrix;
export declare function determinant(mat: SquareMatrix): number;
export declare function invert<M extends SquareMatrix>(mat: M): M;
export declare function equals<M extends Matrix>(mat: M, other: M): boolean;
export declare function approxEquals<M extends Matrix>(mat: M, other: M, epsilon?: number): boolean;
export declare function toString(mat: Matrix): string;
export declare function toArray(mat: Matrix): number[];
export declare function toFloat32Array(mat: Matrix): Float32Array;
