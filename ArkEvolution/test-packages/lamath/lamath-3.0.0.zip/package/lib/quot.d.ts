import { Vec3 } from "./vec";
import { Mat3 } from "./mat";
/**
 * Note quoternion must have exactly 4 elements even though the type signature
 * does note show it.
 */
export declare type Quat = [Vec3, number];
export declare function ident(): Quat;
export declare function lenSqr([vec, w]: Quat): number;
export declare function len(quat: Quat): number;
export declare function isNorm(quat: Quat): boolean;
export declare function norm(quat: Quat): Quat;
export declare function fromAxisAngle(axis: Vec3, angle: number): Quat;
export declare function toMatrix([[x, y, z], w]: Quat): Mat3;
export declare function inv([vec, w]: Quat): Quat;
export declare function conj([vec, w]: Quat): Quat;
export declare function mul([uv1, w1]: Quat, [uv2, w2]: Quat): Quat;
export declare function rotate(quat: Quat, vec: Vec3): Vec3;
export declare function lerp([uv1, w1]: Quat, [uv2, w2]: Quat, interPos: number): Quat;
export declare function slerp([uv1, w1]: Quat, [uv2, w2]: Quat, interPos: number): Quat;
export declare function equals(quat: Quat, other: Quat): boolean;
export declare function toString(quat: Quat): string;
