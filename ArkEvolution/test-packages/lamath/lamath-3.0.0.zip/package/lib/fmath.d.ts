/**
 * Constants for factors of π.
 */
export declare const twoPI: number;
export declare const PIover2: number;
export declare const PIover4: number;
export declare const PIover8: number;
export declare const PIover16: number;
/**
 * Compares two numbers for approximate equality. At most the arguments
 * can differ by the value specified by the epsilon parameter.
 * @param x First value.
 * @param y Second value.
 * @param epsilon Maximum allowed difference.
 */
export declare function approxEquals(x: number, y: number, epsilon?: number): boolean;
/**
 * Return the decimal part of a number. The integer part will be zero.
 * @param x The input number.
 */
export declare function fract(x: number): number;
/**
 * Clamp a number into a specified range. Values outside the range
 * will be clamped to lower and upper bounds respectively.
 * @param x The input number.
 * @param min Minimum value of the output range.
 * @param max Maximum value of the output range.
 */
export declare function clamp(x: number, min: number, max: number): number;
/**
 * Calculate a linear interpolation between two values corresponding
 * to input positions 0 and 1. By specifying a interpolated position
 * < 0 or > 1 you can extrapolate backwards and forwards.
 * @param start The value of the linear function at position 0.
 * @param end The value of the linear function at position 1.
 * @param interPos The interpolated position.
 */
export declare function mix(start: number, end: number, interPos: number): number;
/**
 * Return zero if the input value is smaller than the edge value, and
 * one if it is greater.
 * @param value The input value.
 * @param edge The edge value after which the result flips from 0 to 1.
 */
export declare function step(value: number, edge: number): number;
/**
 * Return a value in range [0, 1] depending on where the input value is
 * compared to two edge values. If the input value is smaller than the
 * lower edge, the result is zero. Conversely, if the input value is
 * greater than the upper edge, the result is one. If the input value is
 * between the lower and the upper edge, the result is a quadratic (smooth)
 * interpolation in range of (0, 1). If lower and upper edge are the same,
 * the result is binary like in the {@link step} function,
 * @param value The input value.
 * @param edgeLower The lower edge value below which the result is zero.
 * @param edgeUpper The upper edge value after which the result is one.
 */
export declare function smoothStep(value: number, edgeLower: number, edgeUpper: number): number;
