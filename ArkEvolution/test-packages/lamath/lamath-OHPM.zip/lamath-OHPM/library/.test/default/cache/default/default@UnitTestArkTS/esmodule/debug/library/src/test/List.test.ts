import AdvancedTestSuite from "@normalized:N&&&lamath/src/test/unit.test&0.0.1";
export default function testsuite() {
    AdvancedTestSuite();
}
