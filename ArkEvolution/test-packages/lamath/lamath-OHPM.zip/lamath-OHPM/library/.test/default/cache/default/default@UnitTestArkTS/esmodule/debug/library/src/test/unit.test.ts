import { describe, it, expect } from "@normalized:N&&&@ohos/hypium/index&1.0.21";
import * as ArrayExt from "@normalized:N&&&lamath/src/main/ets/lib/arrayext&0.0.1";
import * as FMath from "@normalized:N&&&lamath/src/main/ets/lib/fmath&0.0.1";
import isNumber from "@normalized:N&&&lamath/src/main/ets/lib/index&0.0.1";
import * as Mat from "@normalized:N&&&lamath/src/main/ets/lib/mat&0.0.1";
import * as Vec from "@normalized:N&&&lamath/src/main/ets/lib/vec&0.0.1";
export default function AdvancedTestSuite() {
    // === 1. 数组扩展测试 (ArrayExt) ===
    describe('ArrayExtTest', () => {
        it('should_calculate_sum_of_array', 0, () => {
            const data = [1, 2, 3, 4];
            expect(ArrayExt.sum(data)).assertEqual(10);
        });
        it('should_repeat_values', 0, () => {
            const repeated = ArrayExt.repeat(7, 3);
            expect(repeated.length).assertEqual(3);
            expect(repeated[0]).assertEqual(7);
            expect(repeated[2]).assertEqual(7);
        });
        it('should_clone_2d_array', 0, () => {
            const original = [[1, 2], [3, 4]];
            const cloned = ArrayExt.clone(original);
            expect(cloned[0][0]).assertEqual(1);
            cloned[0][0] = 99;
            // 深度拷贝验证：原数组首位应保持不变
            expect(original[0][0]).assertEqual(1);
        });
    });
    // === 2. 浮点数学工具测试 (FMath) ===
    describe('FMathTest', () => {
        it('should_approx_equals_within_epsilon', 0, () => {
            // 默认 epsilon 为 0.000001
            expect(FMath.approxEquals(1.0000001, 1.00000015)).assertTrue();
            expect(FMath.approxEquals(1.0, 1.1)).assertFalse();
        });
        it('should_clamp_values', 0, () => {
            expect(FMath.clamp(5, 0, 10)).assertEqual(5);
            expect(FMath.clamp(-5, 0, 10)).assertEqual(0);
            expect(FMath.clamp(15, 0, 10)).assertEqual(10);
        });
        it('should_calculate_mix_linear_interpolation', 0, () => {
            // 0 和 10 之间 0.5 的位置应该是 5
            expect(FMath.mix(0, 10, 0.5)).assertEqual(5);
        });
    });
    // === 3. 数字判断测试 (IsNumber / index.ets) ===
    describe('IsNumberTest', () => {
        it('should_validate_numbers_and_strings', 0, () => {
            expect(isNumber(123)).assertTrue();
            expect(isNumber("123.45")).assertTrue();
            expect(isNumber("abc")).assertFalse();
            expect(isNumber(" ")).assertFalse();
        });
    });
    // === 4. 向量运算测试 (Vec) ===
    describe('VecTest', () => {
        it('should_calculate_dot_product', 0, () => {
            const v1 = [1, 2, 3];
            const v2 = [4, 5, 6];
            // 1*4 + 2*5 + 3*6 = 4 + 10 + 18 = 32
            expect(Vec.dot(v1, v2)).assertEqual(32);
        });
        it('should_calculate_cross_product_for_3d', 0, () => {
            const v1 = [1, 0, 0];
            const v2 = [0, 1, 0];
            const res = Vec.cross(v1, v2);
            // 结果应为 [0, 0, 1]
            expect(res[0]).assertEqual(0);
            expect(res[1]).assertEqual(0);
            expect(res[2]).assertEqual(1);
        });
        it('should_calculate_vector_length', 0, () => {
            const v = [3, 4];
            expect(Vec.len(v)).assertEqual(5);
        });
        it('should_normalize_vector', 0, () => {
            const v = [3, 0];
            const res = Vec.norm(v);
            expect(res[0]).assertEqual(1);
            expect(res[1]).assertEqual(0);
        });
    });
    // === 5. 矩阵运算测试 (Mat) ===
    describe('MatTest', () => {
        it('should_create_identity_matrix', 0, () => {
            const id = Mat.identity(2);
            // Mat 结构: [rows, cols, e11, e21, e12, e22] (列主序存储)
            expect(id[0]).assertEqual(2); // rows
            expect(id[1]).assertEqual(2); // cols
            expect(Mat.element(id, 0, 0)).assertEqual(1);
            expect(Mat.element(id, 1, 1)).assertEqual(1);
            expect(Mat.element(id, 0, 1)).assertEqual(0);
        });
        it('should_multiply_flat_matrices', 0, () => {
            // 创建两个 2x2 矩阵
            const m1 = Mat.fromArray(2, 2, [1, 2, 3, 4]); // [[1, 3], [2, 4]]
            const m2 = Mat.identity(2);
            const res = Mat.mul(m1, m2);
            // 乘以单位阵结果不变
            expect(Mat.element(res, 0, 0)).assertEqual(1);
            expect(Mat.element(res, 1, 1)).assertEqual(4);
        });
        it('should_transpose_flat_matrix', 0, () => {
            // 矩阵: rows=2, cols=2, data=[1, 2, 3, 4]
            // 代表:
            // [1 3]
            // [2 4]
            const m = Mat.fromArray(2, 2, [1, 2, 3, 4]);
            const mt = Mat.transpose(m);
            // 转置后结果应为:
            // [1 2]
            // [3 4]
            expect(Mat.element(mt, 0, 1)).assertEqual(2);
            expect(Mat.element(mt, 1, 0)).assertEqual(3);
        });
        it('should_calculate_translation_matrix', 0, () => {
            const t = Mat.translation(4, [10, 20, 30]);
            // 4x4 矩阵的平移分量在最后一列
            // 索引位置取决于列主序存储逻辑
            expect(Mat.element(t, 0, 3)).assertEqual(10);
            expect(Mat.element(t, 1, 3)).assertEqual(20);
            expect(Mat.element(t, 2, 3)).assertEqual(30);
        });
    });
}
