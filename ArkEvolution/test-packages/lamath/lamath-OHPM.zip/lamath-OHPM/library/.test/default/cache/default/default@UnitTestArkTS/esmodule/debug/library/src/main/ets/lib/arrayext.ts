/**
 * Clone a 2D array.
 * @param array - The array to be cloned.
 */
function clone<T>(array: T[][]): T[][] {
    let rows: number = array.length;
    let res: T[][] = Array(rows);
    for (let r: number = 0; r < rows; r++)
        res[r] = array[r].slice();
    return res;
}
/**
 * Fill an array of a specified size with a same value.
 * @param value The value used to fill an array.
 * @param count Number of times the value is repeated.
 */
function repeat<T>(value: T, count: number): T[] {
    const res: T[] = Array(count);
    for (let i: number = 0; i < count; i++)
        res[i] = value;
    return res;
}
/**
 * Return the sum of numbers in an array.
 * @param array The array to be summed.
 */
function sum(array: number[]): number {
    let res = 0;
    for (const item of array)
        res += item;
    return res;
}
/**
 * The flatMap() method first maps each element using a mapping function,
 * then flattens the result into a new array.
 * @param array The array of items to be flattened.
 * @param selector Function that returns an array for a given item.
 */
function flatMap<T, U>(array: T[], selector: (item: T) => U[]): U[] {
    return new Array().concat(...array.map(selector));
}
export { clone, repeat, sum, flatMap };
