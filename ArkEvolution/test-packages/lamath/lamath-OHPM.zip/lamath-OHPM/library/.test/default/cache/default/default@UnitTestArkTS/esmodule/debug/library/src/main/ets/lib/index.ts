/*!
 * is-number <https://github.com/jonschlinkert/is-number>
 *
 * Copyright (c) 2014-present, Jon Schlinkert.
 * Released under the MIT License.
 */
// TS2ArkTS: originStartLine=8, originStartColumn=1
export default function main(num: number | string): boolean {
    if (typeof num === 'number') {
        return num - num === 0;
    }
    if (typeof num === 'string' && num.trim() !== '') {
        let parsedNum: number = parseFloat(num);
        return Number.isFinite ? Number.isFinite(parsedNum) : isFinite(parsedNum);
    }
    return false;
}
const cluster: any = undefined;
// Note: ArkTS does not have the 'url' module from Node.js
// URL and URLSearchParams are typically available globally in browser environments
// For ArkTS, you may need to use platform-specific APIs or polyfills
// Since we cannot import from 'url', we'll need to handle this differently
// If you need URL functionality, consider:
// 1. Using the global URL constructor if available in your ArkTS environment
// 2. Implementing custom URL parsing logic
// 3. Using a different approach that doesn't rely on Node.js modules
// For now, we'll remove the import and handle URL/URLSearchParams usage elsewhere
// URL 处理
// CommonJS 风格（很多老包这样写）
const fs2: any = undefined;
// Note: ArkTS does not support Node.js 'fs' module directly
// File system operations in ArkTS use different APIs
// This import statement has been removed as it's not compatible with ArkTS
// Note: 'https' module is not available in ArkTS environment
// Removed import statement as it's not compatible with ArkTS
const os: any = {} as any;
// worker_threads module is not available in ArkTS environment
// Remove the import statement entirely as it's not supported
const path2: any = {} as any;
