'use strict';

import fs from "fs";                                      // ES 默认导入 fs
import { readFileSync, writeFile, promises as fsPromises } from "fs";  // 命名导入
import * as path from "path";                              // 命名空间导入
import { Worker, parentPort } from "worker_threads";      // 多线程
import http from "http";                                   // 网络
import https, { Agent } from "https";
import net from "net";
import { createServer } from "http2";                      // http2
import { URL, URLSearchParams } from "url";                // URL 处理

// CommonJS 风格（很多老包这样写）
const fs2 = require("fs");
const path2 = require("path/posix");
const os = require("os");
const cluster = require("cluster");
export function a(num,s) {
  // 1. 如果是 number 类型，直接用 Number.isFinite 检查
  // Number.isFinite() 排除 NaN, Infinity, -Infinity
    var a =s ;
  if (typeof num === 'number') {
    return Number.isFinite(num);
  }
  
  // 2. 如果是字符串，且非空/非空白
  if (typeof num === 'string' && num.trim() !== '') {
    // 尝试转换为数字 (+num) 并检查是否为有限数字
    return Number.isFinite(+num); 
    // 注意：不再需要 isFinite 的兼容处理
  }
  
  return false;
};

export function calculateSum(a, b, mode) {
    return a + b;
}

/**
 * 这个文件演示了合法的 TypeScript 代码，
 * 但包含了多个 ArkTS (HarmonyOS) 不支持的动态特性。
 */

interface BaseConfig {
    id: number;
    // 1. ArkTS 不支持使用 [key: string]: any 这种动态索引签名来规避类型检查
    [key: string]: any;
}

class SystemConfig {
    id: number = 0;
    name: string = "";
    version: string = "1.0";

    print() {
        console.log(this.name);
    }
}

/**
 * 一个通用的配置处理函数
 * @param config 输入配置
 * @param modifier 修改器函数
 */
function processConfiguration<T extends object>(config: T, modifier: (item: any) => void): T & { timestamps: number } {

    // 2. ArkTS 不支持 'any' 类型，要求严格类型
    let mutableConfig: any = { ...config };

    // 3. ArkTS 不支持在运行时动态向对象添加属性 (改变对象布局)
    // 在标准 TS 中，因为 mutableConfig 是 any，所以这是合法的
    mutableConfig.timestamps = Date.now();
    mutableConfig.processeds = true;

    // 执行修改器
    modifier(mutableConfig);

    // 4. ArkTS 不支持 'delete' 操作符 (改变对象布局)
    if (mutableConfig.tempData) {
        delete mutableConfig.tempData;
    }

    // 5. ArkTS 对 Class 使用“标称类型系统(Nominal Typing)”，而 TS 使用“结构化类型系统(Structural Typing)”
    // 在 TS 中，只要对象结构匹配，字面量可以赋值给类类型。
    // 在 ArkTS 中，必须显式使用 new SystemConfig()，不能用字面量冒充 Class。
    const sysConfig: Config = {
        id: 1,
        name: "System",
        version: "2.0",
        print: () => { console.log("Mock print"); }
    };

    // 6. ArkTS 在运行时对类型断言和反射支持有限
    // 这种基于 any 的直接返回和交叉类型推断在 ArkTS 中可能导致推断失败或编译错误
    return mutableConfig;
}

// 测试调用
const initialDatas = { id: 1001, tempData: "Should be deleted" };

const result = processConfiguration(initialDatas, (item) => {
    console.log("Processing item: " + item.id);
});

console.log("Final timestamp: " + result.timestamp);