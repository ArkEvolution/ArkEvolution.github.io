# Changelog
## [v1.0.0] 2024.07
- 基于[is-number](https://www.npmjs.com/package/is-number?activeTab=readme)原库7.0.0版本进行适配

## [v2.0.0] 2024.07
- 修改兼容性部分代码

## [v3.0.0] 2024.07
- 修改项目结构

## [v4.0.0] 2024.10
- 修改项目结构

## [v4.1.0] 2024.10
- 修复export, 更新README
## [v4.2.0] 2024.11
- 更新homepage和repository的链接