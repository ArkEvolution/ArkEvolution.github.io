# is-number

基于[is-number](https://www.npmjs.com/package/is-number?activeTab=readme)原库7.0.0版本进行适配, 所有功能代码已经转换为`ArkTS`文件
## 下载安装

```shell
ohpm install is-number-ohpmtest1
```

## 使用示例
```javascript
import isNumber from 'is-number-ohpmtest1'

isNumber(5e3);               // true
isNumber(0xff);              // true
isNumber(-1.1);              // true
isNumber(0);                 // true
isNumber(1);                 // true
isNumber(1.1);               // true

isNumber(Infinity);          // false
isNumber(NaN);               // false
isNumber(null);              // false
isNumber(undefined);         // false
```