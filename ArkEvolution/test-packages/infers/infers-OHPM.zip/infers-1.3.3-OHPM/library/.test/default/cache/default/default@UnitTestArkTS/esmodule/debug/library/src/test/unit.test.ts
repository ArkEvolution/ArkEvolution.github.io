import { describe, it, expect } from "@normalized:N&&&@ohos/hypium/index&1.0.21";
import { Matrix } from "@normalized:N&&&infers/src/main/ets/lib/matrix&1.3.3";
import { BPNet } from "@normalized:N&&&infers/src/main/ets/lib/BPNet&1.3.3";
export default function bpNetTest() {
    describe('BPNetDowngradeTest', () => {
        // 1. 测试 Matrix 基础功能 (确保底层数学库正常)
        it('should create matrix and verify shape', 0, () => {
            let m = new Matrix([
                [1, 2, 3],
                [4, 5, 6]
            ]);
            // v1.3.3 的 shape 属性是 [rows, cols]
            expect(m.shape[0]).assertEqual(2);
            expect(m.shape[1]).assertEqual(3);
            expect(m.get(1, 2)).assertEqual(6);
        });
        // 2. 测试 Matrix 乘法 (BPNet 核心依赖)
        it('should calculate matrix multiplication correctly', 0, () => {
            // 1x2 * 2x1 = 1x1
            let m1 = new Matrix([[2, 3]]);
            let m2 = new Matrix([[4], [5]]);
            // 2*4 + 3*5 = 8 + 15 = 23
            let res = m1.multiply(m2);
            expect(res.shape[0]).assertEqual(1);
            expect(res.shape[1]).assertEqual(1);
            expect(res.get(0, 0)).assertEqual(23);
        });
        // 3. 测试 BPNet XOR 训练 (集成测试)
        it('should learn XOR logic using BPNet', 0, async () => {
            // 准备 XOR 数据
            let inputData = new Matrix([
                [0, 0],
                [0, 1],
                [1, 0],
                [1, 1]
            ]);
            let outputData = new Matrix([
                [0],
                [1],
                [1],
                [0]
            ]);
            // 初始化网络 (v1.3.3 旧版结构)
            // 输入层: 2, 隐藏层: 3 (Sigmoid), 输出层: 1 (Sigmoid)
            // 调整: 学习率提高到 0.8 以加速收敛，减少训练轮数防止内存溢出
            let net = new BPNet([2, [3, 'Sigmoid'], [1, 'Sigmoid']], {
                rate: 0.8,
                mode: 'sgd'
            });
            console.info("Start training XOR...");
            // 训练
            // 调整: 轮数从 10000 降低到 3000，防止 OldSpace OOM 问题
            await net.fit(inputData, outputData, {
                epochs: 3000,
                onTrainEnd: (loss: number) => {
                    console.info(`Training finished. Final Loss: ${loss}`);
                }
            });
            // 预测
            let p1 = net.predict(new Matrix([[0, 0]])).get(0, 0);
            let p2 = net.predict(new Matrix([[0, 1]])).get(0, 0);
            let p3 = net.predict(new Matrix([[1, 0]])).get(0, 0);
            let p4 = net.predict(new Matrix([[1, 1]])).get(0, 0);
            console.info(`Predictions: [0,0]->${p1}, [0,1]->${p2}, [1,0]->${p3}, [1,1]->${p4}`);
            // 验证结果 (稍微放宽阈值以应对随机初始化带来的波动)
            // 0 XOR 0 = 0 (Expect < 0.3)
            expect(p1 < 0.3).assertTrue();
            // 0 XOR 1 = 1 (Expect > 0.7)
            expect(p2 > 0.7).assertTrue();
            // 1 XOR 0 = 1 (Expect > 0.7)
            expect(p3 > 0.7).assertTrue();
            // 1 XOR 1 = 0 (Expect < 0.3)
            expect(p4 < 0.3).assertTrue();
        });
    });
}
