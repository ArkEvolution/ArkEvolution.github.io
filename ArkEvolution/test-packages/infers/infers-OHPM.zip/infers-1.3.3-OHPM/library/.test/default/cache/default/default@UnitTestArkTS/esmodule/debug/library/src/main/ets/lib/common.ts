import { Matrix } from "@normalized:N&&&infers/src/main/ets/lib/matrix&1.3.3";
// TS2ArkTS-SessionId-61
function toFixed(num: number, fix: number): number {
    const amount = 10 ** fix;
    return ~~(num * amount) / amount;
}
// TS2ArkTS-SessionId-62
function upset(xs: Matrix, ys: Matrix): Record<string, Matrix> {
    let xss = xs.dataSync();
    let yss = ys.dataSync();
    for (let i: number = 1; i < ys.shape[0]; i++) {
        let random: number = Math.floor(Math.random() * (i + 1));
        let tempX = xss[i];
        xss[i] = xss[random];
        xss[random] = tempX;
        let tempY = yss[i];
        yss[i] = yss[random];
        yss[random] = tempY;
    }
    return { "xs": new Matrix(xss), "ys": new Matrix(yss) };
}
// TS2ArkTS-SessionId-65
export { toFixed, upset };
