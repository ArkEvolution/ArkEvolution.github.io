import { upset } from "@normalized:N&&&infers/src/main/ets/lib/common&1.3.3";
import { Matrix } from "@normalized:N&&&infers/src/main/ets/lib/matrix&1.3.3";
import type { ActivationFunction, TrainingOptions, Mode, BPNetOptions, NetShape, BackPropagationResult } from "./types";
export const defaultTrainingOptions = (m: number): TrainingOptions => ({
    epochs: 100,
    batchSize: m > 10 ? 10 : m,
    async: false
});
export class BPNet {
    readonly shape: NetShape;
    w: Matrix[];
    b: Matrix[];
    hlayer: number;
    scale?: Matrix;
    mode: Mode;
    rate: number;
    constructor(shape: NetShape, opt: BPNetOptions = {}) {
        this.shape = shape;
        this.mode = 'sgd';
        this.rate = 0.01;
        this.hlayer = shape.length - 1;
        if (this.hlayer < 1) {
            throw new Error('The network has at least two layers');
        }
        this.w = [];
        this.b = [];
        for (let l = 0; l < this.hlayer; l++) {
            this.w[l] = Matrix.generate(this.unit(l), this.unit(l - 1));
            this.b[l] = Matrix.generate(1, this.unit(l));
        }
        if (opt.mode)
            this.mode = opt.mode;
        if (opt.rate)
            this.rate = opt.rate;
        if (opt.w)
            this.w = opt.w;
        if (opt.b)
            this.b = opt.b;
        if (opt.scale)
            this.scale = opt.scale;
    }
    unit(l: number): number {
        let n = this.shape[l + 1];
        return Array.isArray(n) ? n[0] : n;
    }
    af(l: number): ActivationFunction | undefined {
        let n = this.shape[l + 1];
        return Array.isArray(n) ? n[1] : undefined;
    }
    afn(x: number, rows: number[], af?: ActivationFunction): number {
        switch (af) {
            case 'Sigmoid':
                return 1 / (1 + Math.exp(-x));
            case 'Relu':
                return x >= 0 ? x : 0;
            case 'Tanh':
                return (Math.exp(x) - Math.exp(-x)) / (Math.exp(x) + Math.exp(-x));
            case 'Softmax':
                let d = Math.max(...rows);
                return Math.exp(x - d) / rows.reduce((p, c) => p + Math.exp(c - d), 0);
            default:
                return x;
        }
    }
    afd(x: number, af?: ActivationFunction): number {
        switch (af) {
            case 'Sigmoid':
                return x * (1 - x);
            case 'Relu':
                return x >= 0 ? 1 : 0;
            case 'Tanh':
                return 1 - ((Math.exp(x) - Math.exp(-x)) / (Math.exp(x) + Math.exp(-x))) ** 2;
            case 'Softmax':
            default:
                return 1;
        }
    }
    toJSON(): string {
        return JSON.stringify({
            mode: this.mode,
            shape: this.shape,
            rate: this.rate,
            scale: this.scale ? this.scale.dataSync() : undefined,
            w: this.w.map(w => w.dataSync()),
            b: this.b.map(b => b.dataSync()),
        });
    }
    static fromJSON(json: string): BPNet {
        let tmp: any = JSON.parse(json);
        let w: any = tmp.w.map((w: number[][]) => new Matrix(w));
        let b: any = tmp.b.map((b: number[][]) => new Matrix(b));
        let scale = tmp.scale ? new Matrix(tmp.scale) : undefined;
        return new BPNet(tmp.shape, {
            mode: tmp.mode,
            rate: tmp.mode,
            w, b, scale
        });
    }
    calcnet(xs: Matrix): Matrix[] {
        let hy: Matrix[] = [];
        for (let l = 0; l < this.hlayer; l++) {
            let lastHy = l === 0 ? xs : hy[l - 1];
            let af = this.af(l);
            let tmp = lastHy.multiply(this.w[l].T).atomicOperation((item, _, j) => item + this.b[l].get(0, j));
            hy[l] = tmp.atomicOperation((item, i) => this.afn(item, tmp.getRow(i), af));
        }
        return hy;
    }
    scaled(xs: Matrix): Matrix {
        if (!this.scale)
            return xs;
        return xs.atomicOperation((item, _, j) => {
            let scale = this.scale!;
            let range = scale.get(1, j);
            let average = scale.get(0, j);
            return range === 0 ? 0 : (item - average) / range;
        });
    }
    predict(xs: Matrix): Matrix {
        this.checkInput(xs);
        xs = this.scaled(xs);
        let hy = this.calcnet(xs);
        return hy[hy.length - 1];
    }
    calcDerivativeMultiple(hy: Matrix[], xs: Matrix, ys: Matrix): BackPropagationResult {
        let m = ys.shape[0];
        let dws = this.w.map(w => w.zeroed());
        let dys = this.b.map(b => b.zeroed());
        for (let n = 0; n < m; n++) {
            let nhy = hy.map(item => new Matrix([item.getRow(n)]));
            let nxs = new Matrix([xs.getRow(n)]);
            let nys = new Matrix([ys.getRow(n)]);
            let backPropagationResult = this.calcDerivative(nhy, nxs, nys);
            const ndw = backPropagationResult.dw;
            const ndy = backPropagationResult.dy;
            dws = dws.map((d, l) => d.addition(ndw[l]));
            dys = dys.map((d, l) => d.addition(ndy[l]));
        }
        let dw = dws.map(d => d.atomicOperation(item => item / m));
        let dy = dys.map(d => d.atomicOperation(item => item / m));
        return { dy, dw };
    }
    calcDerivative(hy: Matrix[], xs: Matrix, ys: Matrix): BackPropagationResult {
        let dw: Matrix[] = [], dy: Matrix[] = [];
        for (let l = this.hlayer - 1; l >= 0; l--) {
            let lastHy = hy[l - 1] ? hy[l - 1] : xs;
            let af = this.af(l);
            if (l === this.hlayer - 1) {
                dy[l] = hy[l].atomicOperation((item, r, c) => (item - ys.get(r, c)) * this.afd(item, af));
            }
            else {
                dy[l] = dy[l + 1].multiply(this.w[l + 1]).atomicOperation((item, r, c) => item * this.afd(hy[l].get(r, c), af));
            }
            dw[l] = dy[l].T.multiply(lastHy);
        }
        return { dy, dw };
    }
    adjust(dy: Matrix[], dw: Matrix[]): void {
        this.w = this.w.map((w, l) => w.subtraction(dw[l].numberMultiply(this.rate)));
        this.b = this.b.map((b, l) => b.subtraction(dy[l].numberMultiply(this.rate)));
    }
    cost(hy: Matrix, ys: Matrix): number {
        let m = ys.shape[0];
        let sub = hy.subtraction(ys).atomicOperation(item => (item ** 2) / 2).columnSum();
        let tmp = sub.getRow(0).map(v => v / m);
        return tmp.reduce((p, c) => p + c) / tmp.length;
    }
    calcLoss(xs: Matrix, ys: Matrix): number {
        this.checkSample(xs, ys);
        let lastHy = this.predict(xs);
        return this.cost(lastHy, ys);
    }
    async bgd(xs: Matrix, ys: Matrix, opt: TrainingOptions): Promise<void> {
        for (let ep = 0; ep < opt.epochs; ep++) {
            let hy = this.calcnet(xs);
            let backPropagationResult = this.calcDerivativeMultiple(hy, xs, ys);
            const dy = backPropagationResult.dy;
            const dw = backPropagationResult.dw;
            this.adjust(dy, dw);
            if (opt.onEpoch) {
                opt.onEpoch(ep, this.cost(hy[hy.length - 1], ys));
                opt.async && await new Promise<any>(resolve => setTimeout(resolve));
            }
            if (opt.onTrainEnd && ep === opt.epochs - 1) {
                opt.onTrainEnd(this.cost(hy[hy.length - 1], ys));
            }
        }
    }
    async sgd(xs: Matrix, ys: Matrix, opt: TrainingOptions): Promise<void> {
        let m = ys.shape[0];
        for (let ep = 0; ep < opt.epochs; ep++) {
            let hys: Matrix | null = null;
            for (let n = 0; n < m; n++) {
                let nxs = new Matrix([xs.getRow(n)]);
                let nys = new Matrix([ys.getRow(n)]);
                let hy = this.calcnet(nxs);
                const backPropagationResult = this.calcDerivative(hy, nxs, nys);
                const dy = backPropagationResult.dy;
                const dw = backPropagationResult.dw;
                this.adjust(dy, dw);
                hys = hys ? hys.connect(hy[hy.length - 1]) : hy[hy.length - 1];
            }
            if (opt.onEpoch) {
                opt.onEpoch(ep, this.cost(hys!, ys));
                opt.async && await new Promise<any>(resolve => setTimeout(resolve));
            }
            if (opt.onTrainEnd && ep === opt.epochs - 1) {
                opt.onTrainEnd(this.cost(hys!, ys));
            }
        }
    }
    async mbgd(xs: Matrix, ys: Matrix, opt: TrainingOptions): Promise<void> {
        let m = ys.shape[0];
        let batchSize = opt.batchSize!;
        let batch = Math.ceil(m / batchSize);
        for (let ep = 0; ep < opt.epochs; ep++) {
            let res = upset(xs, ys);
            const xst = res.xs;
            const yst = res.ys;
            let eploss = 0;
            for (let b = 0; b < batch; b++) {
                let start = b * batchSize;
                let end = start + batchSize;
                end = end > m ? m : end;
                let size = end - start;
                let bxs = xst.slice(start, end);
                let bys = yst.slice(start, end);
                let hy = this.calcnet(bxs);
                let lastHy = hy[hy.length - 1];
                const backPropagationResult = this.calcDerivativeMultiple(hy, bxs, bys);
                const dy = backPropagationResult.dy;
                const dw = backPropagationResult.dw;
                this.adjust(dy, dw);
                let bloss = this.cost(lastHy, bys);
                eploss += bloss;
                if (opt.onBatch)
                    opt.onBatch(b, size, bloss);
            }
            if (opt.onEpoch) {
                opt.onEpoch(ep, eploss / batch);
                opt.async && await new Promise<any>(resolve => setTimeout(resolve));
            }
            if (opt.onTrainEnd && ep === opt.epochs - 1) {
                opt.onTrainEnd(eploss / batch);
            }
        }
    }
    checkInput(xs: Matrix): void {
        if (xs.shape[1] !== this.unit(-1)) {
            throw new Error(`Input matrix column number error, input shape -> ${this.unit(-1)}.`);
        }
    }
    checkSample(xs: Matrix, ys: Matrix): void {
        this.checkInput(xs);
        if (xs.shape[0] !== ys.shape[0]) {
            throw new Error('The row number of input and output matrix is not uniform.');
        }
        if (ys.shape[1] !== this.unit(this.hlayer - 1)) {
            throw new Error(`Output matrix column number error, output shape -> ${this.unit(this.hlayer - 1)}.`);
        }
    }
    fit(xs: Matrix, ys: Matrix, opt: Partial<TrainingOptions> = {}): Promise<void> {
        let m = ys.shape[0];
        let defaultOpt = defaultTrainingOptions(m);
        let nopt: TrainingOptions = {
            epochs: opt.epochs !== undefined ? opt.epochs : defaultOpt.epochs,
            batchSize: opt.batchSize !== undefined ? opt.batchSize : defaultOpt.batchSize,
            async: opt.async !== undefined ? opt.async : defaultOpt.async,
            onBatch: opt.onBatch !== undefined ? opt.onBatch : defaultOpt.onBatch,
            onEpoch: opt.onEpoch !== undefined ? opt.onEpoch : defaultOpt.onEpoch,
            onTrainEnd: opt.onTrainEnd !== undefined ? opt.onTrainEnd : defaultOpt.onTrainEnd
        };
        this.checkSample(xs, ys);
        if (nopt.batchSize! > m) {
            throw new Error(`The batch size cannot be greater than the number of samples.`);
        }
        const normRes = xs.normalization();
        const nxs = normRes[0];
        const scale = normRes[1];
        this.scale = scale;
        xs = nxs;
        switch (this.mode) {
            case 'bgd':
                return this.bgd(xs, ys, nopt);
            case 'mbgd':
                return this.mbgd(xs, ys, nopt);
            case 'sgd':
            default:
                return this.sgd(xs, ys, nopt);
        }
    }
}
