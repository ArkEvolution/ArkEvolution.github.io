import testXor from "@normalized:N&&&infers/src/test/unit.test&1.3.3";
export default function testsuite() {
    testXor();
}
