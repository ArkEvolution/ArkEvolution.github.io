# infers
- 基于[infers-1.3.3]()原库1.3.3版本进行适配.
Matrix operation and machine learning library by TypeScript (Compatible with OpenHarmony/ArkTS).
- [XOR EXAMPLE](https://badgua.gitee.io/infers)
- [API DOC](https://badgua.gitee.io/infers/api/)

![](https://gitee.com/badgua/infers/raw/main/docs/net.png)

## Installation
Make sure `ohpm` is installed. Switch to the project directory then execute the following command:

```shell
ohpm install infers
```

Reference in project:
```typescript
import { Matrix, BPNet, RNN } from 'infers'
```

## Examples

### 1. Matrix Transpose
```typescript
let m = new Matrix([
  [1, 5, 0],
  [2, 4 , -1],
  [0, -2, 0]
])
m.T.print()
// Output:
// Matrix 3x3 [
//  1, 2, 0, 
//  5, 4, -2, 
//  0, -1, 0, 
// ]
```

### 2. BP Neural Network (XOR)
Three-layer network example:
```typescript
let xs = new Matrix([[1, 0], [0, 1], [0, 0], [1, 1]])
let ys = new Matrix([[1], [1], [0], [0]])
let model = new BPNet([2, [6, 'Tanh'], [1, 'Sigmoid']], { rate: 0.1 })

model.fit(xs, ys, {
  epochs: 5000, 
  onEpoch: (epoch, loss) => {
    if (epoch % 100 === 0) console.log('epoch:' + epoch, 'loss:', loss)
  }
})

model.predict(xs).print()
// Output:
// Matrix 4x1 [
//  0.9862025352830867, 
//  0.986128496195502, 
//  0.01443800549676924, 
//  0.014425871504885788, 
// ]
```

### 3. BP Neural Network (Addition)
Four-layer network example:
```typescript
let xs = new Matrix([[1, 4], [3, 2], [6, 5], [4, 7]])
let ys = new Matrix([[5], [5], [11], [11]])
let model = new BPNet([2, 6, 6, 1], { mode: 'bgd', rate: 0.01 })

model.fit(xs, ys, {
  epochs: 500, 
  onEpoch: (epoch, loss) => {
    console.log('epoch:' + epoch, 'loss:', loss)
  }
})

let xs2 = new Matrix([[5, 8], [22, 6], [-5, 9], [-5, -4]])
model.predict(xs2).print()
// Output:
// Matrix 2x1 [
//  12.994745740521667, 
//  27.99134620596921, 
//  3.9987224114576856, 
//  -9.000000644547901,
// ]
```

### 4. RNN (Recurrent Neural Network)
Text prediction example:
```typescript
let trainData = ['Hello RNN', 'morning', 'I love 🍎', '我的🍎在哪里', '我的🍊被人偷了']
let net = new RNN({ trainData })

net.fit({
  epochs: 1500,
  onEpochs: (epoch, loss) => {
    if (epoch % 10 === 0) console.log('epoch: ', epoch, 'loss: ', loss)
  }
})

console.log(net.predict('我的🍎'))
console.log(net.predict('我的🍊'))
console.log(net.predict('Hel'))
// Output:
// 在哪里/n
// 被人偷了/n
// lo RNN/n
```

## Parameter Introduction
* **shape**: The network hierarchical structure of the model. It defines the number of neurons in each layer, the type of activation function for each layer, and the total number of layers. A more complex structure requires more computation per training step and may lead to overfitting.
* **rate**: Learning rate (also known as training step).
  * A lower learning rate requires more training iterations (epochs) to reach the optimal cost function.
  * A learning rate that is too high may cause the model to overshoot the optimal cost function, resulting in the loss value approaching infinity (divergence) and preventing convergence.
* **epochs**: One epoch means all data in the training set has been iterated through once.
* **mode**: Training modes. Options: `sgd` (Stochastic Gradient Descent) | `bgd` (Batch Gradient Descent) | `mbgd` (Mini-batch Gradient Descent).

> **Note**: The selection of the above parameters is crucial for model optimization. The learning rate, training epochs, and network shape required vary by problem and must be adjusted according to the cost function's behavior.

## Export
* **class Matrix**
  * Operations: addition, subtraction, multiply, transpose (`T`)
  * Utils: determinant, normalization
* **class BPNet**
  * Multi-layer network model (suitable for tasks like CNN-style layering)
  * Supports multiple activation functions
  * Applications: Linear regression and Logical classification
* **class RNN**
  * Recurrent Neural Network implementation